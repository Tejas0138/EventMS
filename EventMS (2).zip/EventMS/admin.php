<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// =========================================================================
// Auth Guard
// =========================================================================
if (empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/config/db.php';

$pdo           = Database::getConnection();
$adminUsername = htmlspecialchars($_SESSION['admin_username'] ?? 'User');
$userRole      = (string)($_SESSION['user_role'] ?? 'guard');
$isSuperAdmin  = ($userRole === 'super_admin');
$isGuard       = ($userRole === 'guard');
$isCounter     = ($userRole === 'counter');
$counterRegion = trim((string)($_SESSION['counter_region'] ?? ''));
$counterId     = (int)($_SESSION['counter_id'] ?? 0);
$counterName   = (string)($_SESSION['counter_name'] ?? '');
$counterRange  = (string)($_SESSION['counter_range'] ?? '');
$counterCode   = (string)($_SESSION['counter_code'] ?? '');

if ($isCounter && ($counterId === 0 || $counterName === '')) {
    $cStmt = $pdo->prepare("SELECT id, name, code, name_range FROM `counters` WHERE username = :u LIMIT 1");
    $cStmt->execute([':u' => $_SESSION['admin_username'] ?? '']);
    $cRow = $cStmt->fetch(PDO::FETCH_ASSOC);
    if ($cRow) {
        $counterId    = (int)$cRow['id'];
        $counterName  = $cRow['name'];
        $counterRange = (string)($cRow['name_range'] ?? '');
        $counterCode  = $cRow['code'];
        $_SESSION['counter_id']    = $counterId;
        $_SESSION['counter_name']  = $counterName;
        $_SESSION['counter_range'] = $counterRange;
        $_SESSION['counter_code']  = $counterCode;
    }
}

$roleLabel = 'User';
if ($isSuperAdmin) {
    $roleLabel = 'Super Admin';
} elseif ($isCounter) {
    if (!empty($counterRange)) {
        $roleLabel = "{$counterName} ({$counterRange})";
    } elseif (!empty($counterName)) {
        $roleLabel = $counterName;
    } else {
        $roleLabel = ($counterRegion !== '' ? $counterRegion : 'Help Desk') . ' Counter';
    }
} elseif ($isGuard) {
    $roleLabel = 'Gate Guard (Gate 1)';
}

// =========================================================================
// Tab Access & Role Boundary Enforcement
// =========================================================================
$tab = $_GET['tab'] ?? ($isCounter ? 'gift' : 'gate');
if ($isCounter && $tab !== 'gift') {
    header('Location: admin.php?tab=gift');
    exit;
}
if ($isGuard && $tab !== 'gate') {
    header('Location: admin.php?tab=gate');
    exit;
}
if ($tab === 'counters' && !$isSuperAdmin) {
    header('Location: admin.php?tab=' . ($isCounter ? 'gift' : 'gate') . '&msg=permission_denied');
    exit;
}

// =========================================================================
// Action Handlers (Check-in, Reset, Import, Export, Counter Management)
// =========================================================================
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$msg    = $_GET['msg']    ?? null;
$id     = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);

if ($id > 0) {
    // Preserve search, filter, region and pagination query parameters
    $redirectUrl = "admin.php?tab=" . urlencode($tab);
    if (!empty($_GET['gfilter'])) {
        $redirectUrl .= "&gfilter=" . urlencode((string)$_GET['gfilter']);
    }
    if (!empty($_GET['gsearch'])) {
        $redirectUrl .= "&gsearch=" . urlencode((string)$_GET['gsearch']);
    }
    if (!empty($_GET['gregion'])) {
        $redirectUrl .= "&gregion=" . urlencode((string)$_GET['gregion']);
    }
    if (!empty($_GET['gpage'])) {
        $redirectUrl .= "&gpage=" . urlencode((string)$_GET['gpage']);
    }
    if (!empty($_GET['dfilter'])) {
        $redirectUrl .= "&dfilter=" . urlencode((string)$_GET['dfilter']);
    }
    if (!empty($_GET['dsearch'])) {
        $redirectUrl .= "&dsearch=" . urlencode((string)$_GET['dsearch']);
    }
    if (!empty($_GET['dregion'])) {
        $redirectUrl .= "&dregion=" . urlencode((string)$_GET['dregion']);
    }
    if (!empty($_GET['dpage'])) {
        $redirectUrl .= "&dpage=" . urlencode((string)$_GET['dpage']);
    }

    $isAjaxAction = (
        (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
        (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) ||
        isset($_REQUEST['ajax'])
    );

    try {
        // Gate entry actions — forbidden for counter staff
        if (in_array($action, ['reset_d1', 'reset_day1', 'gate_reset_d1', 'reset_d2', 'reset_day2', 'gate_reset_d2', 'checkin_d1', 'checkin_day1', 'gate_checkin_d1', 'gate_checkin', 'checkin_d2', 'checkin_day2', 'gate_checkin_d2', 'gate_reset'], true)) {
            if ($isCounter) {
                if ($isAjaxAction) {
                    http_response_code(403);
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['success' => false, 'error' => 'Permission denied: Counter staff cannot modify Gate Entry logs.']);
                    exit;
                }
                header("Location: admin.php?tab=gift&msg=permission_denied");
                exit;
            }
        }

        if ($action === 'reset_d1' || $action === 'reset_day1' || $action === 'gate_reset_d1') {
            $stmt = $pdo->prepare("UPDATE allowed_visitors SET is_day1_checked_in = 0, day1_checked_in_at = NULL, is_checked_in = 0, checked_in_at = NULL WHERE id = :id");
            $stmt->execute(['id' => $id]);
            if ($isAjaxAction) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'action' => $action, 'id' => $id]);
                exit;
            }
            header("Location: " . $redirectUrl);
            exit;
        }
        if ($action === 'reset_d2' || $action === 'reset_day2' || $action === 'gate_reset_d2') {
            $stmt = $pdo->prepare("UPDATE allowed_visitors SET is_day2_checked_in = 0, day2_checked_in_at = NULL WHERE id = :id");
            $stmt->execute(['id' => $id]);
            if ($isAjaxAction) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'action' => $action, 'id' => $id]);
                exit;
            }
            header("Location: " . $redirectUrl);
            exit;
        }
        if ($action === 'checkin_d1' || $action === 'checkin_day1' || $action === 'gate_checkin_d1' || $action === 'gate_checkin') {
            $stmt = $pdo->prepare("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP(), is_checked_in = 1, checked_in_at = COALESCE(checked_in_at, UTC_TIMESTAMP()) WHERE id = :id");
            $stmt->execute(['id' => $id]);
            if ($isAjaxAction) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'action' => $action, 'id' => $id]);
                exit;
            }
            header("Location: " . $redirectUrl);
            exit;
        }
        if ($action === 'checkin_d2' || $action === 'checkin_day2' || $action === 'gate_checkin_d2') {
            $stmt = $pdo->prepare("UPDATE allowed_visitors SET is_day2_checked_in = 1, day2_checked_in_at = UTC_TIMESTAMP() WHERE id = :id");
            $stmt->execute(['id' => $id]);
            if ($isAjaxAction) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'action' => $action, 'id' => $id]);
                exit;
            }
            header("Location: " . $redirectUrl);
            exit;
        }
        if ($action === 'gate_reset') {
            $stmt = $pdo->prepare("UPDATE allowed_visitors SET is_day1_checked_in = 0, day1_checked_in_at = NULL, is_day2_checked_in = 0, day2_checked_in_at = NULL, is_checked_in = 0, checked_in_at = NULL WHERE id = :id");
            $stmt->execute(['id' => $id]);
            if ($isAjaxAction) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'action' => $action, 'id' => $id]);
                exit;
            }
            header("Location: " . $redirectUrl);
            exit;
        }

        // COE Kit Handover & Reset with Region Isolation Enforcement
        if ($action === 'mark_given' || $action === 'gift_mark_given') {
            if ($isCounter) {
                $checkRegStmt = $pdo->prepare("SELECT region FROM `gift_distribution` WHERE id = :id");
                $checkRegStmt->execute([':id' => $id]);
                $rowReg = $checkRegStmt->fetchColumn();
                $attendeeReg = trim((string)$rowReg);

                $isRegionAllowed = false;
                if ($counterRegion === 'Help Desk') {
                    $isRegionAllowed = ($attendeeReg === '');
                } else {
                    $isRegionAllowed = (strcasecmp($attendeeReg, $counterRegion) === 0);
                }

                if (!$isRegionAllowed) {
                    if ($isAjaxAction) {
                        http_response_code(403);
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode(['success' => false, 'error' => 'Permission denied: This attendee belongs to another region counter.']);
                        exit;
                    }
                    header("Location: admin.php?tab=gift&msg=permission_denied");
                    exit;
                }
            }

            $actingCounterName = $isSuperAdmin ? 'Super Admin' : ($counterRegion !== '' ? "{$counterRegion} Counter" : 'Help Desk');
            $stmt = $pdo->prepare("
                UPDATE `gift_distribution` 
                SET is_gift_collected = 1, 
                    gift_collected_at = UTC_TIMESTAMP(), 
                    handed_over_by = :who, 
                    counter_region = :creg 
                WHERE id = :id
            ");
            $stmt->execute([
                ':id'   => $id,
                ':who'  => $_SESSION['admin_username'] ?? 'admin',
                ':creg' => $actingCounterName,
            ]);
            if ($isAjaxAction) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'action' => $action, 'id' => $id]);
                exit;
            }
            header("Location: " . $redirectUrl . "&msg=gift_given_one");
            exit;
        }

        if ($action === 'reset_gift' || $action === 'gift_reset') {
            if ($isCounter) {
                $checkRegStmt = $pdo->prepare("SELECT region FROM `gift_distribution` WHERE id = :id");
                $checkRegStmt->execute([':id' => $id]);
                $rowReg = $checkRegStmt->fetchColumn();
                $attendeeReg = trim((string)$rowReg);

                $isRegionAllowed = false;
                if ($counterRegion === 'Help Desk') {
                    $isRegionAllowed = ($attendeeReg === '');
                } else {
                    $isRegionAllowed = (strcasecmp($attendeeReg, $counterRegion) === 0);
                }

                if (!$isRegionAllowed) {
                    if ($isAjaxAction) {
                        http_response_code(403);
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode(['success' => false, 'error' => 'Permission denied: This attendee belongs to another region counter.']);
                        exit;
                    }
                    header("Location: admin.php?tab=gift&msg=permission_denied");
                    exit;
                }
            }

            $stmt = $pdo->prepare("
                UPDATE `gift_distribution` 
                SET is_gift_collected = 0, 
                    gift_collected_at = NULL, 
                    handed_over_by = NULL, 
                    counter_region = NULL 
                WHERE id = :id
            ");
            $stmt->execute([':id' => $id]);
            if ($isAjaxAction) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'action' => $action, 'id' => $id]);
                exit;
            }
            header("Location: " . $redirectUrl . "&msg=gift_reset_one");
            exit;
        }
    } catch (\Throwable $e) {
        if ($isAjaxAction) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            exit;
        }
        header("Location: " . $redirectUrl . "&msg=db_error");
        exit;
    }
}

// =========================================================================
// Super Admin Actions for Regional Counter Management
// =========================================================================

// Super Admin Action: Reset Counter Password
if ($action === 'reset_counter_pwd' || $action === 'reset_counter_password') {
    if (!$isSuperAdmin) {
        header('Location: admin.php?tab=counters&msg=permission_denied');
        exit;
    }
    $counterId = (int)($_POST['counter_id'] ?? $_GET['counter_id'] ?? 0);
    if ($counterId > 0) {
        $cStmt = $pdo->prepare("SELECT id, name, username FROM `counters` WHERE id = :id LIMIT 1");
        $cStmt->execute([':id' => $counterId]);
        $targetCounter = $cStmt->fetch();
        if (!$targetCounter) {
            // Fallback: check admins table
            $aStmt = $pdo->prepare("SELECT id, username, region FROM `admins` WHERE id = :id LIMIT 1");
            $aStmt->execute([':id' => $counterId]);
            $targetCounter = $aStmt->fetch();
        }

        if ($targetCounter) {
            $chars = '23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ@#$%*';
            $newPlainPass = '';
            for ($i = 0; $i < 12; $i++) {
                $newPlainPass .= $chars[random_int(0, strlen($chars) - 1)];
            }
            $newHash = password_hash($newPlainPass, PASSWORD_DEFAULT);

            // Update counters table
            $pdo->prepare("UPDATE `counters` SET password_hash = :p WHERE id = :id OR username = :u")
                ->execute([':p' => $newHash, ':id' => $counterId, ':u' => $targetCounter['username']]);

            // Update admins table
            $pdo->prepare("UPDATE `admins` SET password = :p, failed_attempts = 0, locked_until = NULL WHERE username = :u OR counter_id = :id")
                ->execute([':p' => $newHash, ':u' => $targetCounter['username'], ':id' => $counterId]);

            $_SESSION['counter_pwd_reset'] = [
                'id'       => $counterId,
                'username' => $targetCounter['username'],
                'region'   => $targetCounter['name'] ?? $targetCounter['region'] ?? 'Counter',
                'password' => $newPlainPass,
            ];
            header('Location: admin.php?tab=counters&msg=counter_pwd_reset');
            exit;
        }
    }
    header('Location: admin.php?tab=counters&msg=db_error');
    exit;
}

// Super Admin Action: Toggle Counter Status (Active / Disabled)
if ($action === 'toggle_counter_status') {
    if (!$isSuperAdmin) {
        header('Location: admin.php?tab=counters&msg=permission_denied');
        exit;
    }
    $counterId = (int)($_POST['counter_id'] ?? $_GET['counter_id'] ?? 0);
    if ($counterId > 0) {
        $cStmt = $pdo->prepare("SELECT id, username, is_active FROM `counters` WHERE id = :id LIMIT 1");
        $cStmt->execute([':id' => $counterId]);
        $cRow = $cStmt->fetch(PDO::FETCH_ASSOC);

        if ($cRow) {
            $newActive = ((int)$cRow['is_active'] === 1) ? 0 : 1;
            $newStatus = $newActive ? 'active' : 'disabled';

            $pdo->prepare("UPDATE `counters` SET is_active = :a WHERE id = :id")
                ->execute([':a' => $newActive, ':id' => $counterId]);
            $pdo->prepare("UPDATE `admins` SET status = :s, failed_attempts = 0, locked_until = NULL WHERE username = :u OR counter_id = :id")
                ->execute([':s' => $newStatus, ':u' => $cRow['username'], ':id' => $counterId]);

            header('Location: admin.php?tab=counters&msg=counter_status_toggled');
            exit;
        }
    }
    header('Location: admin.php?tab=counters&msg=db_error');
    exit;
}

// Super Admin Action: Reassign Visitor to Another Counter
if ($action === 'reassign_counter' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isSuperAdmin) {
        header('Location: admin.php?tab=gift&msg=permission_denied');
        exit;
    }
    $visitorId    = (int)($_POST['visitor_id'] ?? 0);
    $newCounterId = (int)($_POST['new_counter_id'] ?? 0);
    $reason       = trim((string)($_POST['reason'] ?? 'Queue rebalance / Admin adjustment'));

    if ($visitorId > 0 && $newCounterId > 0) {
        $vStmt = $pdo->prepare("SELECT id, name, user_id, counter_id FROM `gift_distribution` WHERE id = :id LIMIT 1");
        $vStmt->execute([':id' => $visitorId]);
        $vRow = $vStmt->fetch(PDO::FETCH_ASSOC);

        if ($vRow) {
            $oldCid = !empty($vRow['counter_id']) ? (int)$vRow['counter_id'] : null;

            $pdo->prepare("UPDATE `gift_distribution` SET counter_id = :cid WHERE id = :id")
                ->execute([':cid' => $newCounterId, ':id' => $visitorId]);
            if (!empty($vRow['user_id'])) {
                $pdo->prepare("UPDATE `allowed_visitors` SET counter_id = :cid WHERE user_id = :uid")
                    ->execute([':cid' => $newCounterId, ':uid' => $vRow['user_id']]);
            }

            $pdo->prepare("
                INSERT INTO `counter_reassignment_log` 
                (`visitor_id`, `visitor_name`, `user_id`, `old_counter_id`, `new_counter_id`, `changed_by`, `reason`)
                VALUES (:vid, :vname, :uid, :old_cid, :new_cid, :by, :reason)
            ")->execute([
                ':vid'     => $visitorId,
                ':vname'   => $vRow['name'],
                ':uid'     => $vRow['user_id'],
                ':old_cid' => $oldCid,
                ':new_cid' => $newCounterId,
                ':by'      => $_SESSION['admin_username'] ?? 'admin',
                ':reason'  => $reason
            ]);

            $dFilter = urlencode((string)($_POST['dfilter'] ?? 'all'));
            $dPage   = urlencode((string)($_POST['dpage'] ?? '1'));
            $dSearch = urlencode((string)($_POST['dsearch'] ?? ''));
            header("Location: admin.php?tab=gift&msg=counter_reassigned&dfilter={$dFilter}&dpage={$dPage}&dsearch={$dSearch}");
            exit;
        }
    }
    header('Location: admin.php?tab=gift&msg=db_error');
    exit;
}

// Super Admin Action: Create New Counter
if ($action === 'create_counter' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isSuperAdmin) {
        header('Location: admin.php?tab=gift&msg=permission_denied');
        exit;
    }
    $newRegion   = trim((string)($_POST['new_region'] ?? ''));
    $newUsername = trim((string)($_POST['new_username'] ?? ''));
    $newPass     = trim((string)($_POST['new_password'] ?? ''));

    if ($newRegion === '') {
        header('Location: admin.php?tab=counters&msg=invalid_counter_region');
        exit;
    }

    if ($newUsername === '') {
        $slug = preg_replace('/[^a-z0-9]+/i', '_', strtolower($newRegion));
        $slug = trim($slug, '_');
        $newUsername = 'counter_' . $slug;
    }

    // Check uniqueness of username
    $uCheck = $pdo->prepare("SELECT COUNT(*) FROM `admins` WHERE username = :u");
    $uCheck->execute([':u' => $newUsername]);
    if ((int)$uCheck->fetchColumn() > 0) {
        header('Location: admin.php?tab=counters&msg=counter_exists');
        exit;
    }

    if ($newPass === '') {
        $chars = '23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ!@#$%';
        for ($i = 0; $i < 11; $i++) {
            $newPass .= $chars[random_int(0, strlen($chars) - 1)];
        }
    }

    $newHash = password_hash($newPass, PASSWORD_DEFAULT);
    $ins = $pdo->prepare("
        INSERT INTO `admins` (`username`, `password`, `role`, `region`, `status`, `failed_attempts`) 
        VALUES (:u, :p, 'counter', :r, 'active', 0)
    ");
    $ins->execute([
        ':u' => $newUsername,
        ':p' => $newHash,
        ':r' => $newRegion,
    ]);

    $_SESSION['counter_pwd_reset'] = [
        'id'       => (int)$pdo->lastInsertId(),
        'username' => $newUsername,
        'region'   => $newRegion,
        'password' => $newPass,
    ];
    header('Location: admin.php?tab=counters&msg=counter_created');
    exit;
}

// Gate: Reset All (Super Admin ONLY)
if ($action === 'gate_reset_all' || $action === 'reset_all') {
    if (!$isSuperAdmin) {
        header('Location: admin.php?tab=gate&msg=permission_denied');
        exit;
    }
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 0, day1_checked_in_at = NULL, is_day2_checked_in = 0, day2_checked_in_at = NULL, is_checked_in = 0, checked_in_at = NULL;");
    header('Location: admin.php?tab=gate&msg=gate_reset_all');
    exit;
}

// Gift: Reset All (Super Admin ONLY)
if ($action === 'gift_reset_all') {
    if (!$isSuperAdmin) {
        header('Location: admin.php?tab=gift&msg=permission_denied');
        exit;
    }
    $pdo->exec("UPDATE `gift_distribution` SET is_gift_collected = 0, gift_collected_at = NULL");
    header('Location: admin.php?tab=gift&msg=gift_reset_all');
    exit;
}

// CSV Bulk Import with Dual-Table Synchronization (Gate Entry + Gift Distribution)
if ($action === 'import_csv' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentTab = (string)($_POST['tab'] ?? $_GET['tab'] ?? 'gate');

    // Strict Backend Guard Protection
    if (empty($_SESSION['user_role']) || $_SESSION['user_role'] !== 'super_admin') {
        header("Location: admin.php?tab={$currentTab}&msg=permission_denied");
        exit;
    }

    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK || strtolower(pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION)) !== 'csv' || !is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
        header("Location: admin.php?tab={$currentTab}&msg=invalid_file");
        exit;
    }

    $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
    $importedCount = $skippedCount = 0;
    $headers = null;

    // Prepared statements for dual table synchronization
    $stmtGate = $pdo->prepare("
        INSERT INTO `allowed_visitors` 
        (`name`, `mobile`, `user_id`, `region`, `fincert`, `school_name`, `designation`, `email`, `is_day1_checked_in`, `day1_checked_in_at`, `is_day2_checked_in`, `day2_checked_in_at`, `is_checked_in`, `checked_in_at`)
        VALUES (:name, :mobile, :user_id, :region, :fincert, :school_name, :designation, :email, 0, NULL, 0, NULL, 0, NULL)
        ON DUPLICATE KEY UPDATE 
            `name` = VALUES(`name`),
            `mobile` = COALESCE(NULLIF(VALUES(`mobile`), ''), `mobile`),
            `region` = COALESCE(NULLIF(VALUES(`region`), ''), `region`),
            `fincert` = COALESCE(NULLIF(VALUES(`fincert`), ''), `fincert`),
            `school_name` = COALESCE(NULLIF(VALUES(`school_name`), ''), `school_name`),
            `designation` = COALESCE(NULLIF(VALUES(`designation`), ''), `designation`),
            `email` = COALESCE(NULLIF(VALUES(`email`), ''), `email`)
    ");

    $stmtGift = $pdo->prepare("
        INSERT INTO `gift_distribution` 
        (`name`, `mobile`, `user_id`, `region`, `fincert`, `school_name`, `designation`, `email`, `is_gift_collected`, `gift_collected_at`)
        VALUES (:name, :mobile, :user_id, :region, :fincert, :school_name, :designation, :email, 0, NULL)
        ON DUPLICATE KEY UPDATE 
            `name` = VALUES(`name`),
            `mobile` = COALESCE(NULLIF(VALUES(`mobile`), ''), `mobile`),
            `region` = COALESCE(NULLIF(VALUES(`region`), ''), `region`),
            `fincert` = COALESCE(NULLIF(VALUES(`fincert`), ''), `fincert`),
            `school_name` = COALESCE(NULLIF(VALUES(`school_name`), ''), `school_name`),
            `designation` = COALESCE(NULLIF(VALUES(`designation`), ''), `designation`),
            `email` = COALESCE(NULLIF(VALUES(`email`), ''), `email`)
    ");

    $pdo->beginTransaction();
    try {
        while (($row = fgetcsv($handle, 3000, ',')) !== false) {
            if (empty($row) || (count($row) === 1 && trim((string)$row[0]) === '')) continue;
            if (count($row) === 1 && str_contains((string)$row[0], ';')) $row = str_getcsv($row[0], ';');

            // Detect Header Row
            if ($headers === null) {
                $firstRowStr = strtolower(implode(' ', $row));
                if (str_contains($firstRowStr, 'name') || str_contains($firstRowStr, 'contact') || str_contains($firstRowStr, 'user') || str_contains($firstRowStr, 'register') || str_contains($firstRowStr, 'umname') || str_contains($firstRowStr, 'mobile')) {
                    $headers = [];
                    foreach ($row as $colIdx => $colName) {
                        $c = strtolower(trim((string)$colName));
                        $headers[$c] = $colIdx;
                    }
                    continue; // Skip header row
                } else {
                    $headers = false; // Legacy format without headers
                }
            }

            $name = '';
            $mobile = '';
            $userId = null;
            $region = null;
            $fincert = null;
            $schoolName = null;
            $designation = null;
            $email = null;

            if (is_array($headers)) {
                $getVal = function(array $patterns) use ($headers, $row): ?string {
                    foreach ($headers as $colName => $idx) {
                        foreach ($patterns as $p) {
                            if ($colName === $p || str_contains($colName, $p)) {
                                return isset($row[$idx]) ? trim((string)$row[$idx]) : null;
                            }
                        }
                    }
                    return null;
                };

                $rawName = $getVal(['full name', 'umname', 'name', 'guest']) ?? '';
                $rawMobile = $getVal(['contact', 'mobile number', 'mobile', 'phone']) ?? '';
                $rawUserId = $getVal(['register id', 'register_id', 'registerid', 'register', 'user_id', 'userid', 'user id']) ?? null;
                $rawRegion = $getVal(['region', 'city', 'location']) ?? null;
                $rawFincert = $getVal(['fincert', 'fin cert', 'id no']) ?? null;
                $rawSchool = $getVal(['schname', 'school name', 'school']) ?? null;
                $rawDesig = $getVal(['desig', 'designation']) ?? null;
                $rawEmail = $getVal(['emaild', 'email']) ?? null;

                $name = $rawName;
                $mobile = $rawMobile;
                $userId = $rawUserId;
                $region = $rawRegion;
                $fincert = $rawFincert;
                $schoolName = $rawSchool;
                $designation = $rawDesig;
                $email = $rawEmail;
            } else {
                $rawName = trim((string)($row[0] ?? ''));
                $rawMobile = trim((string)($row[1] ?? ''));
                if (preg_match('/^[0-9+\s()-]+$/', $rawName) && !preg_match('/^[0-9+\s()-]+$/', $rawMobile)) {
                    [$rawName, $rawMobile] = [$rawMobile, $rawName];
                }
                $name = $rawName;
                $mobile = $rawMobile;
            }

            // Clean mobile
            $m = preg_replace('/\D/', '', $mobile);
            if (strlen($m) === 12 && str_starts_with($m, '91')) $m = substr($m, 2);
            if (strlen($m) === 11 && str_starts_with($m, '0'))  $m = substr($m, 1);
            if (strlen($m) !== 10) {
                $m = ($m !== '') ? $m : null;
            }

            // User ID handling
            $cleanUserId = ($userId !== null && trim($userId) !== '') ? trim($userId) : null;
            if ($cleanUserId === null && $m === null) {
                $skippedCount++;
                continue;
            }
            if ($cleanUserId === null && $m !== null) {
                $cleanUserId = 'USR_' . $m;
            }

            $cleanRegion = ($region !== null && trim($region) !== '') ? ucwords(strtolower(trim($region))) : null;
            $cleanName = mb_substr(trim($name) ?: ('Visitor ' . ($m ? substr($m, -4) : $cleanUserId)), 0, 100);
            $cleanFincert = ($fincert !== null && trim($fincert) !== '') ? strtoupper(trim($fincert)) : null;
            $cleanSchool = ($schoolName !== null && trim($schoolName) !== '') ? trim($schoolName) : null;
            $cleanDesig = ($designation !== null && trim($designation) !== '') ? trim($designation) : null;
            $cleanEmail = ($email !== null && trim($email) !== '') ? trim($email) : null;

            $params = [
                ':name'         => $cleanName,
                ':mobile'       => $m,
                ':user_id'      => $cleanUserId,
                ':region'       => $cleanRegion,
                ':fincert'      => $cleanFincert,
                ':school_name'  => $cleanSchool,
                ':designation'  => $cleanDesig,
                ':email'        => $cleanEmail,
            ];

            $stmtGate->execute($params);
            $stmtGift->execute($params);
            $importedCount++;
        }
        $pdo->commit();

        // Automatically assign newly imported visitors to appropriate counters
        try {
            Database::syncVisitorCounters($pdo);
        } catch (\Throwable $t) {
            error_log("Failed to auto-sync visitor counters after CSV import: " . $t->getMessage());
        }
    } catch (\Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        fclose($handle);
        header("Location: admin.php?tab={$currentTab}&msg=import_error");
        exit;
    }
    fclose($handle);
    header("Location: admin.php?tab={$currentTab}&msg=imported&import_success={$importedCount}&count={$importedCount}&skipped={$skippedCount}");
    exit;
}
if (isset($_GET['export']) && $_GET['export'] === 'gate_csv') {
    if (empty($_SESSION['user_role']) || $_SESSION['user_role'] !== 'super_admin') {
        header('Location: admin.php?tab=gate&msg=permission_denied');
        exit;
    }
    $stmt = $pdo->query("SELECT * FROM `allowed_visitors` ORDER BY name ASC");
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=gate_visitors_2day_' . date('Y-m-d_His') . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, [
        'S.No', 'Full Name', 'Register Id', 'FinCert ID (Your Id no.)', 'Region', 'School Name', 'Designation', 'Mobile Number', 'Email',
        'Day 1 Status', 'Day 1 Check-in Time (IST)', 'Day 2 Status', 'Day 2 Check-in Time (IST)', 'Created At (IST)'
    ]);
    $sno = 1;
    while ($r = $stmt->fetch()) {
        fputcsv($out, [
            $sno++,
            $r['name'] ?? '',
            $r['user_id'] ?? '',
            $r['fincert'] ?? '',
            $r['region'] ?? '',
            $r['school_name'] ?? '',
            $r['designation'] ?? '',
            $r['mobile'] ?? '',
            $r['email'] ?? '',
            (int)($r['is_day1_checked_in'] ?? 0) === 1 ? 'Inside Gate' : 'Pending',
            !empty($r['day1_checked_in_at']) ? formatIST($r['day1_checked_in_at'], 'd M Y, h:i:s A') : 'N/A',
            (int)($r['is_day2_checked_in'] ?? 0) === 1 ? 'Inside Gate' : 'Pending',
            !empty($r['day2_checked_in_at']) ? formatIST($r['day2_checked_in_at'], 'd M Y, h:i:s A') : 'N/A',
            !empty($r['created_at']) ? formatIST($r['created_at'], 'd M Y, h:i:s A') : 'N/A'
        ]);
    }
    fclose($out);
    exit;
}
if (isset($_GET['export']) && $_GET['export'] === 'gift_csv') {
    if (!$isSuperAdmin && !$isCounter) {
        header('Location: admin.php?tab=gift&msg=permission_denied');
        exit;
    }

    if ($isCounter) {
        $stmt = $pdo->prepare("SELECT * FROM `gift_distribution` WHERE counter_id = :cid ORDER BY name ASC");
        $stmt->execute([':cid' => $counterId]);
        $filenameRegion = preg_replace('/[^a-z0-9]+/i', '_', strtolower($counterName ?: 'counter'));
        $filename = 'coe_kit_distribution_' . $filenameRegion . '_' . date('Y-m-d_His') . '.csv';
    } else {
        $dRegionFilter = trim((string)($_GET['dregion'] ?? ''));
        $dCounterFilter = (int)($_GET['dcounter'] ?? 0);
        $sql = "SELECT * FROM `gift_distribution` WHERE 1=1";
        $p = [];
        if ($dCounterFilter > 0) {
            $sql .= " AND counter_id = :dcid";
            $p[':dcid'] = $dCounterFilter;
        }
        if ($dRegionFilter !== '') {
            $sql .= " AND region = :reg";
            $p[':reg'] = $dRegionFilter;
        }
        $sql .= " ORDER BY name ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($p);
        $filename = 'coe_kit_distribution_all_' . date('Y-m-d_His') . '.csv';
    }

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    $out = fopen('php://output', 'w');
    fputcsv($out, [
        'S.No', 'Full Name', 'Register Id', 'FinCert ID (Your Id no.)', 'Region', 'School Name', 'Designation', 'Mobile Number', 'Email',
        'Kit Status', 'Handover Timestamp (IST)', 'Handed Over By', 'Counter Region', 'Created At (IST)'
    ]);
    $sno = 1;
    while ($r = $stmt->fetch()) {
        fputcsv($out, [
            $sno++,
            $r['name'] ?? '',
            $r['user_id'] ?? '',
            $r['fincert'] ?? '',
            $r['region'] ?? '',
            $r['school_name'] ?? '',
            $r['designation'] ?? '',
            $r['mobile'] ?? '',
            $r['email'] ?? '',
            (int)($r['is_gift_collected'] ?? 0) === 1 ? 'Kit Collected' : 'Pending',
            !empty($r['gift_collected_at']) ? formatIST($r['gift_collected_at'], 'd M Y, h:i:s A') : 'N/A',
            $r['handed_over_by'] ?? '',
            $r['counter_region'] ?? '',
            !empty($r['created_at']) ? formatIST($r['created_at'], 'd M Y, h:i:s A') : 'N/A'
        ]);
    }
    fclose($out);
    exit;
}

// =========================================================================
// Metrics (2-Day Event Gate Tracking & Gift Distribution)
// =========================================================================
$d1Count = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors` WHERE is_day1_checked_in = 1")->fetchColumn();
$d2Count = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors` WHERE is_day2_checked_in = 1")->fetchColumn();
$totalVisitors = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors`")->fetchColumn();
$pendingBothCount = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors` WHERE is_day1_checked_in = 0 AND is_day2_checked_in = 0")->fetchColumn();

$d1Pending = max(0, $totalVisitors - $d1Count);
$d2Pending = max(0, $totalVisitors - $d2Count);
$d1Rate    = $totalVisitors > 0 ? round(($d1Count / $totalVisitors) * 100) : 0;
$d2Rate    = $totalVisitors > 0 ? round(($d2Count / $totalVisitors) * 100) : 0;

// Legacy aliases for backward safety
$checkedInCount   = $d1Count;
$gatePending      = $d1Pending;
$gateRate         = $d1Rate;

try {
    if ($isCounter) {
        $dmStmt = $pdo->prepare("
            SELECT COUNT(*) AS total, 
                   SUM(is_gift_collected=1) AS given, 
                   SUM(is_gift_collected=0) AS pend 
            FROM `gift_distribution` 
            WHERE counter_id = :cid
        ");
        $dmStmt->execute([':cid' => $counterId]);
        $dm = $dmStmt->fetch();
        if (!$dm || $dm['total'] === null) {
            $dm = ['total' => 0, 'given' => 0, 'pend' => 0];
        }
    } else {
        $dm = $pdo->query("SELECT COUNT(*) AS total, SUM(is_gift_collected=1) AS given, SUM(is_gift_collected=0) AS pend FROM `gift_distribution`")->fetch();
    }
} catch (\Throwable $e) {
    $dm = ['total' => 0, 'given' => 0, 'pend' => 0];
}
$totalGiftElig = (int)($dm['total'] ?? 0);
$giftsGiven    = (int)($dm['given'] ?? 0);
$giftsPending  = (int)($dm['pend']  ?? 0);
$giftRate      = $totalGiftElig > 0 ? round(($giftsGiven / $totalGiftElig) * 100) : 0;

// Counters Management & Filter List (Super Admin & Combined Counters)
$countersList = [];
$totalCountersCount = 0;
$activeCountersCount = 0;
$totalCountersVisitors = 0;
$totalCountersGiven = 0;
$totalCountersPending = 0;

try {
    $countersStmt = $pdo->query("
        SELECT c.id, c.name, c.code, c.username, c.name_range, c.is_active, c.last_login,
               a.id AS admin_id, a.status AS admin_status,
               COALESCE(g_agg.total_visitors, 0) AS total_visitors,
               COALESCE(g_agg.kits_distributed, 0) AS kits_distributed,
               COALESCE(g_agg.kits_pending, 0) AS kits_pending,
               (
                   SELECT GROUP_CONCAT(NULLIF(TRIM(cr.region), '') ORDER BY cr.region SEPARATOR ', ')
                   FROM `counter_regions` cr
                   WHERE cr.counter_id = c.id AND TRIM(cr.region) != ''
               ) AS regions_covered
        FROM `counters` c
        LEFT JOIN `admins` a ON (a.username = c.username)
        LEFT JOIN (
            SELECT counter_id,
                   COUNT(*) AS total_visitors,
                   SUM(CASE WHEN is_gift_collected = 1 THEN 1 ELSE 0 END) AS kits_distributed,
                   SUM(CASE WHEN is_gift_collected = 0 THEN 1 ELSE 0 END) AS kits_pending
            FROM `gift_distribution`
            WHERE counter_id IS NOT NULL AND counter_id > 0
            GROUP BY counter_id
        ) g_agg ON (g_agg.counter_id = c.id)
        WHERE c.is_active = 1 AND c.code != 'helpdesk'
        ORDER BY c.id ASC
    ");
    $countersList = $countersStmt ? $countersStmt->fetchAll() : [];
    $totalCountersCount = count($countersList);
    foreach ($countersList as $cRow) {
        if ((int)($cRow['is_active'] ?? 1) === 1) {
            $activeCountersCount++;
        }
        $totalCountersVisitors += (int)($cRow['total_visitors'] ?? 0);
        $totalCountersGiven    += (int)($cRow['kits_distributed'] ?? 0);
        $totalCountersPending  += (int)($cRow['kits_pending'] ?? 0);
    }

    // Sanity check: sum of counter visitor counts must equal total visitors
    $totalDbVisitors = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors`")->fetchColumn();
    if ($totalCountersVisitors !== $totalDbVisitors) {
        error_log("[WARNING] Sanity check mismatch: Sum of counter visitor counts ($totalCountersVisitors) does not match total allowed visitors ($totalDbVisitors).");
    }
} catch (\Throwable $e) {
    error_log("Failed to query counters: " . $e->getMessage());
}

// =========================================================================
// Regions & Filters (Tab 1 & Tab 2)
// Safety-net query: Explicit utf8mb4_unicode_ci collations on both sides of UNION
// Wrapped in try/catch to ensure zero fatal error crashes
// =========================================================================
$allRegions = [];
try {
    $regionsStmt = $pdo->query("
        SELECT DISTINCT region FROM (
            SELECT region COLLATE utf8mb4_unicode_ci AS region 
            FROM `allowed_visitors` 
            WHERE region IS NOT NULL AND TRIM(region) != ''
            UNION 
            SELECT region COLLATE utf8mb4_unicode_ci AS region 
            FROM `gift_distribution` 
            WHERE region IS NOT NULL AND TRIM(region) != ''
        ) AS combined 
        WHERE region IS NOT NULL AND TRIM(region) != '' 
        ORDER BY region ASC
    ");
    $rawRegions = $regionsStmt ? $regionsStmt->fetchAll(PDO::FETCH_COLUMN) : [];
} catch (\Throwable $e) {
    error_log("Failed to fetch distinct regions with UNION: " . $e->getMessage());
    try {
        $rawRegions = $pdo->query("
            SELECT DISTINCT region 
            FROM `allowed_visitors` 
            WHERE region IS NOT NULL AND TRIM(region) != '' 
            ORDER BY region ASC
        ")->fetchAll(PDO::FETCH_COLUMN);
    } catch (\Throwable $t) {
        error_log("Fallback distinct regions query failed: " . $t->getMessage());
        $rawRegions = [];
    }
}

// Normalize case and trim whitespace (e.g. 'Pune' vs 'PUNE' or extra spaces)
$normalizedRegions = [];
foreach ($rawRegions as $reg) {
    $clean = trim((string)$reg);
    if ($clean === '' || $clean === '—' || $clean === '-') continue;
    $key = mb_strtolower($clean, 'UTF-8');
    if (!isset($normalizedRegions[$key])) {
        $normalizedRegions[$key] = $clean;
    }
}
$allRegions = array_values($normalizedRegions);
natcasesort($allRegions);
$allRegions = array_values($allRegions);

try {
    $gateRegionCountsStmt = $pdo->query("
        SELECT region, COUNT(*) as cnt 
        FROM `allowed_visitors` 
        WHERE region IS NOT NULL AND TRIM(region) != '' 
        GROUP BY region
    ");
    $gateRegionCounts = $gateRegionCountsStmt ? $gateRegionCountsStmt->fetchAll(PDO::FETCH_KEY_PAIR) : [];
} catch (\Throwable $e) {
    error_log("Failed to fetch gate region counts: " . $e->getMessage());
    $gateRegionCounts = [];
}

try {
    $giftRegionCountsStmt = $pdo->query("
        SELECT region, COUNT(*) as cnt 
        FROM `gift_distribution` 
        WHERE region IS NOT NULL AND TRIM(region) != '' 
        GROUP BY region
    ");
    $giftRegionCounts = $giftRegionCountsStmt ? $giftRegionCountsStmt->fetchAll(PDO::FETCH_KEY_PAIR) : [];
} catch (\Throwable $e) {
    error_log("Failed to fetch gift region counts: " . $e->getMessage());
    $giftRegionCounts = [];
}

// Pagination config
$perPage = 50;

// =========================================================================
// Gate Visitors (Tab 1 - 2-Day Event Filters & Pagination)
// =========================================================================
$gSearch = trim((string)($_GET['gsearch'] ?? ''));
$gFilter = trim((string)($_GET['gfilter'] ?? 'all'));
$gRegion = trim((string)($_GET['gregion'] ?? ''));
$gPage   = max(1, (int)($_GET['gpage'] ?? 1));

$gSql = "SELECT * FROM `allowed_visitors` WHERE 1=1";
$gP   = [];
if ($gSearch !== '') {
    $gSql .= " AND (name LIKE :s1 OR mobile LIKE :s2 OR user_id LIKE :s3 OR fincert LIKE :s4 OR region LIKE :s5 OR school_name LIKE :s6)";
    $gP[':s1'] = $gP[':s2'] = $gP[':s3'] = $gP[':s4'] = $gP[':s5'] = $gP[':s6'] = "%$gSearch%";
}
if ($gRegion !== '') {
    $gSql .= " AND region = :greg";
    $gP[':greg'] = $gRegion;
}
if ($gFilter === 'day1') {
    $gSql .= " AND is_day1_checked_in = 1";
} elseif ($gFilter === 'day2') {
    $gSql .= " AND is_day2_checked_in = 1";
} elseif ($gFilter === 'pending_both') {
    $gSql .= " AND is_day1_checked_in = 0 AND is_day2_checked_in = 0";
} elseif ($gFilter === 'checked_in') {
    $gSql .= " AND (is_day1_checked_in = 1 OR is_day2_checked_in = 1)";
} elseif ($gFilter === 'pending') {
    $gSql .= " AND is_day1_checked_in = 0";
}

$gSql .= " ORDER BY 
    CASE WHEN (is_day1_checked_in = 1 OR is_day2_checked_in = 1) THEN 0 ELSE 1 END ASC,
    GREATEST(
        COALESCE(CASE WHEN is_day1_checked_in = 1 THEN day1_checked_in_at END, '1970-01-01 00:00:00'),
        COALESCE(CASE WHEN is_day2_checked_in = 1 THEN day2_checked_in_at END, '1970-01-01 00:00:00')
    ) DESC,
    name ASC";

$gStmt = $pdo->prepare($gSql);
$gStmt->execute($gP);
$gateVisitors = $gStmt->fetchAll();
sortGateVisitors($gateVisitors);

$totalGateRows  = count($gateVisitors);
$totalGatePages = max(1, (int)ceil($totalGateRows / $perPage));
if ($gPage > $totalGatePages) {
    $gPage = $totalGatePages;
}
$gateOffset          = ($gPage - 1) * $perPage;
$gateVisibleVisitors = array_slice($gateVisitors, $gateOffset, $perPage);

// =========================================================================
// Gift Visitors (Tab 2 - Filters & Pagination)
// =========================================================================
$dSearch  = trim((string)($_GET['dsearch'] ?? ''));
$dFilter  = trim((string)($_GET['dfilter'] ?? 'all'));
$dCounter = isset($_GET['dcounter']) ? (int)$_GET['dcounter'] : 0;
$dRegion  = trim((string)($_GET['dregion'] ?? ''));
$dPage    = max(1, (int)($_GET['dpage'] ?? 1));

// For counter staff: determine regions covered by this counter
$counterAllowedRegions = [];
if ($isCounter) {
    $crStmt = $pdo->prepare("SELECT region FROM `counter_regions` WHERE counter_id = :cid ORDER BY region ASC");
    $crStmt->execute([':cid' => $counterId]);
    $counterAllowedRegions = array_filter(array_map('trim', $crStmt->fetchAll(PDO::FETCH_COLUMN)));
}

$dSql = "SELECT g.*, c.name AS assigned_counter_name, c.name_range AS assigned_counter_range
         FROM `gift_distribution` g
         LEFT JOIN `counters` c ON c.id = g.counter_id
         WHERE 1=1";
$dP   = [];
if ($dSearch !== '') {
    $dSql .= " AND (g.name LIKE :s1 OR g.mobile LIKE :s2 OR g.user_id LIKE :s3 OR g.fincert LIKE :s4 OR g.region LIKE :s5 OR g.school_name LIKE :s6)";
    $dP[':s1'] = $dP[':s2'] = $dP[':s3'] = $dP[':s4'] = $dP[':s5'] = $dP[':s6'] = "%$dSearch%";
}

if ($isCounter) {
    $dSql .= " AND g.counter_id = :mycid";
    $dP[':mycid'] = $counterId;
    if ($dRegion !== '') {
        $dSql .= " AND g.region = :dreg";
        $dP[':dreg'] = $dRegion;
    }
} else {
    if ($dCounter > 0) {
        $dSql .= " AND g.counter_id = :dcid";
        $dP[':dcid'] = $dCounter;
    }
    if ($dRegion !== '') {
        $dSql .= " AND g.region = :dreg";
        $dP[':dreg'] = $dRegion;
    }
}

if ($dFilter === 'collected') {
    $dSql .= " AND g.is_gift_collected = 1";
} elseif ($dFilter === 'pending') {
    $dSql .= " AND g.is_gift_collected = 0";
}

$dSql .= " ORDER BY 
    CASE WHEN g.is_gift_collected = 1 THEN 0 ELSE 1 END ASC,
    COALESCE(g.gift_collected_at, '1970-01-01 00:00:00') DESC,
    g.name ASC";

$dStmt = $pdo->prepare($dSql);
$dStmt->execute($dP);
$giftVisitors = $dStmt->fetchAll();
sortGiftVisitors($giftVisitors);

$totalGiftRows  = count($giftVisitors);
$totalGiftPages = max(1, (int)ceil($totalGiftRows / $perPage));
if ($dPage > $totalGiftPages) {
    $dPage = $totalGiftPages;
}
$giftOffset          = ($dPage - 1) * $perPage;
$giftVisibleVisitors = array_slice($giftVisitors, $giftOffset, $perPage);

$isGate = $tab === 'gate';

// Helper function to render Gate Visitors Table Rows
if (!function_exists('renderGateTableRows')) {
function renderGateTableRows(array $gateVisitors, string $gFilter = '', string $gSearch = '', string $gRegion = '', int $gPage = 1, int $startIdx = 0): string
{
    ob_start();
    if (empty($gateVisitors)): ?>
        <tr class="tr-empty">
            <td colspan="8" style="text-align:center;padding:3rem;color:var(--text-muted);">
                <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:8px;opacity:0.4;"></i>
                No matching visitors found.
            </td>
        </tr>
    <?php else:
        $extraParams = '';
        if (!empty($gFilter) && $gFilter !== 'all') $extraParams .= '&gfilter=' . urlencode($gFilter);
        if (!empty($gSearch)) $extraParams .= '&gsearch=' . urlencode($gSearch);
        if (!empty($gRegion)) $extraParams .= '&gregion=' . urlencode($gRegion);
        if ($gPage > 1) $extraParams .= '&gpage=' . urlencode((string)$gPage);

        foreach ($gateVisitors as $idx => $v): 
            $visitor = $v;
            $rawPhone = trim((string)($v['mobile'] ?? ''));
            $cleanPhone = preg_replace('/\D/', '', $rawPhone);
            $formattedPhone = strlen($cleanPhone) === 10
                ? substr($cleanPhone, 0, 5) . ' ' . substr($cleanPhone, 5)
                : htmlspecialchars($rawPhone);
            $schoolOrDesig = trim((string)($v['school_name'] ?? ''));
            if ($schoolOrDesig === '') {
                $schoolOrDesig = trim((string)($v['designation'] ?? 'Attendee'));
            }
        ?>
            <tr data-id="<?= (int)$v['id'] ?>"
                data-name="<?= htmlspecialchars($v['name']) ?>"
                data-d1-checked="<?= (int)($v['is_day1_checked_in'] ?? 0) ?>"
                data-d1-time="<?= htmlspecialchars($v['day1_checked_in_at'] ?? '') ?>"
                data-d2-checked="<?= (int)($v['is_day2_checked_in'] ?? 0) ?>"
                data-d2-time="<?= htmlspecialchars($v['day2_checked_in_at'] ?? '') ?>">
                <td class="td-id col-id">
                    <span class="id-badge">#<?= $startIdx + $idx + 1 ?></span>
                </td>
                <td class="td-name col-name">
                    <div class="guest-name"><?= htmlspecialchars($v['name']) ?></div>
                    <div class="guest-type" title="<?= htmlspecialchars($schoolOrDesig) ?>"><?= htmlspecialchars($schoolOrDesig) ?></div>
                </td>
                <td class="td-userid col-userid">
                    <span class="card-meta-label">Register Id</span>
                    <span class="user-id-badge" title="<?= htmlspecialchars($v['user_id'] ?: '—') ?>"><?= htmlspecialchars($v['user_id'] ?: '—') ?></span>
                </td>
                <td class="td-region col-region">
                    <span class="card-meta-label">Region</span>
                    <span class="region-badge"><?= htmlspecialchars($v['region'] ?: '—') ?></span>
                </td>
                <td class="td-mobile col-mobile">
                    <?php if ($cleanPhone !== ''): ?>
                        <a href="tel:+91<?= htmlspecialchars($cleanPhone) ?>" class="mobile-badge-link" title="Call guest">
                            <i class="bi bi-telephone-fill"></i>
                            <span class="mobile-num">+91&nbsp;<?= htmlspecialchars($formattedPhone) ?></span>
                        </a>
                    <?php else: ?>
                        <span class="text-muted" style="font-size:0.82rem;">—</span>
                    <?php endif; ?>
                </td>
                <td class="td-status td-status-d1 col-status-d1">
                    <div class="status-card-inner">
                        <span class="card-status-label">Day 1</span>
                        <?php if ((int)($v['is_day1_checked_in'] ?? 0) === 1): ?>
                            <span class="status-pill pill-green">
                                <span class="pulse-dot"></span> Inside Gate
                            </span>
                            <?php if (!empty($v['day1_checked_in_at'])): ?>
                                <div class="status-timestamp">
                                    <i class="bi bi-clock-history text-success"></i>
                                    <?= htmlspecialchars(formatIST($v['day1_checked_in_at'], 'd M, h:i A')) ?>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="status-pill pill-amber">
                                <i class="bi bi-clock" style="font-size:0.7rem;"></i> Pending
                            </span>
                        <?php endif; ?>
                    </div>
                </td>
                <td class="td-status td-status-d2 col-status-d2">
                    <div class="status-card-inner">
                        <span class="card-status-label">Day 2</span>
                        <?php if ((int)($v['is_day2_checked_in'] ?? 0) === 1): ?>
                            <span class="status-pill pill-teal">
                                <span class="pulse-dot-teal"></span> Inside Gate
                            </span>
                            <?php if (!empty($v['day2_checked_in_at'])): ?>
                                <div class="status-timestamp">
                                    <i class="bi bi-clock-history" style="color:#0891b2;"></i>
                                    <?= htmlspecialchars(formatIST($v['day2_checked_in_at'], 'd M, h:i A')) ?>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="status-pill pill-amber">
                                <i class="bi bi-clock" style="font-size:0.7rem;"></i> Pending
                            </span>
                        <?php endif; ?>
                    </div>
                </td>
                <td class="td-actions col-actions">
                    <div class="action-btn-group">
                        <!-- Day 1 Action Button -->
                        <?php if ($visitor['is_day1_checked_in'] == 1): ?>
                            <a href="admin.php?tab=gate&action=reset_d1&id=<?= (int)$visitor['id'] ?><?= $extraParams ?>" 
                               class="btn-reset-row action-btn"
                               onclick="return confirm('Reset Day 1 for <?= htmlspecialchars(addslashes($visitor['name'])) ?>?');">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset D1
                            </a>
                        <?php else: ?>
                            <a href="admin.php?tab=gate&action=checkin_d1&id=<?= (int)$visitor['id'] ?><?= $extraParams ?>" 
                               class="btn-checkin-d1 action-btn">
                                <i class="bi bi-check-lg"></i> Day 1
                            </a>
                        <?php endif; ?>

                        <!-- Day 2 Action Button -->
                        <?php if ($visitor['is_day2_checked_in'] == 1): ?>
                            <a href="admin.php?tab=gate&action=reset_d2&id=<?= (int)$visitor['id'] ?><?= $extraParams ?>" 
                               class="btn-reset-row action-btn"
                               onclick="return confirm('Reset Day 2 for <?= htmlspecialchars(addslashes($visitor['name'])) ?>?');">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset D2
                            </a>
                        <?php else: ?>
                            <a href="admin.php?tab=gate&action=checkin_d2&id=<?= (int)$visitor['id'] ?><?= $extraParams ?>" 
                               class="btn-day2-action action-btn">
                                <i class="bi bi-check-lg"></i> Day 2
                            </a>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach;
    endif;
    return ob_get_clean();
}
}

// Helper function to render Gift Visitors Table Rows
if (!function_exists('renderGiftTableRows')) {
function renderGiftTableRows(array $giftVisitors, string $dFilter = '', string $dSearch = '', string $dRegion = '', int $dPage = 1, int $startIdx = 0, int $dCounter = 0): string
{
    ob_start();
    $isSuperAdmin = !empty($_SESSION['user_role']) && $_SESSION['user_role'] === 'super_admin';
    if (empty($giftVisitors)): ?>
        <tr class="tr-empty">
            <td colspan="8" style="text-align:center;padding:3rem;color:var(--text-muted);">
                <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:8px;opacity:0.4;"></i>
                No matching attendees found.
            </td>
        </tr>
    <?php else:
        $extraParams = '';
        if (!empty($dFilter) && $dFilter !== 'all') $extraParams .= '&dfilter=' . urlencode($dFilter);
        if (!empty($dSearch)) $extraParams .= '&dsearch=' . urlencode($dSearch);
        if (!empty($dRegion)) $extraParams .= '&dregion=' . urlencode($dRegion);
        if ($dCounter > 0) $extraParams .= '&dcounter=' . urlencode((string)$dCounter);
        if ($dPage > 1) $extraParams .= '&dpage=' . urlencode((string)$dPage);

        foreach ($giftVisitors as $idx => $v): 
            $rawPhone = trim((string)($v['mobile'] ?? ''));
            $cleanPhone = preg_replace('/\D/', '', $rawPhone);
            $formattedPhone = strlen($cleanPhone) === 10
                ? substr($cleanPhone, 0, 5) . ' ' . substr($cleanPhone, 5)
                : htmlspecialchars($rawPhone);
            $schoolOrDesig = trim((string)($v['school_name'] ?? ''));
            if ($schoolOrDesig === '') {
                $schoolOrDesig = trim((string)($v['designation'] ?? 'Attendee'));
            }
            $assignedCounter = trim((string)($v['assigned_counter_name'] ?? ''));
            if ($assignedCounter === '') {
                $assignedCounter = (!empty($v['region'])) ? ($v['region'] . ' Counter') : 'Help Desk';
            }
        ?>
            <tr data-id="<?= (int)$v['id'] ?>"
                data-name="<?= htmlspecialchars($v['name']) ?>"
                data-gift-collected="<?= (int)($v['is_gift_collected'] ?? 0) ?>"
                data-gift-time="<?= htmlspecialchars($v['gift_collected_at'] ?? '') ?>">
                <td class="td-id col-id">
                    <span class="id-badge">#<?= $startIdx + $idx + 1 ?></span>
                </td>
                <td class="td-name col-name">
                    <div class="guest-name"><?= htmlspecialchars($v['name']) ?></div>
                    <div class="guest-type" title="<?= htmlspecialchars($schoolOrDesig) ?>"><?= htmlspecialchars($schoolOrDesig) ?></div>
                </td>
                <td class="td-userid col-userid">
                    <span class="card-meta-label">Register Id</span>
                    <span class="user-id-badge" title="<?= htmlspecialchars($v['user_id'] ?: '—') ?>"><?= htmlspecialchars($v['user_id'] ?: '—') ?></span>
                </td>
                <td class="td-region col-region">
                    <span class="card-meta-label">Region &amp; Counter</span>
                    <span class="region-badge"><?= htmlspecialchars($v['region'] ?: '—') ?></span>
                    <div class="small text-muted" style="font-size:0.75rem;margin-top:3px;white-space:nowrap;">
                        <i class="bi bi-shop text-primary me-1"></i><strong><?= htmlspecialchars($assignedCounter) ?></strong>
                    </div>
                </td>
                <td class="td-mobile col-mobile">
                    <?php if ($cleanPhone !== ''): ?>
                        <a href="tel:+91<?= htmlspecialchars($cleanPhone) ?>" class="mobile-badge-link" title="Call guest">
                            <i class="bi bi-telephone-fill"></i>
                            <span class="mobile-num">+91&nbsp;<?= htmlspecialchars($formattedPhone) ?></span>
                        </a>
                    <?php else: ?>
                        <span class="text-muted" style="font-size:0.82rem;">—</span>
                    <?php endif; ?>
                </td>
                <td class="td-gift-status col-gift-status">
                    <div class="gift-status-wrap">
                        <span class="card-status-label">Kit Status</span>
                        <?php if ((int)$v['is_gift_collected'] === 1): ?>
                            <span class="status-pill pill-green">
                                <span class="pulse-dot"></span> Kit Collected
                            </span>
                        <?php else: ?>
                            <span class="status-pill pill-amber">
                                <i class="bi bi-clock" style="font-size:0.7rem;"></i> Pending
                            </span>
                        <?php endif; ?>
                    </div>
                </td>
                <td class="td-gift-time col-gift-time">
                    <div class="gift-time-wrap">
                        <span class="card-status-label">Handover Timestamp</span>
                        <?php if (!empty($v['gift_collected_at'])): ?>
                            <span class="gift-timestamp">
                                <i class="bi bi-clock-history text-success"></i>
                                <?= htmlspecialchars(formatIST($v['gift_collected_at'], 'd M, h:i A')) ?>
                            </span>
                            <?php if (!empty($v['handed_over_by'])): ?>
                                <div class="small text-muted" style="font-size:0.72rem;margin-top:3px;line-height:1.2;">
                                    <i class="bi bi-person-check text-primary"></i> <?= htmlspecialchars($v['handed_over_by']) ?>
                                    <?php if (!empty($v['counter_region'])): ?>
                                        &bull; <span class="text-secondary"><?= htmlspecialchars($v['counter_region']) ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="text-muted" style="font-size:0.8rem;">— Not Yet Handed Over —</span>
                        <?php endif; ?>
                    </div>
                </td>
                <td class="td-actions col-actions">
                    <div class="action-btn-group">
                        <?php if ((int)$v['is_gift_collected'] === 1): ?>
                            <span class="badge-claimed action-btn">
                                <i class="bi bi-check-circle-fill"></i> Kit Given
                            </span>
                            <a href="admin.php?tab=gift&action=reset_gift&id=<?= (int)$v['id'] ?><?= $extraParams ?>"
                               class="btn-reset-gift action-btn"
                               onclick="return confirm('Reset COE Kit status for <?= htmlspecialchars(addslashes($v['name'])) ?> back to Pending?');"
                               title="Reset COE Kit status">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset Kit
                            </a>
                        <?php else: ?>
                            <a href="admin.php?tab=gift&action=mark_given&id=<?= (int)$v['id'] ?><?= $extraParams ?>"
                               class="btn-mark-given action-btn"
                               onclick="return confirm('Confirm COE Kit handover for <?= htmlspecialchars(addslashes($v['name'])) ?>?');"
                               title="Mark COE Kit as given to attendee">
                                <i class="bi bi-box-seam"></i> Give Kit
                            </a>
                        <?php endif; ?>
                        <?php if ($isSuperAdmin): ?>
                            <button type="button" 
                                    class="action-btn"
                                    style="background:#f1f5f9;border:1px solid #cbd5e1;color:#334155;border-radius:6px;padding:6px 10px;font-size:0.78rem;font-weight:600;display:inline-flex;align-items:center;gap:4px;"
                                    onclick="openReassignModal(<?= (int)$v['id'] ?>, '<?= htmlspecialchars(addslashes($v['name'])) ?>', <?= (int)($v['counter_id'] ?? 0) ?>)"
                                    title="Reassign to another counter">
                                <i class="bi bi-arrow-left-right text-primary"></i> Move
                            </button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach;
    endif;
    return ob_get_clean();
}
}

// Helper function for responsive pagination controls
if (!function_exists('renderPagination')) {
function renderPagination(int $currentPage, int $totalPages, int $totalRows, int $perPage, string $tab, array $queryParams): string
{
    if ($totalRows === 0) {
        return '<div class="pagination-bar d-flex justify-content-between align-items-center flex-wrap gap-2 px-3 py-2.5 border-top bg-light-subtle small text-muted">' .
               '<div>Showing <strong>0</strong> visitors</div></div>';
    }

    $pageParam = ($tab === 'gate') ? 'gpage' : 'dpage';
    $startRow  = (($currentPage - 1) * $perPage) + 1;
    $endRow    = min($totalRows, $currentPage * $perPage);

    $buildUrl = function(int $p) use ($tab, $pageParam, $queryParams) {
        $params = array_merge($queryParams, ['tab' => $tab, $pageParam => $p]);
        return 'admin.php?' . http_build_query($params);
    };

    ob_start();
    ?>
    <div class="pagination-bar d-flex justify-content-between align-items-center flex-wrap gap-2 px-3 py-2.5 border-top bg-light-subtle">
        <div class="small text-muted">
            Showing <strong><?= number_format($startRow) ?> - <?= number_format($endRow) ?></strong> of <strong><?= number_format($totalRows) ?></strong> (Page <?= $currentPage ?> of <?= $totalPages ?>)
        </div>
        <?php if ($totalPages > 1): ?>
            <nav aria-label="Page navigation">
                <ul class="pagination pagination-sm mb-0 gap-1 flex-wrap">
                    <?php if ($currentPage > 1): ?>
                        <li class="page-item">
                            <a class="page-link rounded-2" href="<?= htmlspecialchars($buildUrl(1)) ?>" title="First page">&laquo; First</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link rounded-2" href="<?= htmlspecialchars($buildUrl($currentPage - 1)) ?>" title="Previous page">&lsaquo; Prev</a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link rounded-2">&laquo; First</span></li>
                        <li class="page-item disabled"><span class="page-link rounded-2">&lsaquo; Prev</span></li>
                    <?php endif; ?>

                    <?php
                    $startPage = max(1, $currentPage - 2);
                    $endPage   = min($totalPages, $currentPage + 2);
                    if ($startPage > 1) {
                        echo '<li class="page-item disabled"><span class="page-link rounded-2 border-0 bg-transparent">…</span></li>';
                    }
                    for ($p = $startPage; $p <= $endPage; $p++):
                    ?>
                        <li class="page-item <?= $p === $currentPage ? 'active' : '' ?>">
                            <a class="page-link rounded-2 fw-semibold" href="<?= htmlspecialchars($buildUrl($p)) ?>"><?= $p ?></a>
                        </li>
                    <?php endfor;
                    if ($endPage < $totalPages) {
                        echo '<li class="page-item disabled"><span class="page-link rounded-2 border-0 bg-transparent">…</span></li>';
                    }
                    ?>

                    <?php if ($currentPage < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link rounded-2" href="<?= htmlspecialchars($buildUrl($currentPage + 1)) ?>" title="Next page">Next &rsaquo;</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link rounded-2" href="<?= htmlspecialchars($buildUrl($totalPages)) ?>" title="Last page">Last &raquo;</a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link rounded-2">Next &rsaquo;</span></li>
                        <li class="page-item disabled"><span class="page-link rounded-2">Last &raquo;</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
}

// Live AJAX Polling Endpoint
if (isset($_GET['ajax_live'])) {
    if ($tab === 'counters') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'tab' => 'counters']);
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    $rowsHtml = $isGate 
        ? renderGateTableRows($gateVisibleVisitors, $gFilter, $gSearch, $gRegion, $gPage, $gateOffset)
        : renderGiftTableRows($giftVisibleVisitors, $dFilter, $dSearch, $dRegion, $dPage, $giftOffset, $dCounter);

    echo json_encode([
        'success'      => true,
        'tab'          => $tab,
        'count'        => count($isGate ? $gateVisitors : $giftVisitors),
        'visibleCount' => count($isGate ? $gateVisibleVisitors : $giftVisibleVisitors),
        'startOffset'  => $isGate ? $gateOffset : $giftOffset,
        'rowsHtml'     => $rowsHtml,
        'metrics'      => [
            'totalVisitors'     => $totalVisitors,
            'd1Count'           => $d1Count,
            'd1Rate'            => $d1Rate,
            'd2Count'           => $d2Count,
            'd2Rate'            => $d2Rate,
            'pendingBothCount'  => $pendingBothCount,
            'totalGiftElig'     => $totalGiftElig,
            'giftsGiven'        => $giftsGiven,
            'giftRate'          => $giftRate,
            'giftsPending'      => $giftsPending,
        ]
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#0f1c30">
    <title><?= $tab === 'counters' ? 'Regional Counters' : ($isGate ? 'Gate Entry Live Tracking' : 'COE Kit Distribution Control') ?> | EventMS Admin</title>
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2310b981'%3E%3Cpath d='M12 2L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-3zm-2 15l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z'/%3E%3C/svg%3E">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        /* ========================================================
           RESET & ROOT
           ======================================================== */
        *, *::before, *::after { box-sizing: border-box; }

        :root {
            --navy:           #0f1c30;
            --navy-light:     #162844;
            --navy-border:    rgba(255,255,255,0.08);
            --blue:           #1d58d8;
            --blue-hover:     #1545b0;
            --blue-glow:      rgba(29,88,216,0.35);
            --cyan:           #38bdf8;
            --page-bg:        #f1f5f9;
            --card-bg:        #ffffff;
            --border-light:   #e2e8f0;
            --text-dark:      #0f172a;
            --text-body:      #1e293b;
            --text-muted:     #64748b;
            --text-sidebar:   #94a3b8;
            --success:        #10b981;
            --warning:        #f59e0b;
            --danger:         #ef4444;
            --purple:         #8b5cf6;
            --sidebar-w:      260px;
            --topbar-h:       64px;
            --radius-card:    14px;
            --radius-pill:    9999px;
            --shadow-card:    0 1px 3px rgba(15,28,48,0.06), 0 4px 16px rgba(15,28,48,0.06);
            --shadow-sidebar: 4px 0 24px rgba(0,0,0,0.18);
            --transition:     all 0.2s ease;
            --sat:            env(safe-area-inset-top, 0px);
            --sab:            env(safe-area-inset-bottom, 0px);
            --sal:            env(safe-area-inset-left, 0px);
            --sar:            env(safe-area-inset-right, 0px);
        }

        html, body {
            min-height: 100%;
            height: auto;
            margin: 0;
            padding: 0;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: var(--page-bg);
            color: var(--text-body);
            -webkit-font-smoothing: antialiased;
            overflow-x: hidden;
            width: 100%;
            max-width: 100vw;
        }

        /* ========================================================
           APP SHELL: Sidebar + Main
           ======================================================== */
        .app-shell {
            display: flex;
            min-height: 100vh;
            min-height: 100dvh;
            width: 100%;
            overflow-x: hidden;
        }

        /* ========================================================
           SIDEBAR
           ======================================================== */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-w);
            height: 100vh;
            height: 100dvh;
            max-height: 100dvh;
            background: var(--navy);
            display: flex;
            flex-direction: column;
            z-index: 200;
            box-shadow: var(--shadow-sidebar);
            transition: transform 0.28s cubic-bezier(0.4,0,0.2,1);
            overflow: hidden;
            padding-top: max(0px, env(safe-area-inset-top, 0px));
        }

        /* Brand Block */
        .sidebar-brand {
            flex-shrink: 0;
            padding: 1.25rem 1.25rem 1rem;
            border-bottom: 1px solid var(--navy-border);
            display: flex;
            align-items: center;
            gap: 12px;
            min-height: var(--topbar-h);
        }

        .brand-icon {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            background: rgba(56,189,248,0.15);
            border: 1.5px solid rgba(56,189,248,0.35);
            color: var(--cyan);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            flex-shrink: 0;
            box-shadow: 0 0 12px rgba(56,189,248,0.2);
        }

        .brand-text {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }

        .brand-text strong {
            font-size: 0.95rem;
            font-weight: 800;
            color: #ffffff;
            letter-spacing: -0.3px;
        }

        .brand-text span {
            font-size: 0.72rem;
            color: var(--text-sidebar);
            display: flex;
            align-items: center;
            gap: 5px;
            margin-top: 2px;
        }

        .live-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--success);
            box-shadow: 0 0 6px var(--success);
            animation: livePulse 2s infinite;
            flex-shrink: 0;
        }

        @keyframes livePulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(1.3); }
        }

        /* Scrollable navigation area in sidebar */
        .sidebar-nav-scroll {
            flex: 1 1 auto;
            overflow-y: auto;
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
            padding-bottom: 1rem;
        }
        .sidebar-nav-scroll::-webkit-scrollbar { width: 4px; }
        .sidebar-nav-scroll::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }

        /* Nav Sections */
        .sidebar-section {
            padding: 1.1rem 0.85rem 0.5rem;
        }

        .sidebar-section-label {
            font-size: 0.65rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #475569;
            padding: 0 0.5rem;
            margin-bottom: 0.4rem;
        }

        /* Nav Item */
        .nav-item-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.65rem 0.75rem;
            border-radius: 10px;
            text-decoration: none;
            color: var(--text-sidebar);
            font-size: 0.875rem;
            font-weight: 600;
            transition: var(--transition);
            position: relative;
            margin-bottom: 2px;
        }

        .nav-item-link:hover {
            background: rgba(255,255,255,0.07);
            color: #ffffff;
        }

        .nav-item-link.active {
            background: rgba(29,88,216,0.22);
            color: #ffffff;
            box-shadow: inset 3px 0 0 var(--blue);
        }

        .nav-item-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 8px;
            bottom: 8px;
            width: 3px;
            background: var(--blue);
            border-radius: 0 3px 3px 0;
        }

        .nav-icon {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            flex-shrink: 0;
            background: rgba(255,255,255,0.06);
            transition: var(--transition);
        }

        .nav-item-link.active .nav-icon {
            background: rgba(29,88,216,0.35);
            color: var(--cyan);
        }

        .nav-item-link:hover .nav-icon {
            background: rgba(255,255,255,0.1);
        }

        .nav-label { flex: 1; }

        .nav-badge {
            font-size: 0.65rem;
            font-weight: 800;
            padding: 0.15rem 0.5rem;
            border-radius: var(--radius-pill);
            background: rgba(255,255,255,0.1);
            color: #cbd5e1;
            letter-spacing: 0.3px;
        }

        .nav-item-link.active .nav-badge {
            background: rgba(29,88,216,0.4);
            color: var(--cyan);
        }

        /* Sidebar Divider */
        .sidebar-divider {
            border: none;
            border-top: 1px solid var(--navy-border);
            margin: 0.5rem 0.85rem;
        }

        /* Sidebar Bottom: Admin Profile + Logout pinned */
        .sidebar-bottom {
            flex-shrink: 0;
            margin-top: auto;
            padding: 0.85rem 0.85rem calc(16px + env(safe-area-inset-bottom, 0px));
            border-top: 1px solid var(--navy-border);
            background: var(--navy);
        }

        .admin-profile-card {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px;
            padding: 0.75rem;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 0.65rem;
        }

        .admin-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--blue), #7c3aed);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            color: #ffffff;
            font-weight: 700;
            flex-shrink: 0;
        }

        .admin-info strong {
            display: block;
            font-size: 0.82rem;
            font-weight: 700;
            color: #ffffff;
        }

        .role-pill {
            display: inline-flex;
            align-items: center;
            padding: 0.15rem 0.55rem;
            border-radius: var(--radius-pill);
            font-size: 0.65rem;
            font-weight: 800;
            letter-spacing: 0.3px;
            line-height: 1.2;
        }

        .role-pill-super {
            background: rgba(139, 92, 246, 0.25);
            color: #c4b5fd;
            border: 1px solid rgba(139, 92, 246, 0.4);
        }

        .role-pill-guard {
            background: rgba(16, 185, 129, 0.22);
            color: #6ee7b7;
            border: 1px solid rgba(16, 185, 129, 0.35);
        }

        .btn-logout-sidebar {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 0.55rem 1rem;
            border-radius: 10px;
            background: rgba(239,68,68,0.12);
            border: 1px solid rgba(239,68,68,0.25);
            color: #fca5a5;
            font-size: 0.82rem;
            font-weight: 700;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
        }

        .btn-logout-sidebar:hover {
            background: rgba(239,68,68,0.25);
            border-color: rgba(239,68,68,0.5);
            color: #ffffff;
        }

        /* ========================================================
           MAIN PANEL (Right)
           ======================================================== */
        .main-panel {
            margin-left: var(--sidebar-w);
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            min-height: 100dvh;
            min-width: 0;
            width: calc(100% - var(--sidebar-w));
            max-width: 100%;
        }

        /* ========================================================
           TOP NAVBAR
           ======================================================== */
        .topbar {
            min-height: var(--topbar-h);
            height: auto;
            background: var(--card-bg);
            border-bottom: 1px solid var(--border-light);
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            gap: 12px;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 1px 3px rgba(15,28,48,0.04);
        }

        /* Mobile hamburger */
        .sidebar-toggle {
            display: none;
            width: 36px;
            height: 36px;
            border: 1.5px solid var(--border-light);
            border-radius: 9px;
            background: #ffffff;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text-dark);
            font-size: 1.1rem;
            flex-shrink: 0;
            transition: var(--transition);
        }

        .sidebar-toggle:hover { background: var(--page-bg); }

        .topbar-text-group {
            display: flex;
            flex-direction: column;
            line-height: 1.25;
            min-width: 0;
        }

        .topbar-heading-wrap {
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 0;
        }

        .topbar-heading-wrap strong {
            font-size: 1.05rem;
            font-weight: 800;
            color: var(--text-dark);
            letter-spacing: -0.2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .topbar-subtitle {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin-top: 2px;
        }

        .topbar-actions {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-topbar {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 0.45rem 0.9rem;
            border-radius: 9px;
            font-size: 0.82rem;
            font-weight: 700;
            text-decoration: none;
            border: 1.5px solid transparent;
            cursor: pointer;
            transition: var(--transition);
            white-space: nowrap;
        }

        .btn-topbar-ghost {
            background: #ffffff;
            border-color: var(--border-light);
            color: var(--text-body);
        }

        .btn-topbar-ghost:hover {
            background: var(--page-bg);
            border-color: #94a3b8;
            color: var(--text-dark);
        }

        .btn-topbar-primary {
            background: var(--blue);
            border-color: var(--blue);
            color: #ffffff;
            box-shadow: 0 2px 10px var(--blue-glow);
        }

        .btn-topbar-primary:hover {
            background: var(--blue-hover);
            border-color: var(--blue-hover);
            color: #ffffff;
        }

        .btn-topbar-danger {
            background: #fef2f2;
            border-color: #fecaca;
            color: #dc2626;
        }

        .btn-topbar-danger:hover {
            background: #fee2e2;
            border-color: #f87171;
            color: #b91c1c;
        }

        /* ========================================================
           CONTENT BODY
           ======================================================== */
        .content-body {
            padding: 1.5rem;
            flex: 1;
        }

        /* ========================================================
           METRIC CARDS
           ======================================================== */
        .metrics-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .metric-card {
            background: var(--card-bg);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-card);
            padding: 1.1rem 1.25rem;
            box-shadow: var(--shadow-card);
            display: flex;
            flex-direction: column;
            gap: 4px;
            position: relative;
            overflow: hidden;
            transition: var(--transition);
        }

        .metric-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(15,28,48,0.1);
        }

        .metric-card::after {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
        }

        .mc-blue::after   { background: var(--blue); }
        .mc-green::after  { background: var(--success); }
        .mc-teal::after   { background: #0891b2; }
        .mc-purple::after { background: var(--purple); }
        .mc-amber::after  { background: var(--warning); }

        .metric-label {
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .metric-icon {
            width: 28px;
            height: 28px;
            border-radius: 7px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
        }

        .mi-blue   { background: rgba(29,88,216,0.1);  color: var(--blue); }
        .mi-green  { background: rgba(16,185,129,0.1); color: var(--success); }
        .mi-teal   { background: rgba(8,145,178,0.12); color: #0891b2; }
        .mi-purple { background: rgba(139,92,246,0.1); color: var(--purple); }
        .mi-amber  { background: rgba(245,158,11,0.1); color: var(--warning); }

        .metric-value {
            font-size: 1.9rem;
            font-weight: 800;
            color: var(--text-dark);
            line-height: 1;
            margin-top: 2px;
        }

        .metric-sub {
            font-size: 0.75rem;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .rate-pill {
            display: inline-flex;
            align-items: center;
            padding: 0.1rem 0.45rem;
            border-radius: var(--radius-pill);
            font-size: 0.65rem;
            font-weight: 800;
        }

        .rate-green  { background: #dcfce7; color: #166534; }
        .rate-teal   { background: #cffafe; color: #0e7490; }
        .rate-purple { background: #ede9fe; color: #5b21b6; }

        .mini-bar {
            height: 3px;
            background: var(--border-light);
            border-radius: var(--radius-pill);
            overflow: hidden;
            margin-top: 6px;
        }

        .mini-bar-fill {
            height: 100%;
            border-radius: var(--radius-pill);
            transition: width 0.6s ease;
        }

        /* ========================================================
           CONTENT CARD (Table Container)
           ======================================================== */
        .content-card {
            background: var(--card-bg);
            border: 1px solid var(--border-light);
            border-radius: var(--radius-card);
            box-shadow: var(--shadow-card);
            overflow: hidden;
        }

        .content-card-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border-light);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.75rem;
            background: #fafbfc;
        }

        .content-card-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--text-dark);
        }

        .card-icon-dot {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
        }

        /* ========================================================
           FILTER BAR & TOOLBAR
           ======================================================== */
        .filter-bar {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            background: #ffffff;
        }

        .filter-form {
            display: flex;
            flex-direction: column;
            gap: 12px;
            width: 100%;
        }

        .filter-search-row {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            width: 100%;
            max-width: 100%;
        }

        .search-field-wrap {
            position: relative;
            flex: 1 1 280px;
            min-width: 220px;
        }

        .search-field-wrap i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 0.95rem;
            pointer-events: none;
        }

        .search-field {
            width: 100%;
            height: 40px;
            border: 1.5px solid var(--border-light);
            border-radius: 8px;
            padding: 0 0.85rem 0 2.4rem;
            font-size: 14px;
            color: var(--text-dark);
            background: var(--card-bg);
            outline: none;
            transition: var(--transition);
            box-sizing: border-box;
        }

        .search-field:focus {
            border-color: var(--blue);
            box-shadow: 0 0 0 3px rgba(29,88,216,0.12);
        }

        .region-select-wrap {
            width: 180px;
            flex: 0 0 180px;
        }

        .region-select {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-dark);
            border-radius: 8px;
            border: 1.5px solid var(--border-light);
            height: 40px;
            width: 100%;
            box-sizing: border-box;
            background-color: var(--card-bg);
            padding: 0 0.75rem;
        }

        .region-select:focus {
            border-color: var(--blue);
            box-shadow: 0 0 0 3px rgba(29,88,216,0.12);
        }

        .filter-submit {
            height: 40px;
            padding: 0 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            border: none;
            background: var(--blue);
            color: #ffffff;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: var(--transition);
            white-space: nowrap;
            flex-shrink: 0;
            box-sizing: border-box;
        }

        .filter-submit:hover { background: var(--blue-hover); }

        .filter-clear {
            height: 40px;
            padding: 0 14px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            border: 1.5px solid var(--border-light);
            background: #ffffff;
            color: var(--text-muted);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: var(--transition);
            white-space: nowrap;
            flex-shrink: 0;
            box-sizing: border-box;
        }

        .filter-clear:hover { background: var(--page-bg); color: var(--text-dark); }

        .filter-btn-group {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
            width: 100%;
        }

        .filter-btn {
            height: 36px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0 14px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            border: 1.5px solid var(--border-light);
            background: #ffffff;
            color: var(--text-muted);
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            white-space: nowrap;
            flex-shrink: 0;
            box-sizing: border-box;
        }

        .filter-btn:hover {
            background: var(--page-bg);
            color: var(--text-dark);
        }

        .filter-btn.active-all    { background: var(--navy); border-color: var(--navy); color: #ffffff; }
        .filter-btn.active-green  { background: var(--success); border-color: var(--success); color: #ffffff; }
        .filter-btn.active-teal   { background: #0891b2; border-color: #0891b2; color: #ffffff; }
        .filter-btn.active-amber  { background: var(--warning); border-color: var(--warning); color: #ffffff; }

        /* ========================================================
           CRISP TABLE
           ======================================================== */
        .table-responsive {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .crisp-table {
            width: 100%;
            min-width: 1386px;
            table-layout: fixed;
            border-collapse: collapse;
            font-size: 0.875rem;
        }

        .crisp-table thead th {
            background: #f8fafc;
            border-bottom: 2px solid var(--border-light);
            color: #64748b;
            font-size: 0.72rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 12px;
            vertical-align: middle;
            white-space: nowrap;
            box-sizing: border-box;
        }

        .crisp-table tbody td {
            padding: 14px 12px;
            border-bottom: 1px solid #f1f5f9;
            color: var(--text-body);
            vertical-align: middle;
            box-sizing: border-box;
        }

        .crisp-table tbody tr {
            min-height: 72px;
        }

        .crisp-table tbody tr:last-child td { border-bottom: none; }

        .crisp-table tbody tr:hover td { background: #fafbfc; }

        /* Status labels hidden on desktop */
        .card-status-label,
        .card-meta-label {
            display: none;
        }

        .user-id-badge {
            display: inline-flex !important;
            align-items: center !important;
            height: 32px !important;
            box-sizing: border-box !important;
            font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;
            font-size: 0.8rem !important;
            font-weight: 600 !important;
            color: #1e293b !important;
            background: #f1f5f9 !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 8px !important;
            padding: 0 10px !important;
            letter-spacing: 0.2px !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
            max-width: 100% !important;
            width: max-content !important;
            vertical-align: middle !important;
        }

        .region-badge {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            height: 32px !important;
            box-sizing: border-box !important;
            font-size: 0.78rem !important;
            font-weight: 600 !important;
            color: #0369a1 !important;
            background: #f0f9ff !important;
            border: 1px solid #bae6fd !important;
            border-radius: 8px !important;
            padding: 0 10px !important;
            letter-spacing: 0.2px !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
            max-width: 100% !important;
            width: max-content !important;
            vertical-align: middle !important;
        }

        .pagination-bar {
            background: #ffffff;
        }

        .guest-name {
            font-weight: 700;
            color: var(--text-dark);
            line-height: 1.3;
        }

        .guest-type {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 0.74rem;
            color: var(--text-muted);
            line-height: 1.3;
            max-height: 2.6em;
            word-break: break-word;
            margin-top: 2px;
        }

        .id-badge {
            color: var(--text-muted);
            font-weight: 700;
            font-size: 0.8rem;
            background: #f1f5f9;
            padding: 2px 6px;
            border-radius: 6px;
            display: inline-block;
        }

        @keyframes rowSoftHighlight {
            0% {
                background-color: rgba(34, 197, 94, 0.28) !important;
            }
            100% {
                background-color: transparent !important;
            }
        }

        tr.row-highlight-new {
            animation: rowSoftHighlight 2.5s ease-out forwards !important;
        }

        tr.row-highlight-new td {
            animation: rowSoftHighlight 2.5s ease-out forwards !important;
        }

        .status-card-inner {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .status-timestamp {
            font-size: 0.72rem;
            color: var(--text-muted);
            margin-top: 2px;
            white-space: nowrap;
        }

        .gift-status-wrap, .gift-time-wrap {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .gift-timestamp {
            color: var(--text-dark);
            font-weight: 600;
            font-size: 0.82rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        /* ========================================================
           BADGES & STATUS PILLS
           ======================================================== */
        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 0.3rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .pill-green {
            background: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .pill-teal {
            background: #cffafe;
            color: #0e7490;
            border: 1px solid #a5f3fc;
        }

        .pill-amber {
            background: #fefce8;
            color: #854d0e;
            border: 1px solid #fde68a;
        }

        .pulse-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--success);
            box-shadow: 0 0 5px var(--success);
            animation: livePulse 1.8s infinite;
        }

        .pulse-dot-teal {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #0891b2;
            box-shadow: 0 0 5px #0891b2;
            animation: livePulse 1.8s infinite;
        }

        .mobile-badge-link {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 8px !important;
            height: 32px !important;
            box-sizing: border-box !important;
            width: max-content !important;
            max-width: 100% !important;
            white-space: nowrap !important;
            padding: 0 12px !important;
            background: #f8fafc !important;
            border: 1px solid var(--border-light) !important;
            border-radius: 8px !important;
            color: var(--text-dark) !important;
            text-decoration: none !important;
            font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;
            font-size: 0.82rem !important;
            font-weight: 600 !important;
            font-variant-numeric: tabular-nums !important;
            letter-spacing: 0.2px !important;
            vertical-align: middle !important;
            transition: var(--transition);
        }

        .mobile-badge-link i {
            font-size: 0.75rem;
            color: var(--blue);
            flex-shrink: 0;
        }

        .mobile-badge-link:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--blue) !important;
        }

        .mobile-num {
            white-space: nowrap !important;
            font-variant-numeric: tabular-nums !important;
        }

        /* ========================================================
           ACTION BUTTONS (Themes & Colors)
           ======================================================== */
        .btn-checkin-d1 {
            border: 1.5px solid #22c55e !important;
            background: transparent !important;
            color: #16a34a !important;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            touch-action: manipulation;
        }
        .btn-checkin-d1:hover {
            background: #16a34a !important;
            color: #ffffff !important;
            box-shadow: 0 2px 8px rgba(22, 163, 74, 0.35);
        }

        .btn-day2-action {
            border: 1.5px solid #0891b2 !important;
            background: #0891b2 !important;
            color: #ffffff !important;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            box-shadow: 0 1px 4px rgba(8, 145, 178, 0.25);
            touch-action: manipulation;
        }
        .btn-day2-action:hover {
            background: #0e7490 !important;
            border-color: #0e7490 !important;
            color: #ffffff !important;
            box-shadow: 0 2px 8px rgba(14, 116, 144, 0.4);
        }

        .btn-reset-row {
            border: 1.5px solid #fde68a !important;
            background: #fefce8 !important;
            color: #92400e !important;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            touch-action: manipulation;
        }
        .btn-reset-row:hover {
            background: #fef3c7 !important;
            border-color: var(--warning) !important;
            color: #78350f !important;
        }

        .btn-mark-given {
            border: 1.5px solid #86efac !important;
            background: #ecfdf5 !important;
            color: #065f46 !important;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            box-shadow: 0 1px 2px rgba(16,185,129,0.12);
            touch-action: manipulation;
        }
        .btn-mark-given:hover {
            background: #10b981 !important;
            border-color: #10b981 !important;
            color: #ffffff !important;
            box-shadow: 0 2px 8px rgba(16,185,129,0.35);
        }

        .badge-claimed {
            background: #dcfce7 !important;
            color: #15803d !important;
            border: 1px solid #bbf7d0 !important;
        }

        .btn-reset-gift {
            border: 1.5px solid #fed7aa !important;
            background: #fff7ed !important;
            color: #c2410c !important;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            touch-action: manipulation;
        }
        .btn-reset-gift:hover {
            background: #ea580c !important;
            border-color: #ea580c !important;
            color: #ffffff !important;
            box-shadow: 0 2px 8px rgba(234,88,12,0.3);
        }

        /* ========================================================
           DESKTOP TABLE LAYOUT, COLUMNS & BUTTONS (>= 769px)
           ======================================================== */
        @media (min-width: 769px) {
            .col-id {
                width: 56px !important;
                min-width: 56px !important;
                max-width: 56px !important;
                padding-left: 16px !important;
                padding-right: 8px !important;
                text-align: center !important;
            }

            .col-name {
                min-width: 240px !important;
                text-align: left !important;
            }

            .col-userid {
                width: 200px !important;
                min-width: 200px !important;
                max-width: 200px !important;
                text-align: left !important;
                padding: 14px 12px !important;
                overflow: hidden !important;
            }

            .col-region {
                width: 140px !important;
                min-width: 140px !important;
                max-width: 140px !important;
                text-align: left !important;
                padding: 14px 12px !important;
            }

            .col-mobile {
                width: 190px !important;
                min-width: 190px !important;
                max-width: 190px !important;
                text-align: left !important;
                padding: 14px 12px !important;
                overflow: visible !important;
            }

            .col-status-d1 {
                width: 170px !important;
                min-width: 170px !important;
                max-width: 170px !important;
                text-align: center !important;
            }

            .col-status-d2 {
                width: 170px !important;
                min-width: 170px !important;
                max-width: 170px !important;
                text-align: center !important;
            }

            .col-gift-status {
                width: 170px !important;
                min-width: 170px !important;
                max-width: 170px !important;
                text-align: center !important;
            }

            .col-gift-time {
                width: 180px !important;
                min-width: 180px !important;
                max-width: 180px !important;
                text-align: center !important;
            }

            .col-actions {
                width: 220px !important;
                min-width: 220px !important;
                max-width: 220px !important;
                text-align: right !important;
                padding-right: 16px !important;
            }

            /* Counters Table Specific Fixed Layout (Problem 2) */
            .table-counters {
                width: 100% !important;
                min-width: 1666px !important;
                table-layout: fixed !important;
                border-collapse: collapse !important;
            }
            .table-counters th,
            .table-counters td {
                padding: 12px 14px !important;
                vertical-align: middle !important;
                box-sizing: border-box !important;
            }
            .table-counters tbody tr {
                min-height: 72px !important;
                height: 72px;
            }
            .table-counters .col-c-id {
                width: 56px !important;
                min-width: 56px !important;
                max-width: 56px !important;
                text-align: center !important;
            }
            .table-counters .col-c-name {
                width: 230px !important;
                min-width: 230px !important;
                max-width: 230px !important;
                text-align: left !important;
            }
            .table-counters .counter-name-text {
                font-weight: 700;
                color: var(--text-dark, #0f1c30);
                font-size: 0.92rem;
                line-height: 1.35;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                overflow: hidden;
            }
            .table-counters .col-c-regions {
                width: 280px !important;
                min-width: 280px !important;
                max-width: 280px !important;
                text-align: left !important;
                overflow: visible !important;
            }
            .region-chips-wrap {
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                align-items: center;
            }
            .region-chip {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                background: #f1f5f9;
                color: #334155;
                border: 1px solid #cbd5e1;
                font-size: 0.78rem;
                font-weight: 600;
                padding: 3px 8px;
                border-radius: 6px;
                white-space: nowrap;
            }
            .range-chip {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                background: #eff6ff;
                color: #1d4ed8;
                border: 1px solid #bfdbfe;
                font-size: 0.78rem;
                font-weight: 600;
                padding: 3px 8px;
                border-radius: 6px;
                white-space: normal;
                line-height: 1.35;
                word-break: break-word;
                max-width: 100%;
            }
            .table-counters .col-c-user {
                width: 280px !important;
                min-width: 280px !important;
                max-width: 280px !important;
                text-align: left !important;
            }
            .counter-user-box {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 8px;
                width: 100%;
                max-width: 100%;
            }
            .counter-user-code {
                font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;
                font-size: 13px !important;
                font-weight: 600;
                color: var(--navy, #0f1c30);
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                padding: 4px 8px;
                border-radius: 6px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 220px;
                display: inline-block;
            }
            .btn-copy-uname {
                width: 28px;
                height: 28px;
                padding: 0;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                border-radius: 6px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
                color: #64748b;
                font-size: 12px;
                cursor: pointer;
                flex-shrink: 0;
                transition: all 0.15s ease;
            }
            .btn-copy-uname:hover {
                background: #f1f5f9;
                color: var(--blue, #1d4ed8);
                border-color: #94a3b8;
            }
            .table-counters .col-c-visitors {
                width: 90px !important;
                min-width: 90px !important;
                max-width: 90px !important;
                text-align: center !important;
            }
            .table-counters .col-c-distributed {
                width: 120px !important;
                min-width: 120px !important;
                max-width: 120px !important;
                text-align: center !important;
            }
            .table-counters .col-c-pending {
                width: 100px !important;
                min-width: 100px !important;
                max-width: 100px !important;
                text-align: center !important;
            }
            .table-counters .col-c-login {
                width: 170px !important;
                min-width: 170px !important;
                max-width: 170px !important;
                text-align: center !important;
            }
            .table-counters .col-c-status {
                width: 110px !important;
                min-width: 110px !important;
                max-width: 110px !important;
                text-align: center !important;
            }
            .table-counters .col-c-actions {
                width: 230px !important;
                min-width: 230px !important;
                max-width: 230px !important;
                text-align: right !important;
                padding-right: 16px !important;
            }
            .counter-actions-wrap {
                display: flex;
                gap: 8px;
                justify-content: flex-end;
                align-items: center;
                flex-wrap: nowrap;
                width: 100%;
            }
            .btn-counter-action {
                height: 34px !important;
                width: 104px !important;
                min-width: 104px !important;
                max-width: 104px !important;
                padding: 0 12px !important;
                font-size: 13px !important;
                font-weight: 600 !important;
                white-space: nowrap !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                gap: 6px !important;
                border-radius: 999px !important;
                box-sizing: border-box !important;
                flex-shrink: 0 !important;
                text-decoration: none !important;
                transition: all 0.15s ease-in-out;
            }

            /* Mobile Counter Cards Styles */
            .counters-mobile-list {
                padding: 12px;
            }
            .counter-mobile-card {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 14px;
                padding: 14px;
                margin-bottom: 12px;
                box-shadow: 0 1px 4px rgba(15, 28, 48, 0.05);
            }
            .cmc-name {
                font-size: 0.95rem;
                color: var(--navy, #0f1c30);
            }
            .cmc-stats-grid {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 8px;
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 10px;
                padding: 8px;
                text-align: center;
            }
            .cmc-stat-label {
                font-size: 0.68rem;
                text-transform: uppercase;
                font-weight: 800;
                color: #64748b;
                letter-spacing: 0.05em;
                margin-bottom: 2px;
            }
            .cmc-stat-val {
                font-size: 0.9rem;
            }

            .crisp-table tbody td.col-mobile {
                overflow: visible !important;
            }

            .crisp-table tbody td.col-userid {
                overflow: hidden !important;
            }

            .action-btn-group {
                display: flex !important;
                gap: 8px !important;
                justify-content: flex-end !important;
                align-items: center !important;
                flex-wrap: nowrap !important;
                width: 100% !important;
            }

            /* Unified 96px x 36px action pill buttons on desktop */
            .action-btn,
            .btn-checkin-d1,
            .btn-day2-action,
            .btn-reset-row,
            .btn-mark-given,
            .btn-reset-gift,
            .badge-claimed {
                width: 96px !important;
                min-width: 96px !important;
                max-width: 96px !important;
                height: 36px !important;
                min-height: 36px !important;
                max-height: 36px !important;
                padding: 0 8px !important;
                border-radius: 999px !important;
                font-size: 13px !important;
                font-weight: 600 !important;
                white-space: nowrap !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                gap: 5px !important;
                flex-shrink: 0 !important;
                box-sizing: border-box !important;
                text-decoration: none !important;
                line-height: 1 !important;
                overflow: hidden !important;
            }

            /* Centered 140px Status Badges on desktop */
            .status-card-inner,
            .gift-status-wrap {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
                width: 100%;
            }

            .status-card-inner .status-pill,
            .gift-status-wrap .status-pill {
                width: 140px !important;
                min-width: 140px !important;
                max-width: 140px !important;
                height: 30px !important;
                min-height: 30px !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                margin: 0 auto !important;
                white-space: nowrap !important;
                box-sizing: border-box !important;
                font-size: 0.75rem !important;
                font-weight: 700 !important;
                padding: 0 8px !important;
                border-radius: var(--radius-pill) !important;
            }
        }

        /* ========================================================
           FLASH NOTICE
           ======================================================== */
        .flash-notice {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.7rem 1rem;
            border-radius: 10px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 1.25rem;
            overflow: hidden;
            max-height: 120px;
            opacity: 1;
            transform: translateY(0);
            transition: opacity 0.2s ease, max-height 0.25s ease, margin 0.25s ease, padding 0.25s ease, transform 0.2s ease;
            box-sizing: border-box;
        }

        .flash-notice.flash-dismissing {
            opacity: 0;
            max-height: 0;
            margin-top: 0 !important;
            margin-bottom: 0 !important;
            padding-top: 0 !important;
            padding-bottom: 0 !important;
            border-top-width: 0 !important;
            border-bottom-width: 0 !important;
            transform: translateY(-4px);
            pointer-events: none;
        }

        .flash-close {
            background: transparent;
            border: none;
            color: inherit;
            font-size: 1.35rem;
            line-height: 1;
            padding: 0 4px;
            cursor: pointer;
            opacity: 0.55;
            transition: opacity 0.15s ease, transform 0.15s ease;
            margin-left: auto;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .flash-close:hover {
            opacity: 1;
            transform: scale(1.1);
        }

        .flash-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; }
        .flash-warning { background: #fffbeb; border: 1px solid #fde68a; color: #92400e; }
        .flash-danger  { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }

        /* ========================================================
           SIDEBAR OVERLAY (Mobile)
           ======================================================== */
        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 28, 48, 0.6);
            z-index: 199;
            backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px);
            transition: opacity 0.25s ease;
            opacity: 0;
        }

        /* ========================================================
           RESPONSIVE BREAKPOINTS
           ======================================================== */
        @media (max-width: 1024px) {
            .metrics-row { grid-template-columns: repeat(2, 1fr); gap: 0.75rem; }
        }

        @media (max-width: 767.98px) {
            .sidebar {
                transform: translateX(calc(-1 * var(--sidebar-w)));
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .sidebar-overlay.open {
                display: block;
                opacity: 1;
            }

            .main-panel {
                margin-left: 0;
                width: 100%;
                max-width: 100vw;
            }

            .sidebar-toggle {
                display: flex;
            }

            /* Mobile 2-Row Sticky Topbar */
            .topbar {
                display: grid;
                grid-template-columns: auto 1fr auto;
                grid-template-areas:
                    "toggle title actions"
                    "sub    sub   sub";
                gap: 6px 10px;
                padding: calc(8px + env(safe-area-inset-top, 0px)) 12px 10px 12px;
                min-height: auto;
                height: auto;
                background: rgba(255, 255, 255, 0.98);
                backdrop-filter: blur(12px);
                -webkit-backdrop-filter: blur(12px);
            }

            .sidebar-toggle {
                grid-area: toggle;
                align-self: center;
            }

            .topbar-text-group {
                display: contents;
            }

            .topbar-heading-wrap {
                grid-area: title;
                align-self: center;
                min-width: 0;
            }

            .topbar-heading-wrap strong {
                font-size: 0.92rem;
            }

            .topbar-actions {
                grid-area: actions;
                align-self: center;
                margin-left: 0;
                display: flex;
                align-items: center;
                gap: 6px;
                flex-wrap: nowrap;
            }

            .topbar-actions .btn-topbar {
                width: 36px;
                height: 36px;
                min-width: 36px;
                padding: 0;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                border-radius: 9px;
            }

            .topbar-actions .btn-topbar span {
                display: none !important;
            }

            .topbar-actions .btn-topbar i {
                font-size: 1.05rem;
                margin: 0;
            }

            .topbar-subtitle {
                grid-area: sub;
                width: 100%;
                margin: 0;
                padding-top: 4px;
                border-top: 1px dashed rgba(226, 232, 240, 0.7);
                line-height: 1.35;
                font-size: 0.72rem;
            }

            /* Content Body & Metrics */
            .content-body {
                padding: 12px 14px;
            }

            .metrics-row {
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 10px !important;
                margin-bottom: 1rem !important;
            }

            .metric-card {
                padding: 0.85rem 0.9rem;
            }

            .metric-value {
                font-size: 1.5rem;
            }

            .metric-label {
                font-size: 0.68rem;
            }

            .metric-sub {
                font-size: 0.68rem;
                flex-wrap: wrap;
            }

            /* Mobile Filter Bar */
            .filter-bar {
                padding: 0.75rem 0.85rem;
            }

            .filter-form {
                display: flex;
                flex-direction: column;
                gap: 8px;
                width: 100%;
            }

            .filter-search-row {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 8px;
                width: 100%;
                max-width: 100%;
            }

            .filter-search-row .search-field-wrap {
                width: 100%;
                flex: 1 1 100%;
                min-width: 0;
            }

            .region-select-wrap {
                width: 100%;
                min-width: 100%;
                max-width: 100%;
            }

            .card-meta-label {
                display: block;
                font-size: 0.65rem;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                color: var(--text-muted);
                margin-bottom: 2px;
            }

            .filter-submit {
                padding: 0 0.85rem;
                flex-shrink: 0;
            }

            .filter-clear {
                padding: 0 0.75rem;
                flex-shrink: 0;
            }

            .filter-btn-group {
                display: flex;
                overflow-x: auto;
                overflow-y: hidden;
                flex-wrap: nowrap;
                -webkit-overflow-scrolling: touch;
                scrollbar-width: none;
                gap: 6px;
                width: 100%;
                padding: 2px 2px 6px 2px;
                margin: 0 -2px;
            }

            .filter-btn-group::-webkit-scrollbar {
                display: none;
            }

            .filter-btn {
                flex: 0 0 auto;
                padding: 0.38rem 0.75rem;
                font-size: 0.76rem;
            }

            /* Mobile Card Layout for Tables */
            .table-responsive {
                overflow: visible !important;
                -webkit-overflow-scrolling: auto;
            }

            .crisp-table {
                display: block;
                width: 100%;
            }

            .crisp-table thead {
                display: none !important;
            }

            .crisp-table tbody {
                display: block;
                width: 100%;
                padding: 10px 12px;
            }

            .crisp-table tbody tr {
                display: grid;
                position: relative;
                background: var(--card-bg);
                border: 1px solid var(--border-light);
                border-radius: 14px;
                padding: 12px 14px;
                margin-bottom: 12px;
                box-shadow: 0 1px 4px rgba(15,28,48,0.05);
                gap: 10px;
            }

            .crisp-table tbody tr:hover td {
                background: transparent;
            }

            /* Gate Entry Grid Area Mapping - Two Equal 50/50 Columns */
            .crisp-table.table-gate tbody tr {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                grid-template-areas:
                    "name   name"
                    "uid    reg"
                    "mobile mobile"
                    "stat1  stat2"
                    "act    act";
                gap: 10px;
            }

            /* Gift Distribution Grid Area Mapping - Two Equal 50/50 Columns */
            .crisp-table.table-gift tbody tr {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                grid-template-areas:
                    "name   name"
                    "uid    reg"
                    "mobile mobile"
                    "status time"
                    "act    act";
                gap: 10px;
            }

            /* Empty State Row */
            .crisp-table tbody tr.tr-empty {
                display: block !important;
                text-align: center;
                padding: 2.5rem 1rem !important;
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
            }

            .crisp-table tbody tr.tr-empty td {
                display: block !important;
                padding: 0 !important;
                border: none !important;
            }

            /* Cell Placements in Cards */
            .crisp-table tbody td {
                display: block;
                padding: 0 !important;
                border: none !important;
            }

            .td-name {
                grid-area: name;
                min-width: 0;
                padding-right: 48px !important;
            }

            .td-userid {
                grid-area: uid;
                width: 100% !important;
                min-width: 0 !important;
                background: #f8fafc;
                border: 1px solid var(--border-light);
                border-radius: 8px;
                padding: 6px 10px !important;
                display: flex;
                flex-direction: column;
                justify-content: center;
            }

            .td-userid .user-id-badge {
                height: auto !important;
                min-height: 24px !important;
                white-space: normal !important;
                word-break: break-all !important;
                overflow-wrap: anywhere !important;
                text-overflow: clip !important;
                max-width: 100% !important;
                padding: 2px 0 !important;
                background: transparent !important;
                border: none !important;
                font-size: 0.78rem !important;
                display: block !important;
                width: 100% !important;
            }

            .td-region {
                grid-area: reg;
                width: 100% !important;
                min-width: 0 !important;
                background: #f8fafc;
                border: 1px solid var(--border-light);
                border-radius: 8px;
                padding: 6px 10px !important;
                display: flex;
                flex-direction: column;
                justify-content: center;
            }

            .td-region .region-badge {
                height: auto !important;
                min-height: 24px !important;
                white-space: normal !important;
                word-break: break-word !important;
                text-overflow: clip !important;
                max-width: 100% !important;
                padding: 2px 0 !important;
                background: transparent !important;
                border: none !important;
                font-size: 0.78rem !important;
                display: block !important;
                width: 100% !important;
            }

            .td-id,
            .col-id {
                position: absolute !important;
                top: 12px !important;
                right: 14px !important;
                z-index: 2;
                text-align: right !important;
                padding: 0 !important;
                margin: 0 !important;
                width: auto !important;
                min-width: 0 !important;
                max-width: none !important;
            }

            .id-badge {
                display: inline-block;
                font-size: 0.72rem;
                font-weight: 700;
                color: var(--text-muted);
                background: #f1f5f9;
                padding: 2px 7px;
                border-radius: 6px;
            }

            .guest-name {
                font-size: 0.95rem;
                font-weight: 700;
                color: var(--text-dark);
                line-height: 1.25;
                word-break: break-word;
            }

            .guest-type {
                font-size: 0.72rem;
                color: var(--text-muted);
                margin-top: 2px;
            }

            .td-mobile {
                grid-area: mobile;
                width: 100%;
            }

            .td-mobile .mobile-badge-link {
                width: 100% !important;
                max-width: 100% !important;
                height: 38px !important;
                justify-content: center !important;
                font-size: 0.85rem !important;
            }

            /* Day 1 & Day 2 Status Boxes - Equal Columns */
            .td-status-d1 {
                grid-area: stat1;
                width: 100% !important;
                min-width: 0 !important;
                max-width: 100% !important;
                flex: none !important;
            }

            .td-status-d2 {
                grid-area: stat2;
                width: 100% !important;
                min-width: 0 !important;
                max-width: 100% !important;
                flex: none !important;
            }

            .td-gift-status {
                grid-area: status;
                width: 100% !important;
                min-width: 0 !important;
                max-width: 100% !important;
                flex: none !important;
            }

            .td-gift-time {
                grid-area: time;
                width: 100% !important;
                min-width: 0 !important;
                max-width: 100% !important;
                flex: none !important;
            }

            /* Status Boxes inside Mobile Cards: Equal Height, Padding and Radius */
            .status-card-inner,
            .gift-status-wrap,
            .gift-time-wrap {
                background: #f8fafc;
                border: 1px solid var(--border-light);
                border-radius: 10px;
                padding: 8px 10px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: flex-start;
                text-align: center;
                gap: 4px;
                min-height: 100%;
                height: 100%;
                width: 100% !important;
                min-width: 0 !important;
                max-width: 100% !important;
                box-sizing: border-box !important;
                flex: none !important;
            }

            .card-status-label {
                display: block !important;
                font-size: 0.68rem;
                font-weight: 800;
                text-transform: uppercase;
                letter-spacing: 0.06em;
                color: var(--text-muted);
                text-align: center;
                width: 100%;
                margin-bottom: 2px;
            }

            /* Status Badge: Full-width Centered with White-Space Nowrap */
            .status-card-inner .status-pill,
            .gift-status-wrap .status-pill {
                width: 100% !important;
                min-width: 0 !important;
                max-width: 100% !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                padding: 0.32rem 0.4rem !important;
                font-size: 0.74rem !important;
                font-weight: 700 !important;
                white-space: nowrap !important;
                box-sizing: border-box !important;
                text-align: center !important;
                gap: 4px !important;
                border-radius: var(--radius-pill) !important;
                margin: 0 !important;
            }

            /* Timestamp Wrap Cleanly without Resizing the Box */
            .status-timestamp {
                font-size: 0.68rem;
                color: var(--text-muted);
                margin-top: 2px;
                text-align: center;
                white-space: normal;
                word-break: normal;
                line-height: 1.25;
                width: 100%;
            }

            .gift-timestamp {
                font-size: 0.72rem;
                color: var(--text-dark);
                font-weight: 600;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 4px;
                text-align: center;
                white-space: normal;
                word-break: normal;
                line-height: 1.25;
                width: 100%;
            }

            .td-actions {
                grid-area: act;
                padding-top: 6px !important;
                border-top: 1px dashed var(--border-light) !important;
                width: 100%;
            }

            /* Action Buttons: 2 Equal Columns Matching the Status Boxes Above */
            .action-btn-group {
                display: grid !important;
                grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
                gap: 10px !important;
                width: 100% !important;
            }

            .action-btn-group > :only-child {
                grid-column: 1 / -1 !important;
            }

            .action-btn-group .btn,
            .action-btn-group .action-btn,
            .action-btn-group .btn-checkin-d1,
            .action-btn-group .btn-day2-action,
            .action-btn-group .btn-reset-row,
            .action-btn-group .badge-claimed,
            .action-btn-group .btn-reset-gift,
            .action-btn-group .btn-mark-given {
                width: 100% !important;
                min-width: 0 !important;
                max-width: 100% !important;
                flex: none !important;
                height: auto !important;
                min-height: 40px !important;
                max-height: none !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                font-size: 0.82rem !important;
                font-weight: 700 !important;
                padding: 0.4rem 0.5rem !important;
                white-space: nowrap !important;
                box-sizing: border-box !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 480px) {
            .content-body { padding: 10px 12px; }
            .metrics-row { gap: 8px !important; }
            .metric-card { padding: 0.75rem 0.8rem; }
            .metric-value { font-size: 1.35rem; }
            .metric-label { font-size: 0.65rem; }
            .metric-sub { font-size: 0.66rem; }
            .crisp-table tbody { padding: 8px 10px; }
            .crisp-table tbody tr { padding: 10px 12px; margin-bottom: 10px; gap: 10px; }
            .action-btn-group { gap: 10px !important; }
        }
    </style>
</head>
<body>

<!-- Sidebar Overlay (Mobile) -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app-shell">

    <!-- ================================================================
         SIDEBAR
         ================================================================ -->
    <aside class="sidebar" id="sidebar">

        <!-- Brand -->
        <div class="sidebar-brand">
            <div class="brand-icon">
                <i class="bi bi-shield-check"></i>
            </div>
            <div class="brand-text">
                <strong>EventMS Admin</strong>
                <span>
                    <span class="live-dot"></span>
                    Session Active
                </span>
            </div>
        </div>

        <!-- Main Navigation & Public Terminals (Scrollable independently) -->
        <div class="sidebar-nav-scroll">
            <?php if ($isCounter): ?>
                <!-- Counter Role Navigation: COE Kit Only -->
                <div class="sidebar-section">
                    <div class="sidebar-section-label">COE Kit Counter</div>
                    <a href="admin.php?tab=gift" class="nav-item-link active">
                        <div class="nav-icon"><i class="bi bi-box-seam"></i></div>
                        <span class="nav-label">COE Kit Distribution</span>
                        <span class="nav-badge"><?= $giftsGiven ?>/<?= $totalGiftElig ?></span>
                    </a>
                </div>

                <hr class="sidebar-divider">

                <div class="sidebar-section">
                    <div class="sidebar-section-label">Counter Terminal</div>
                    <a href="gift.php" target="_blank" class="nav-item-link">
                        <div class="nav-icon"><i class="bi bi-display"></i></div>
                        <span class="nav-label">COE Kit Terminal</span>
                        <i class="bi bi-box-arrow-up-right" style="font-size:0.7rem;color:#475569;margin-left:auto;"></i>
                    </a>
                </div>

            <?php elseif ($isSuperAdmin): ?>
                <!-- Super Admin Navigation: Gate, COE Kit & Regional Counters -->
                <div class="sidebar-section">
                    <div class="sidebar-section-label">Live Tracking</div>

                    <a href="admin.php?tab=gate" class="nav-item-link <?= $tab === 'gate' ? 'active' : '' ?>">
                        <div class="nav-icon"><i class="bi bi-door-open-fill"></i></div>
                        <span class="nav-label">Gate Entry</span>
                        <span class="nav-badge"><?= $checkedInCount ?>/<?= $totalVisitors ?></span>
                    </a>

                    <a href="admin.php?tab=gift" class="nav-item-link <?= $tab === 'gift' ? 'active' : '' ?>">
                        <div class="nav-icon"><i class="bi bi-box-seam"></i></div>
                        <span class="nav-label">COE Kit Distribution</span>
                        <span class="nav-badge"><?= $giftsGiven ?>/<?= $totalGiftElig ?></span>
                    </a>

                    <a href="admin.php?tab=counters" class="nav-item-link <?= $tab === 'counters' ? 'active' : '' ?>">
                        <div class="nav-icon"><i class="bi bi-people-fill"></i></div>
                        <span class="nav-label">Regional Counters</span>
                        <span class="nav-badge"><?= $totalCountersCount ?: 20 ?></span>
                    </a>
                </div>

                <hr class="sidebar-divider">

                <div class="sidebar-section">
                    <div class="sidebar-section-label">Public Terminals</div>

                    <a href="index.php" target="_blank" class="nav-item-link">
                        <div class="nav-icon"><i class="bi bi-display"></i></div>
                        <span class="nav-label">Gate Terminal</span>
                        <i class="bi bi-box-arrow-up-right" style="font-size:0.7rem;color:#475569;margin-left:auto;"></i>
                    </a>

                    <a href="gift.php" target="_blank" class="nav-item-link">
                        <div class="nav-icon"><i class="bi bi-box-seam"></i></div>
                        <span class="nav-label">COE Kit Terminal</span>
                        <i class="bi bi-box-arrow-up-right" style="font-size:0.7rem;color:#475569;margin-left:auto;"></i>
                    </a>
                </div>

            <?php else: ?>
                <!-- Guard Role Navigation: Gate Entry Only -->
                <div class="sidebar-section">
                    <div class="sidebar-section-label">Live Tracking</div>
                    <a href="admin.php?tab=gate" class="nav-item-link active">
                        <div class="nav-icon"><i class="bi bi-door-open-fill"></i></div>
                        <span class="nav-label">Gate Entry</span>
                        <span class="nav-badge"><?= $checkedInCount ?>/<?= $totalVisitors ?></span>
                    </a>
                </div>

                <hr class="sidebar-divider">

                <div class="sidebar-section">
                    <div class="sidebar-section-label">Public Terminal</div>
                    <a href="index.php" target="_blank" class="nav-item-link">
                        <div class="nav-icon"><i class="bi bi-display"></i></div>
                        <span class="nav-label">Gate Terminal</span>
                        <i class="bi bi-box-arrow-up-right" style="font-size:0.7rem;color:#475569;margin-left:auto;"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Bottom: User Profile + Logout (Pinned at bottom) -->
        <div class="sidebar-bottom">
            <div class="admin-profile-card">
                <div class="admin-avatar" style="<?= $isSuperAdmin ? 'background: linear-gradient(135deg, var(--blue), #7c3aed);' : ($isCounter ? 'background: linear-gradient(135deg, #2563eb, #0891b2);' : 'background: linear-gradient(135deg, #10b981, #059669);') ?>">
                    <?= strtoupper(substr($adminUsername, 0, 1)) ?>
                </div>
                <div class="admin-info" style="flex:1;min-width:0;">
                    <strong style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= $adminUsername ?></strong>
                    <div style="margin-top:2px;">
                        <?php if ($isSuperAdmin): ?>
                            <span class="role-pill role-pill-super">
                                <i class="bi bi-shield-shaded me-1"></i>Super Admin
                            </span>
                        <?php elseif ($isCounter): ?>
                            <span class="role-pill" style="background:rgba(29,88,216,0.18);color:var(--cyan);border:1px solid rgba(29,88,216,0.3);font-size:0.7rem;">
                                <i class="bi bi-geo-alt-fill me-1"></i><?= htmlspecialchars($counterRegion) ?> Counter
                            </span>
                        <?php else: ?>
                            <span class="role-pill role-pill-guard">
                                <i class="bi bi-shield-check me-1"></i>Gate Guard (Gate 1)
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <a href="logout.php" class="btn-logout-sidebar" onclick="return confirm('Sign out of active session?');">
                <i class="bi bi-box-arrow-right"></i>
                Sign Out
            </a>
        </div>

    </aside>

    <!-- ================================================================
         MAIN PANEL
         ================================================================ -->
    <main class="main-panel">

        <!-- TOP NAVBAR -->
        <div class="topbar">

            <!-- Mobile Toggle -->
            <button class="sidebar-toggle d-md-none" id="sidebarToggle" aria-label="Toggle sidebar">
                <i class="bi bi-list"></i>
            </button>

            <!-- Dynamic Title -->
            <div class="topbar-text-group">
                <div class="topbar-heading-wrap">
                    <strong>
                        <?php if ($tab === 'counters'): ?>
                            👥 Regional Counter Management
                        <?php elseif ($isGate): ?>
                            🚪 Gate Entry Live Tracking
                        <?php else: ?>
                            <?= $isCounter ? ('📦 ' . htmlspecialchars($roleLabel)) : '📦 COE Kit Distribution Control' ?>
                        <?php endif; ?>
                    </strong>
                    <?php if ($isSuperAdmin): ?>
                        <span class="role-pill role-pill-super d-none d-sm-inline-flex" style="font-size:0.65rem;">
                            <i class="bi bi-shield-shaded me-1"></i>Super Admin
                        </span>
                    <?php elseif ($isCounter): ?>
                        <span class="role-pill d-none d-sm-inline-flex" style="background:rgba(29,88,216,0.18);color:var(--cyan);border:1px solid rgba(29,88,216,0.3);font-size:0.65rem;">
                            <i class="bi bi-geo-alt-fill me-1"></i><?= htmlspecialchars($counterName ?: $counterRegion) ?>
                        </span>
                    <?php else: ?>
                        <span class="role-pill role-pill-guard d-none d-sm-inline-flex" style="font-size:0.65rem;">
                            <i class="bi bi-shield-check me-1"></i>Gate Guard (Gate 1)
                        </span>
                    <?php endif; ?>
                </div>
                <small class="topbar-subtitle">
                    <?php if ($tab === 'counters'): ?>
                        <?= $totalCountersCount ?> Regional Counters &bull; <?= $activeCountersCount ?> Active &bull; <?= $totalCountersGiven ?> Total Kits Distributed Across All Booths
                    <?php elseif ($isGate): ?>
                        Day 1: <strong><?= $d1Count ?></strong> (<?= $d1Rate ?>%) &bull; Day 2: <strong><?= $d2Count ?></strong> (<?= $d2Rate ?>%) &bull; <?= $totalVisitors ?> Whitelisted
                    <?php elseif ($isCounter): ?>
                        <?= $giftsGiven ?> of <?= $totalGiftElig ?> kits distributed &middot; <?= $giftRate ?>% kit rate in <?= htmlspecialchars($counterName ?: $counterRegion) ?>
                    <?php else: ?>
                        <?= $giftsGiven ?> of <?= $totalGiftElig ?> kits distributed &middot; <?= $giftRate ?>% kit rate
                    <?php endif; ?>
                </small>
            </div>

            <!-- Top Action Cluster -->
            <div class="topbar-actions">
                <?php if ($tab === 'counters' && $isSuperAdmin): ?>
                    <button type="button" class="btn-topbar btn-topbar-primary" data-bs-toggle="modal" data-bs-target="#createCounterModal" title="Create a new regional counter">
                        <i class="bi bi-plus-circle"></i><span>Create Counter</span>
                    </button>
                    <a href="counter_credentials.csv" download class="btn-topbar btn-topbar-ghost" title="Download initial credentials CSV">
                        <i class="bi bi-file-earmark-spreadsheet"></i><span>Credentials CSV</span>
                    </a>
                <?php elseif ($tab === 'gate' && $isSuperAdmin): ?>
                    <a href="admin.php?export=gate_csv&tab=gate" class="btn-topbar btn-topbar-ghost" title="Export 2-day visitor list as CSV">
                        <i class="bi bi-download"></i><span>Export CSV</span>
                    </a>
                    <button type="button" class="btn-topbar btn-topbar-primary" data-bs-toggle="modal" data-bs-target="#importCsvModal" title="Bulk import visitors CSV">
                        <i class="bi bi-cloud-arrow-up"></i><span>Import CSV</span>
                    </button>
                    <a href="admin.php?action=gate_reset_all&tab=gate"
                       class="btn-topbar btn-topbar-danger"
                       onclick="return confirm('Reset ALL <?= $totalVisitors ?> gate entries for Day 1 and Day 2 to Not Checked-in?');"
                       title="Super Admin: Reset all gate entries">
                        <i class="bi bi-arrow-counterclockwise"></i><span>Reset All</span>
                    </a>
                <?php elseif ($tab === 'gift'): ?>
                    <a href="admin.php?export=gift_csv&tab=gift<?= !empty($dRegion) ? '&dregion=' . urlencode($dRegion) : '' ?>" class="btn-topbar btn-topbar-ghost" title="Export COE Kit distribution list as CSV">
                        <i class="bi bi-download"></i><span>Export CSV</span>
                    </a>
                    <?php if ($isSuperAdmin): ?>
                        <button type="button" class="btn-topbar btn-topbar-primary" data-bs-toggle="modal" data-bs-target="#importCsvModal" title="Bulk import visitors CSV">
                            <i class="bi bi-cloud-arrow-up"></i><span>Import CSV</span>
                        </button>
                        <a href="admin.php?action=gift_reset_all&tab=gift"
                           class="btn-topbar btn-topbar-danger"
                           onclick="return confirm('Reset ALL <?= $totalGiftElig ?> COE Kit records to Pending?');"
                           title="Super Admin: Reset all COE Kits">
                            <i class="bi bi-arrow-counterclockwise"></i><span>Reset All</span>
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

        </div>

        <!-- CONTENT BODY -->
        <div class="content-body">

            <!-- Flash Notice -->
            <?php
            $notices = [
                'gate_checkin_d1'        => ['success', 'bi-check2-circle',          'Visitor Day 1 check-in verified! Marked as <strong>Inside Gate (Day 1)</strong>.'],
                'gate_reset_d1'          => ['warning', 'bi-arrow-counterclockwise', 'Visitor Day 1 entry reset to <strong>Pending</strong>.'],
                'gate_checkin_d2'        => ['success', 'bi-check2-circle',          'Visitor Day 2 check-in verified! Marked as <strong>Inside Gate (Day 2)</strong>.'],
                'gate_reset_d2'          => ['warning', 'bi-arrow-counterclockwise', 'Visitor Day 2 entry reset to <strong>Pending</strong>.'],
                'gate_checkin_one'       => ['success', 'bi-check2-circle',          'Visitor check-in verified! Marked as <strong>Inside Gate</strong>.'],
                'gate_reset_one'         => ['warning', 'bi-arrow-counterclockwise', 'Visitor gate entry reset to <strong>Not Checked-in</strong>.'],
                'gate_reset_all'         => ['danger',  'bi-arrow-repeat',           'All Day 1 &amp; Day 2 gate entries reset to <strong>Not Checked-in</strong>. Gate cleared.'],
                'gift_given_one'         => ['success', 'bi-box-seam',               'COE Kit handover approved! Visitor marked as <strong>Kit Collected</strong>.'],
                'gift_reset_one'         => ['warning', 'bi-arrow-counterclockwise', 'Visitor COE Kit status reset to <strong>Pending / Re-issued</strong>.'],
                'gift_reset_all'         => ['danger',  'bi-arrow-repeat',           'All COE Kit records reset to <strong>Pending</strong>. Distribution counter cleared.'],
                'counter_pwd_reset'      => ['success', 'bi-key-fill',                 'Counter password updated successfully! Please note the new password below.'],
                'counter_status_toggled' => ['success', 'bi-toggle-on',                'Counter account status updated successfully.'],
                'counter_reassigned'     => ['success', 'bi-check2-circle',             'Visitor counter successfully reassigned and logged.'],
                'counter_created'        => ['success', 'bi-person-check-fill',        'New regional counter created successfully! Credentials generated below.'],
                'counter_exists'         => ['danger',  'bi-exclamation-triangle-fill', 'A counter account with that username already exists. Please choose a different region or username.'],
                'invalid_counter_region' => ['danger',  'bi-exclamation-triangle-fill', 'Please enter a valid region name for the new counter.'],
                'imported'               => ['success', 'bi-cloud-check-fill',       'Successfully imported and synchronized <strong>' . (int)($_GET['count'] ?? $_GET['import_success'] ?? 0) . '</strong> visitor(s) across both Gate &amp; COE Kit modules. (' . (int)($_GET['skipped'] ?? 0) . ' skipped)'],
                'import_error'           => ['danger',  'bi-exclamation-octagon-fill', 'Import failed: Database error encountered during synchronization. Transaction was rolled back.'],
                'invalid_file'           => ['danger',  'bi-exclamation-triangle-fill', 'Upload failed: Please upload a valid <strong>.csv</strong> file.'],
                'db_error'               => ['danger',  'bi-exclamation-octagon-fill',  'Action failed: A database error occurred. Your changes were not saved.'],
                'permission_denied'      => ['danger',  'bi-shield-x',               'Access Restricted: You do not have permission for this action or region.'],
            ];
            if ($msg && isset($notices[$msg])):
                [$type, $icon, $text] = $notices[$msg];
                $isErrorNotice = in_array($msg, ['import_error', 'invalid_file', 'db_error', 'permission_denied', 'counter_exists', 'invalid_counter_region'], true);
            ?>
                <div class="flash-notice flash-<?= $type ?>" id="flashNotice" role="alert" data-type="<?= $type ?>" data-is-error="<?= $isErrorNotice ? 'true' : 'false' ?>">
                    <i class="<?= $icon ?> flex-shrink-0 fs-5"></i>
                    <div class="flex-grow-1"><?= $text ?></div>
                    <button type="button" class="flash-close" aria-label="Close" onclick="dismissFlashNotice(this.closest('.flash-notice'))" title="Dismiss notice">&times;</button>
                </div>
            <?php endif; ?>

            <!-- KPI METRICS ROW -->
            <div class="metrics-row">

                <?php if ($tab === 'counters'): ?>
                    <!-- Counters Management View -->
                    <div class="metric-card mc-blue">
                        <div class="metric-label">
                            <span class="metric-icon mi-blue"><i class="bi bi-shop"></i></span>
                            Total Counters
                        </div>
                        <div class="metric-value"><?= $totalCountersCount ?></div>
                        <div class="metric-sub">Configured regional booths</div>
                    </div>
                    <div class="metric-card mc-green">
                        <div class="metric-label">
                            <span class="metric-icon mi-green"><i class="bi bi-check-circle-fill"></i></span>
                            Active Counters
                        </div>
                        <div class="metric-value" style="color:var(--success);"><?= $activeCountersCount ?></div>
                        <div class="metric-sub">Online &amp; active booths</div>
                    </div>
                    <div class="metric-card mc-teal">
                        <div class="metric-label">
                            <span class="metric-icon mi-teal"><i class="bi bi-box-seam"></i></span>
                            Kits Distributed
                        </div>
                        <div class="metric-value" style="color:#0891b2;"><?= $totalCountersGiven ?></div>
                        <div class="metric-sub">Handed over across booths</div>
                    </div>
                    <div class="metric-card mc-amber">
                        <div class="metric-label">
                            <span class="metric-icon mi-amber"><i class="bi bi-clock-history"></i></span>
                            Kits Pending
                        </div>
                        <div class="metric-value" style="color:var(--warning);"><?= $totalCountersPending ?></div>
                        <div class="metric-sub">Awaiting collection</div>
                    </div>

                <?php elseif ($isCounter): ?>
                    <!-- Counter Staff View (Strictly Scoped to their Region) -->
                    <div class="metric-card mc-blue">
                        <div class="metric-label">
                            <span class="metric-icon mi-blue"><i class="bi bi-people-fill"></i></span>
                            Regional Attendees
                        </div>
                        <div class="metric-value"><?= $totalGiftElig ?></div>
                        <div class="metric-sub">Registered for <?= htmlspecialchars($counterRegion) ?></div>
                    </div>
                    <div class="metric-card mc-green">
                        <div class="metric-label">
                            <span class="metric-icon mi-green"><i class="bi bi-box-seam"></i></span>
                            Kits Distributed
                        </div>
                        <div class="metric-value" style="color:var(--success);"><?= $giftsGiven ?></div>
                        <div class="metric-sub">
                            Handed over
                            <span class="rate-pill rate-green"><?= $giftRate ?>%</span>
                        </div>
                        <div class="mini-bar">
                            <div class="mini-bar-fill" style="width:<?= $giftRate ?>%;background:var(--success);"></div>
                        </div>
                    </div>
                    <div class="metric-card mc-amber">
                        <div class="metric-label">
                            <span class="metric-icon mi-amber"><i class="bi bi-clock"></i></span>
                            Pending Kits
                        </div>
                        <div class="metric-value" style="color:var(--warning);"><?= $giftsPending ?></div>
                        <div class="metric-sub">Awaiting handover</div>
                    </div>
                    <div class="metric-card mc-teal">
                        <div class="metric-label">
                            <span class="metric-icon mi-teal"><i class="bi bi-speedometer2"></i></span>
                            Distribution Rate
                        </div>
                        <div class="metric-value" style="color:#0891b2;"><?= $giftRate ?>%</div>
                        <div class="metric-sub">Counter completion</div>
                        <div class="mini-bar">
                            <div class="mini-bar-fill" style="width:<?= $giftRate ?>%;background:#0891b2;"></div>
                        </div>
                    </div>

                <?php else: ?>
                    <!-- Super Admin & Guard Standard Metrics -->
                    <!-- 1. Total Whitelisted Visitors -->
                    <div class="metric-card mc-blue">
                        <div class="metric-label">
                            <span class="metric-icon mi-blue"><i class="bi bi-people-fill"></i></span>
                            Total Visitors
                        </div>
                        <div class="metric-value"><?= $totalVisitors ?></div>
                        <div class="metric-sub">Whitelisted attendees</div>
                    </div>

                    <!-- 2. Day 1 Inside Gate -->
                    <div class="metric-card mc-green">
                        <div class="metric-label">
                            <span class="metric-icon mi-green"><i class="bi bi-calendar-check-fill"></i></span>
                            Day 1 Inside Gate
                        </div>
                        <div class="metric-value" style="color:var(--success);"><?= $d1Count ?></div>
                        <div class="metric-sub">
                            Day 1 checked in
                            <span class="rate-pill rate-green"><?= $d1Rate ?>%</span>
                        </div>
                        <div class="mini-bar">
                            <div class="mini-bar-fill" style="width:<?= $d1Rate ?>%;background:var(--success);"></div>
                        </div>
                    </div>

                    <!-- 3. Day 2 Inside Gate -->
                    <div class="metric-card mc-teal">
                        <div class="metric-label">
                            <span class="metric-icon mi-teal"><i class="bi bi-calendar2-check-fill"></i></span>
                            Day 2 Inside Gate
                        </div>
                        <div class="metric-value" style="color:#0891b2;"><?= $d2Count ?></div>
                        <div class="metric-sub">
                            Day 2 checked in
                            <span class="rate-pill rate-teal"><?= $d2Rate ?>%</span>
                        </div>
                        <div class="mini-bar">
                            <div class="mini-bar-fill" style="width:<?= $d2Rate ?>%;background:#0891b2;"></div>
                        </div>
                    </div>

                    <!-- 4. COE Kit Handover Stats -->
                    <div class="metric-card mc-amber">
                        <div class="metric-label">
                            <span class="metric-icon mi-amber"><i class="bi bi-box-seam"></i></span>
                            COE Kits Distributed
                        </div>
                        <div class="metric-value" style="color:var(--warning);"><?= $giftsGiven ?></div>
                        <div class="metric-sub">
                            <?= $giftsGiven ?> of <?= $totalGiftElig ?> kits
                            <span class="rate-pill" style="background:#fef3c7;color:#92400e;"><?= $giftRate ?>%</span>
                        </div>
                        <div class="mini-bar">
                            <div class="mini-bar-fill" style="width:<?= $giftRate ?>%;background:var(--warning);"></div>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
            <!-- /METRICS ROW -->

            <?php if ($tab === 'counters' && $isSuperAdmin): ?>
            <!-- ============================================================
                 REGIONAL COUNTERS MANAGEMENT TABLE (Tab: counters)
                 ============================================================ -->
            <div class="content-card">
                <div class="content-card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div class="content-card-title">
                        <div class="card-icon-dot mi-blue" style="background:rgba(29,88,216,0.1);color:var(--blue);">
                            <i class="bi bi-people-fill"></i>
                        </div>
                        Regional Counter Accounts &amp; Booth Activity
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <button type="button" class="btn btn-primary btn-sm rounded-pill px-3 fw-bold" data-bs-toggle="modal" data-bs-target="#createCounterModal" style="background:var(--blue);border:none;">
                            <i class="bi bi-plus-circle me-1"></i> New Counter
                        </button>
                    </div>
                </div>

                <!-- Desktop & Tablet Table (>= 768px) -->
                <div class="table-responsive d-none d-md-block">
                    <table class="crisp-table table-counters">
                        <thead>
                            <tr>
                                <th class="col-c-id" style="width:56px;text-align:center;">#</th>
                                <th class="col-c-name" style="width:230px;text-align:left;">Counter Name</th>
                                <th class="col-c-regions" style="width:280px;text-align:left;">Regions / Range Covered</th>
                                <th class="col-c-user" style="width:280px;text-align:left;">Counter Username</th>
                                <th class="col-c-visitors" style="width:90px;text-align:center;">Visitors</th>
                                <th class="col-c-distributed" style="width:120px;text-align:center;">Distributed</th>
                                <th class="col-c-pending" style="width:100px;text-align:center;">Pending</th>
                                <th class="col-c-login" style="width:170px;text-align:center;">Last Login (IST)</th>
                                <th class="col-c-status" style="width:110px;text-align:center;">Status</th>
                                <th class="col-c-actions" style="width:230px;text-align:right;padding-right:16px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($countersList)): ?>
                                <tr class="tr-empty">
                                    <td colspan="10" style="text-align:center;padding:3rem;color:var(--text-muted);">
                                        <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:8px;opacity:0.4;"></i>
                                        No counter accounts found. Click "New Counter" to create one.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($countersList as $cIdx => $c): 
                                    $cStatus = $c['status'] ?? ($c['admin_status'] ?? ((int)($c['is_active'] ?? 1) === 1 ? 'active' : 'disabled'));
                                    $isActive = ((int)($c['is_active'] ?? 1) === 1 && $cStatus === 'active');
                                    $tot = (int)($c['total_visitors'] ?? 0);
                                    $giv = (int)($c['kits_distributed'] ?? 0);
                                    $pen = (int)($c['kits_pending'] ?? 0);
                                    $pct = $tot > 0 ? round(($giv / $tot) * 100) : 0;
                                ?>
                                    <tr>
                                        <td class="col-c-id" style="text-align:center;">
                                            <span class="id-badge">#<?= $cIdx + 1 ?></span>
                                        </td>
                                        <td class="col-c-name">
                                            <strong class="counter-name-text" title="<?= htmlspecialchars($c['name']) ?>"><?= htmlspecialchars($c['name']) ?></strong>
                                        </td>
                                        <td class="col-c-regions">
                                            <div class="region-chips-wrap">
                                                <?php if (!empty($c['name_range'])): ?>
                                                    <span class="range-chip" title="<?= htmlspecialchars($c['name_range']) ?>">
                                                        <i class="bi bi-sort-alpha-down"></i> <?= htmlspecialchars($c['name_range']) ?>
                                                    </span>
                                                <?php elseif ($c['code'] === 'helpdesk' || $c['name'] === 'Help Desk'): ?>
                                                    <span class="region-chip" style="background:#fef2f2;color:#991b1b;border-color:#fecaca;">
                                                        <i class="bi bi-question-circle"></i> Unassigned / Help Desk
                                                    </span>
                                                <?php elseif (!empty($c['regions_covered'])): 
                                                    $rChips = array_filter(array_map('trim', explode(',', (string)$c['regions_covered'])));
                                                    foreach ($rChips as $rc): ?>
                                                        <span class="region-chip">
                                                            <i class="bi bi-geo-alt-fill text-primary"></i> <?= htmlspecialchars($rc) ?>
                                                        </span>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <span class="text-muted small">—</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="col-c-user">
                                            <div class="counter-user-box">
                                                <code class="counter-user-code" title="<?= htmlspecialchars($c['username']) ?>">
                                                    <?= htmlspecialchars($c['username']) ?>
                                                </code>
                                                <button type="button" class="btn-copy-uname" onclick="copyCounterUsername('<?= htmlspecialchars(addslashes($c['username'])) ?>', this)" title="Copy username">
                                                    <i class="bi bi-clipboard"></i>
                                                </button>
                                            </div>
                                        </td>
                                        <td class="col-c-visitors" style="text-align:center;">
                                            <strong class="text-dark"><?= number_format($tot) ?></strong>
                                        </td>
                                        <td class="col-c-distributed" style="text-align:center;">
                                            <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1 rounded-pill fw-bold">
                                                <?= number_format($giv) ?> (<?= $pct ?>%)
                                            </span>
                                        </td>
                                        <td class="col-c-pending" style="text-align:center;">
                                            <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle px-2 py-1 rounded-pill fw-bold">
                                                <?= number_format($pen) ?>
                                            </span>
                                        </td>
                                        <td class="col-c-login" style="text-align:center;font-size:0.82rem;color:var(--text-muted);">
                                            <?php if (!empty($c['last_login'])): ?>
                                                <i class="bi bi-clock-history text-success me-1"></i><?= htmlspecialchars(formatIST($c['last_login'], 'd M Y, h:i A')) ?>
                                            <?php else: ?>
                                                <span class="text-muted italic">Never logged in</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="col-c-status" style="text-align:center;">
                                            <?php if ($isActive): ?>
                                                <span class="badge bg-success-subtle text-success border border-success-subtle px-2.5 py-1 rounded-pill fw-bold">
                                                    <i class="bi bi-check-circle-fill me-1"></i> Active
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2.5 py-1 rounded-pill fw-bold">
                                                    <i class="bi bi-slash-circle-fill me-1"></i> Disabled
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="col-c-actions" style="text-align:right;padding-right:16px;">
                                            <div class="counter-actions-wrap">
                                                <button type="button" class="btn btn-outline-primary btn-counter-action" 
                                                        onclick="confirmResetCounterPassword(<?= (int)$c['id'] ?>, '<?= htmlspecialchars(addslashes($c['username'])) ?>', '<?= htmlspecialchars(addslashes($c['name'])) ?>')"
                                                        title="Generate and reset password">
                                                    <i class="bi bi-key"></i> <span>Reset Pwd</span>
                                                </button>
                                                <a href="admin.php?tab=counters&action=toggle_counter_status&counter_id=<?= (int)$c['id'] ?>" 
                                                   class="btn <?= $isActive ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-counter-action"
                                                   onclick="return confirm('Are you sure you want to <?= $isActive ? 'DISABLE' : 'ENABLE' ?> <?= htmlspecialchars(addslashes($c['name'])) ?>?');"
                                                   title="<?= $isActive ? 'Disable booth login' : 'Enable booth login' ?>">
                                                    <i class="bi bi-<?= $isActive ? 'pause-circle' : 'play-circle' ?>"></i> <span><?= $isActive ? 'Disable' : 'Enable' ?></span>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-total-row" style="background:#f8fafc;font-weight:700;border-top:2px solid #cbd5e1;">
                                <td class="col-c-id" style="text-align:center;">
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis rounded-pill">Total</span>
                                </td>
                                <td class="col-c-name" style="font-weight:700;color:var(--text-dark);">
                                    <?= $totalCountersCount ?> Regional Counters
                                </td>
                                <td class="col-c-regions" style="color:var(--text-muted);font-size:0.82rem;">
                                    <?= $activeCountersCount ?> active &bull; <?= $totalCountersCount - $activeCountersCount ?> disabled
                                </td>
                                <td class="col-c-user" style="color:var(--text-muted);font-size:0.82rem;">
                                    All booth credentials synced
                                </td>
                                <td class="col-c-visitors" style="text-align:center;font-weight:800;color:var(--text-dark);font-size:0.95rem;">
                                    <?= number_format($totalCountersVisitors) ?>
                                </td>
                                <td class="col-c-distributed" style="text-align:center;font-weight:800;color:var(--success);font-size:0.95rem;">
                                    <?= number_format($totalCountersGiven) ?> (<?= $totalCountersVisitors > 0 ? round(($totalCountersGiven / $totalCountersVisitors) * 100) : 0 ?>%)
                                </td>
                                <td class="col-c-pending" style="text-align:center;font-weight:800;color:#d97706;font-size:0.95rem;">
                                    <?= number_format($totalCountersPending) ?>
                                </td>
                                <td colspan="3" class="col-c-actions" style="text-align:right;padding-right:16px;color:var(--text-muted);font-size:0.82rem;font-weight:600;">
                                    <?php if ($totalCountersVisitors === 1270 || ($totalDbVisitors > 0 && $totalCountersVisitors === $totalDbVisitors)): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-1.5 rounded-pill fw-bold">
                                            <i class="bi bi-check-circle-fill me-1"></i> Total <?= number_format($totalCountersVisitors) ?> &bull; Balanced
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-1.5 rounded-pill fw-bold">
                                            <i class="bi bi-exclamation-triangle-fill me-1"></i> Total <?= $totalCountersVisitors ?> &bull; Mismatch (<?= $totalDbVisitors ?: 1270 ?> expected)
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <!-- Mobile Cards View (< 768px) -->
                <div class="counters-mobile-list d-block d-md-none">
                    <?php if (empty($countersList)): ?>
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1 d-block mb-2 opacity-50"></i>
                            No counter accounts found. Click "New Counter" to create one.
                        </div>
                    <?php else: ?>
                        <?php foreach ($countersList as $cIdx => $c): 
                            $cStatus = $c['status'] ?? ($c['admin_status'] ?? ((int)($c['is_active'] ?? 1) === 1 ? 'active' : 'disabled'));
                            $isActive = ((int)($c['is_active'] ?? 1) === 1 && $cStatus === 'active');
                            $tot = (int)($c['total_visitors'] ?? 0);
                            $giv = (int)($c['kits_distributed'] ?? 0);
                            $pen = (int)($c['kits_pending'] ?? 0);
                            $pct = $tot > 0 ? round(($giv / $tot) * 100) : 0;
                        ?>
                            <div class="counter-mobile-card">
                                <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                                    <div class="d-flex align-items-center gap-1.5 flex-wrap">
                                        <span class="id-badge">#<?= $cIdx + 1 ?></span>
                                        <strong class="cmc-name"><?= htmlspecialchars($c['name']) ?></strong>
                                    </div>
                                    <div>
                                        <?php if ($isActive): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-0.5 rounded-pill fw-bold" style="font-size:0.75rem;">
                                                <i class="bi bi-check-circle-fill me-1"></i> Active
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-0.5 rounded-pill fw-bold" style="font-size:0.75rem;">
                                                <i class="bi bi-slash-circle-fill me-1"></i> Disabled
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="mb-2">
                                    <div class="region-chips-wrap">
                                        <?php if (!empty($c['name_range'])): ?>
                                            <span class="range-chip" title="<?= htmlspecialchars($c['name_range']) ?>">
                                                <i class="bi bi-sort-alpha-down"></i> <?= htmlspecialchars($c['name_range']) ?>
                                            </span>
                                        <?php elseif ($c['code'] === 'helpdesk' || $c['name'] === 'Help Desk'): ?>
                                            <span class="region-chip" style="background:#fef2f2;color:#991b1b;border-color:#fecaca;">
                                                <i class="bi bi-question-circle"></i> Unassigned / Help Desk
                                            </span>
                                        <?php elseif (!empty($c['regions_covered'])): 
                                            $rChips = array_filter(array_map('trim', explode(',', (string)$c['regions_covered'])));
                                            foreach ($rChips as $rc): ?>
                                                <span class="region-chip">
                                                    <i class="bi bi-geo-alt-fill text-primary"></i> <?= htmlspecialchars($rc) ?>
                                                </span>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <span class="text-muted small">—</span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="mb-2.5">
                                    <div class="counter-user-box">
                                        <code class="counter-user-code" style="max-width:calc(100% - 36px);">
                                            <?= htmlspecialchars($c['username']) ?>
                                        </code>
                                        <button type="button" class="btn-copy-uname" onclick="copyCounterUsername('<?= htmlspecialchars(addslashes($c['username'])) ?>', this)" title="Copy username">
                                            <i class="bi bi-clipboard"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="cmc-stats-grid mb-2.5">
                                    <div class="cmc-stat-box">
                                        <div class="cmc-stat-label">Visitors</div>
                                        <div class="cmc-stat-val fw-bold text-dark"><?= number_format($tot) ?></div>
                                    </div>
                                    <div class="cmc-stat-box">
                                        <div class="cmc-stat-label">Distributed</div>
                                        <div class="cmc-stat-val fw-bold text-success"><?= number_format($giv) ?> <small class="text-muted" style="font-size:0.75rem;">(<?= $pct ?>%)</small></div>
                                    </div>
                                    <div class="cmc-stat-box">
                                        <div class="cmc-stat-label">Pending</div>
                                        <div class="cmc-stat-val fw-bold text-warning-emphasis"><?= number_format($pen) ?></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center mb-2.5 small text-muted" style="font-size:0.78rem;">
                                    <span><i class="bi bi-clock-history me-1"></i> Last Login:</span>
                                    <span><?= !empty($c['last_login']) ? htmlspecialchars(formatIST($c['last_login'], 'd M Y, h:i A')) : 'Never logged in' ?></span>
                                </div>

                                <div class="d-flex gap-2 w-100">
                                    <button type="button" class="btn btn-outline-primary btn-counter-action flex-fill" 
                                            onclick="confirmResetCounterPassword(<?= (int)$c['id'] ?>, '<?= htmlspecialchars(addslashes($c['username'])) ?>', '<?= htmlspecialchars(addslashes($c['name'])) ?>')"
                                            style="width:50% !important;min-width:0 !important;max-width:none !important;">
                                        <i class="bi bi-key"></i> <span>Reset Pwd</span>
                                    </button>
                                    <a href="admin.php?tab=counters&action=toggle_counter_status&counter_id=<?= (int)$c['id'] ?>" 
                                       class="btn <?= $isActive ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-counter-action flex-fill"
                                       onclick="return confirm('Are you sure you want to <?= $isActive ? 'DISABLE' : 'ENABLE' ?> <?= htmlspecialchars(addslashes($c['name'])) ?>?');"
                                       style="width:50% !important;min-width:0 !important;max-width:none !important;">
                                        <i class="bi bi-<?= $isActive ? 'pause-circle' : 'play-circle' ?>"></i> <span><?= $isActive ? 'Disable' : 'Enable' ?></span>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <!-- Mobile Summary Card -->
                        <div class="counter-mobile-card counter-total-card" style="background:#f8fafc;border:2px solid #cbd5e1;">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <strong class="text-dark">Total All Booths</strong>
                                <span class="badge bg-primary text-white rounded-pill px-2.5 py-1 fw-bold">Total <?= number_format($totalCountersVisitors) ?></span>
                            </div>
                            <div class="cmc-stats-grid mb-2">
                                <div class="cmc-stat-box">
                                    <div class="cmc-stat-label">Total Visitors</div>
                                    <div class="cmc-stat-val fw-bold text-dark"><?= number_format($totalCountersVisitors) ?></div>
                                </div>
                                <div class="cmc-stat-box">
                                    <div class="cmc-stat-label">Distributed</div>
                                    <div class="cmc-stat-val fw-bold text-success"><?= number_format($totalCountersGiven) ?></div>
                                </div>
                                <div class="cmc-stat-box">
                                    <div class="cmc-stat-label">Pending</div>
                                    <div class="cmc-stat-val fw-bold text-warning-emphasis"><?= number_format($totalCountersPending) ?></div>
                                </div>
                            </div>
                            <div class="small text-center text-success fw-semibold">
                                <i class="bi bi-check-circle-fill me-1"></i> <?= $totalCountersCount ?> Counters (<?= $activeCountersCount ?> Active) &bull; Balanced
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php elseif ($isGate): ?>
            <!-- ============================================================
                 GATE ENTRY TABLE (Tab: gate - 2-Day Event Tracking)
                 ============================================================ -->
            <div class="content-card">
                <div class="content-card-header">
                    <div class="content-card-title">
                        <div class="card-icon-dot mi-blue" style="background:rgba(29,88,216,0.1);color:var(--blue);">
                            <i class="bi bi-table"></i>
                        </div>
                        2-Day Gate Entry Check-In Log
                    </div>
                    <span id="gateSubtitle" style="font-size:0.8rem;color:var(--text-muted);">
                        <?= count($gateVisitors) ?> visitors &bull; Latest check-in first
                    </span>
                </div>

                <!-- Filter Bar -->
                <div class="filter-bar">
                    <form method="GET" class="filter-form">
                        <input type="hidden" name="tab" value="gate">
                        <input type="hidden" name="gfilter" value="<?= htmlspecialchars($gFilter) ?>">

                        <div class="filter-search-row">
                            <div class="search-field-wrap">
                                <i class="bi bi-search"></i>
                                <input type="text" name="gsearch" class="search-field" placeholder="Search name, Register Id, fincert, mobile, region, school…" value="<?= htmlspecialchars($gSearch) ?>">
                            </div>

                            <div class="region-select-wrap">
                                <select name="gregion" class="form-select region-select" onchange="this.form.submit()">
                                    <option value="">All Regions (<?= count($allRegions) ?>)</option>
                                    <?php foreach ($allRegions as $reg): 
                                        $cnt = $gateRegionCounts[$reg] ?? 0;
                                    ?>
                                        <option value="<?= htmlspecialchars($reg) ?>" <?= $gRegion === $reg ? 'selected' : '' ?>>
                                             <?= htmlspecialchars($reg) ?><?= $cnt > 0 ? " ({$cnt})" : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <button type="submit" class="filter-submit">
                                <i class="bi bi-funnel"></i> <span>Filter</span>
                            </button>
                            <?php if ($gSearch !== '' || $gFilter !== 'all' || $gRegion !== ''): ?>
                                <a href="admin.php?tab=gate" class="filter-clear" title="Clear all filters">
                                    <i class="bi bi-x-lg"></i>
                                </a>
                            <?php endif; ?>
                        </div>

                        <div class="filter-btn-group">
                            <a href="admin.php?tab=gate&gfilter=all<?= !empty($gSearch) ? '&gsearch=' . urlencode($gSearch) : '' ?><?= !empty($gRegion) ? '&gregion=' . urlencode($gRegion) : '' ?>"
                               class="filter-btn <?= $gFilter === 'all' ? 'active-all' : '' ?>">
                                All (<span id="badgeGateAll"><?= $totalVisitors ?></span>)
                            </a>
                            <a href="admin.php?tab=gate&gfilter=day1<?= !empty($gSearch) ? '&gsearch=' . urlencode($gSearch) : '' ?><?= !empty($gRegion) ? '&gregion=' . urlencode($gRegion) : '' ?>"
                               class="filter-btn <?= $gFilter === 'day1' ? 'active-green' : '' ?>">
                                Day 1 Inside (<span id="badgeGateD1"><?= $d1Count ?></span>)
                            </a>
                            <a href="admin.php?tab=gate&gfilter=day2<?= !empty($gSearch) ? '&gsearch=' . urlencode($gSearch) : '' ?><?= !empty($gRegion) ? '&gregion=' . urlencode($gRegion) : '' ?>"
                               class="filter-btn <?= $gFilter === 'day2' ? 'active-teal' : '' ?>">
                                Day 2 Inside (<span id="badgeGateD2"><?= $d2Count ?></span>)
                            </a>
                            <a href="admin.php?tab=gate&gfilter=pending_both<?= !empty($gSearch) ? '&gsearch=' . urlencode($gSearch) : '' ?><?= !empty($gRegion) ? '&gregion=' . urlencode($gRegion) : '' ?>"
                               class="filter-btn <?= $gFilter === 'pending_both' ? 'active-amber' : '' ?>">
                                Pending Both (<span id="badgeGatePending"><?= $pendingBothCount ?></span>)
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="crisp-table table-gate">
                        <thead>
                            <tr>
                                <th class="col-id">#</th>
                                <th class="col-name">Full Name</th>
                                <th class="col-userid">Register Id</th>
                                <th class="col-region">Region</th>
                                <th class="col-mobile">Mobile Number</th>
                                <th class="col-status-d1">Day 1 Status</th>
                                <th class="col-status-d2">Day 2 Status</th>
                                <th class="col-actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="gateTableBody" data-start-offset="<?= $gateOffset ?>">
                            <?= renderGateTableRows($gateVisibleVisitors, $gFilter, $gSearch, $gRegion, $gPage, $gateOffset) ?>
                        </tbody>
                    </table>
                </div>

                <?= renderPagination($gPage, $totalGatePages, $totalGateRows, $perPage, 'gate', [
                    'gfilter' => $gFilter,
                    'gsearch' => $gSearch,
                    'gregion' => $gRegion,
                ]) ?>
            </div>

            <?php else: ?>
            <!-- ============================================================
                 COE KIT DISTRIBUTION TABLE (Tab: gift)
                 ============================================================ -->

            <div class="content-card">
                <div class="content-card-header">
                    <div class="content-card-title">
                        <div class="card-icon-dot" style="background:rgba(139,92,246,0.1);color:var(--purple);width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;">
                            <i class="bi bi-box-seam"></i>
                        </div>
                        COE Kit Distribution Log
                    </div>
                    <span id="giftSubtitle" style="font-size:0.8rem;color:var(--text-muted);">
                        <?= count($giftVisitors) ?> attendees &bull; Latest check-in first
                    </span>
                </div>

                <!-- Filter Bar -->
                <div class="filter-bar">
                    <form method="GET" class="filter-form">
                        <input type="hidden" name="tab" value="gift">
                        <input type="hidden" name="dfilter" value="<?= htmlspecialchars($dFilter) ?>">

                        <div class="filter-search-row">
                            <div class="search-field-wrap">
                                <i class="bi bi-search"></i>
                                <input type="text" name="dsearch" class="search-field" placeholder="Search name, Register Id, fincert, mobile, region, school…" value="<?= htmlspecialchars($dSearch) ?>">
                            </div>

                            <?php if ($isCounter): ?>
                                <?php if (!empty($counterAllowedRegions) && count($counterAllowedRegions) > 1): ?>
                                    <div class="region-select-wrap">
                                        <select name="dregion" class="form-select region-select" onchange="this.form.submit()">
                                            <option value="">All Regions in Counter (<?= count($counterAllowedRegions) ?>)</option>
                                            <?php foreach ($counterAllowedRegions as $cr): ?>
                                                <option value="<?= htmlspecialchars($cr) ?>" <?= $dRegion === $cr ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($cr) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php else: ?>
                                    <div class="region-select-wrap">
                                        <span class="badge" style="background:rgba(29,88,216,0.1);color:var(--blue);border:1px solid rgba(29,88,216,0.25);padding:8px 14px;border-radius:8px;font-size:0.85rem;font-weight:700;display:inline-flex;align-items:center;">
                                            <i class="bi bi-geo-alt-fill me-1"></i> <?= htmlspecialchars($roleLabel) ?> (<?= $totalGiftElig ?>)
                                        </span>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="region-select-wrap">
                                    <select name="dcounter" class="form-select region-select" onchange="this.form.submit()" style="min-width:180px;">
                                        <option value="0">All Counters (<?= count($countersList) ?>)</option>
                                        <?php foreach ($countersList as $cOpt): ?>
                                            <option value="<?= (int)$cOpt['id'] ?>" <?= $dCounter === (int)$cOpt['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($cOpt['name']) ?> (<?= (int)$cOpt['total_visitors'] ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="region-select-wrap">
                                    <select name="dregion" class="form-select region-select" onchange="this.form.submit()">
                                        <option value="">All Regions (<?= count($allRegions) ?>)</option>
                                        <?php foreach ($allRegions as $reg): 
                                            $cnt = $giftRegionCounts[$reg] ?? 0;
                                        ?>
                                            <option value="<?= htmlspecialchars($reg) ?>" <?= $dRegion === $reg ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($reg) ?><?= $cnt > 0 ? " ({$cnt})" : '' ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endif; ?>

                            <button type="submit" class="filter-submit">
                                <i class="bi bi-funnel"></i> <span>Filter</span>
                            </button>
                            <?php if ($dSearch !== '' || $dFilter !== 'all' || $dCounter > 0 || $dRegion !== ''): ?>
                                <a href="admin.php?tab=gift" class="filter-clear" title="Clear all filters">
                                    <i class="bi bi-x-lg"></i>
                                </a>
                            <?php endif; ?>
                        </div>

                        <?php 
                            $counterParam = ($dCounter > 0) ? '&dcounter=' . urlencode((string)$dCounter) : '';
                            $regionParam  = (!empty($dRegion)) ? '&dregion=' . urlencode($dRegion) : '';
                            $searchParam  = (!empty($dSearch)) ? '&dsearch=' . urlencode($dSearch) : '';
                            $baseFilterUrl = "admin.php?tab=gift{$searchParam}{$counterParam}{$regionParam}";
                        ?>
                        <div class="filter-btn-group">
                            <a href="<?= $baseFilterUrl ?>&dfilter=all"
                               class="filter-btn <?= $dFilter === 'all' ? 'active-all' : '' ?>">
                                All (<span id="badgeGiftAll"><?= $totalGiftElig ?></span>)
                            </a>
                            <a href="<?= $baseFilterUrl ?>&dfilter=collected"
                               class="filter-btn <?= $dFilter === 'collected' ? 'active-green' : '' ?>">
                                Kit Collected (<span id="badgeGiftGiven"><?= $giftsGiven ?></span>)
                            </a>
                            <a href="<?= $baseFilterUrl ?>&dfilter=pending"
                               class="filter-btn <?= $dFilter === 'pending' ? 'active-amber' : '' ?>">
                                Pending (<span id="badgeGiftPending"><?= $giftsPending ?></span>)
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="crisp-table table-gift">
                        <thead>
                            <tr>
                                <th class="col-id">#</th>
                                <th class="col-name">Full Name</th>
                                <th class="col-userid">Register Id</th>
                                <th class="col-region">Region &amp; Counter</th>
                                <th class="col-mobile">Mobile Number</th>
                                <th class="col-gift-status">Kit Status</th>
                                <th class="col-gift-time">Collection Timestamp</th>
                                <th class="col-actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="giftTableBody" data-start-offset="<?= $giftOffset ?>">
                            <?= renderGiftTableRows($giftVisibleVisitors, $dFilter, $dSearch, $dRegion, $dPage, $giftOffset, $dCounter) ?>
                        </tbody>
                    </table>
                </div>

                <?= renderPagination($dPage, $totalGiftPages, $totalGiftRows, $perPage, 'gift', [
                    'dfilter'  => $dFilter,
                    'dsearch'  => $dSearch,
                    'dcounter' => $dCounter,
                    'dregion'  => $dRegion,
                ]) ?>
            </div>

            <?php endif; ?>

        </div><!-- /content-body -->
    </main><!-- /main-panel -->

</div><!-- /app-shell -->

<?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'super_admin'): ?>
<!-- ================================================================
     CSV Import Modal (Synchronized Across Gate Entry & Gift Distribution)
     ================================================================ -->
<div class="modal fade" id="importCsvModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:460px;margin:0.75rem auto;padding:0 10px;">
        <div class="modal-content" style="border-radius:16px;overflow:hidden;border:1px solid var(--border-light);">
            <form method="POST" action="admin.php" enctype="multipart/form-data">
                <input type="hidden" name="action" value="import_csv">
                <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">

                <!-- Header -->
                <div style="background:var(--navy);padding:1.1rem 1.5rem;display:flex;align-items:center;justify-content:space-between;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div class="brand-icon" style="width:32px;height:32px;font-size:0.95rem;">
                            <i class="bi bi-cloud-arrow-up"></i>
                        </div>
                        <span style="font-weight:700;font-size:0.95rem;color:#ffffff;">Bulk Import Visitors (CSV)</span>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Body -->
                <div style="padding:1.5rem;background:#ffffff;">
                    <div style="background:#f8fafc;border:1px solid var(--border-light);border-radius:10px;padding:0.85rem 1rem;margin-bottom:1rem;font-size:0.82rem;color:var(--text-muted);">
                        <div style="display:flex;align-items:center;gap:7px;margin-bottom:6px;">
                            <i class="bi bi-info-circle-fill" style="color:var(--blue);font-size:1rem;"></i>
                            <strong style="color:var(--text-dark);">Supported CSV Formats (Auto-Mapped)</strong>
                        </div>
                        <div style="font-family:monospace;background:#ffffff;border:1px solid var(--border-light);border-radius:7px;padding:0.5rem 0.75rem;font-size:0.75rem;color:var(--text-dark);margin-bottom:6px;line-height:1.4;">
                            <strong>Extended / Exported:</strong> sno, region, userid, schname, umname, desig, contact, emaild, fincert<br>
                            <strong>Simple:</strong> Name, Mobile Number
                        </div>
                        <ul style="margin:0;padding-left:1.1rem;line-height:1.7;font-size:0.76rem;">
                            <li>Simultaneously syncs attendees across <strong>Gate Entry</strong> and <strong>COE Kit Distribution</strong>.</li>
                            <li>Preserves Register Id, Region, FinCert ID, and existing check-in / COE Kit timestamps.</li>
                            <li>Phone numbers are automatically sanitized (+91 / 0 stripped).</li>
                        </ul>
                    </div>
                    <div>
                        <label style="display:block;font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;color:#475569;margin-bottom:6px;">
                            <i class="bi bi-filetype-csv" style="color:var(--blue);margin-right:4px;"></i> Select CSV File
                        </label>
                        <input type="file" class="form-control" name="csv_file" accept=".csv,text/csv" required style="border-radius:9px;">
                    </div>
                </div>

                <!-- Footer -->
                <div style="padding:0.85rem 1.5rem;background:#f8fafc;border-top:1px solid var(--border-light);display:flex;justify-content:flex-end;gap:8px;">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-3 btn-sm fw-semibold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm rounded-pill px-4 fw-bold" style="background:var(--blue);color:#ffffff;">
                        <i class="bi bi-cloud-arrow-up me-1"></i> Upload &amp; Import
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ================================================================
     Create Counter Modal (Super Admin ONLY)
     ================================================================ -->
<div class="modal fade" id="createCounterModal" tabindex="-1" aria-labelledby="createCounterModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:440px;margin:1rem auto;padding:0 12px;">
        <div class="modal-content" style="border-radius:16px;overflow:hidden;border:1px solid var(--border-light);">
            <form method="POST" action="admin.php">
                <input type="hidden" name="action" value="create_counter">
                <input type="hidden" name="tab" value="counters">
                <div style="background:var(--navy);padding:1.1rem 1.4rem;display:flex;align-items:center;justify-content:space-between;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div class="brand-icon" style="width:32px;height:32px;font-size:0.95rem;background:rgba(29,88,216,0.2);color:var(--blue);">
                            <i class="bi bi-person-plus-fill"></i>
                        </div>
                        <span style="font-weight:700;font-size:0.95rem;color:#ffffff;" id="createCounterModalLabel">Create Regional Counter</span>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div style="padding:1.5rem;background:#ffffff;">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark">Region Name <span class="text-danger">*</span></label>
                        <input type="text" name="new_region" class="form-control" placeholder="e.g. Nagpur, Mumbai, Kolhapur" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark">Username <span class="text-muted fw-normal">(Optional, auto-generated)</span></label>
                        <input type="text" name="new_username" class="form-control" placeholder="e.g. counter_nagpur">
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-bold text-dark">Password <span class="text-muted fw-normal">(Optional, auto-generated)</span></label>
                        <input type="text" name="new_password" class="form-control" placeholder="Leave blank to generate a secure random password">
                    </div>
                </div>
                <div style="padding:0.85rem 1.4rem;background:#f8fafc;border-top:1px solid var(--border-light);display:flex;justify-content:flex-end;gap:8px;">
                    <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 fw-semibold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm rounded-pill px-4 fw-bold" style="background:var(--blue);border:none;">
                        <i class="bi bi-plus-circle me-1"></i> Create Counter
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ================================================================
     Reassign Counter Modal (Super Admin ONLY)
     ================================================================ -->
<?php if ($isSuperAdmin): ?>
<div class="modal fade" id="reassignCounterModal" tabindex="-1" aria-labelledby="reassignCounterModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:440px;margin:1rem auto;padding:0 12px;">
        <div class="modal-content" style="border-radius:16px;overflow:hidden;border:1px solid var(--border-light);box-shadow:0 12px 30px rgba(0,0,0,0.15);">
            <form method="POST" action="admin.php?tab=gift&action=reassign_counter">
                <input type="hidden" name="action" value="reassign_counter">
                <input type="hidden" name="visitor_id" id="reassignVisitorId" value="">
                <input type="hidden" name="dfilter" value="<?= htmlspecialchars($dFilter) ?>">
                <input type="hidden" name="dpage" value="<?= (int)$dPage ?>">
                <input type="hidden" name="dsearch" value="<?= htmlspecialchars($dSearch) ?>">
                <input type="hidden" name="dcounter" value="<?= (int)$dCounter ?>">
                <input type="hidden" name="dregion" value="<?= htmlspecialchars($dRegion) ?>">

                <div style="background:var(--navy);padding:1.1rem 1.4rem;display:flex;align-items:center;justify-content:space-between;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div class="brand-icon" style="width:32px;height:32px;font-size:0.95rem;background:rgba(29,88,216,0.2);color:var(--blue);">
                            <i class="bi bi-arrow-left-right"></i>
                        </div>
                        <span style="font-weight:700;font-size:0.95rem;color:#ffffff;" id="reassignCounterModalLabel">Reassign Attendee Counter</span>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div style="padding:1.5rem;background:#ffffff;">
                    <p class="text-muted small mb-3">
                        Reassign <strong id="reassignVisitorName" class="text-dark">Attendee</strong> to a different COE Kit distribution counter:
                    </p>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark">TARGET COUNTER <span class="text-danger">*</span></label>
                        <select name="new_counter_id" id="reassignTargetCounter" class="form-select" required>
                            <?php foreach ($countersList as $cOpt): ?>
                                <option value="<?= (int)$cOpt['id'] ?>">
                                    <?= htmlspecialchars($cOpt['name']) ?><?= !empty($cOpt['name_range']) ? " ({$cOpt['name_range']})" : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-bold text-dark">REASON / NOTE <span class="text-muted fw-normal">(Optional)</span></label>
                        <input type="text" name="reason" class="form-control form-control-sm" placeholder="e.g. Pune queue rebalance, attendee arrived at counter 2">
                    </div>
                </div>
                <div style="padding:0.85rem 1.4rem;background:#f8fafc;border-top:1px solid var(--border-light);display:flex;justify-content:flex-end;gap:8px;">
                    <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 fw-semibold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm rounded-pill px-4 fw-bold" style="background:var(--blue);border:none;">
                        <i class="bi bi-check2-circle me-1"></i> Confirm Move
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($_SESSION['counter_pwd_reset'])): 
    $pwdInfo = $_SESSION['counter_pwd_reset'];
    unset($_SESSION['counter_pwd_reset']);
?>
<!-- Temporary Password Display Modal -->
<div class="modal fade show" id="tempPwdModal" tabindex="-1" style="display:block;background:rgba(15,28,48,0.6);" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" style="max-width:440px;margin:1rem auto;padding:0 12px;">
        <div class="modal-content" style="border-radius:16px;overflow:hidden;border:1px solid var(--border-light);box-shadow:0 12px 30px rgba(0,0,0,0.15);">
            <div style="background:var(--navy);padding:1.1rem 1.4rem;display:flex;align-items:center;justify-content:space-between;">
                <div style="display:flex;align-items:center;gap:10px;">
                    <div class="brand-icon" style="width:32px;height:32px;font-size:0.95rem;background:rgba(16,185,129,0.2);color:#10b981;">
                        <i class="bi bi-key-fill"></i>
                    </div>
                    <span style="font-weight:700;font-size:0.95rem;color:#ffffff;">New Counter Credentials</span>
                </div>
                <button type="button" class="btn-close btn-close-white" onclick="document.getElementById('tempPwdModal').style.display='none';"></button>
            </div>
            <div style="padding:1.5rem;background:#ffffff;">
                <div class="alert alert-warning border-warning-subtle text-warning-emphasis py-2 px-3 mb-3 small">
                    <i class="bi bi-exclamation-triangle-fill me-1 text-warning"></i>
                    <strong>Copy password now!</strong> This password will not be shown again.
                </div>
                <div class="mb-2">
                    <span class="text-muted small">Region:</span> <strong><?= htmlspecialchars($pwdInfo['region']) ?></strong>
                </div>
                <div class="mb-3">
                    <span class="text-muted small">Username:</span> <code class="fw-bold px-2 py-0.5 bg-light rounded border text-dark"><?= htmlspecialchars($pwdInfo['username']) ?></code>
                </div>
                <div class="mb-3">
                    <label class="small text-muted fw-bold d-block mb-1">Generated Password:</label>
                    <div class="input-group">
                        <input type="text" id="copyPasswordInput" class="form-control font-monospace fw-bold text-primary" value="<?= htmlspecialchars($pwdInfo['password']) ?>" readonly>
                        <button class="btn btn-outline-primary" type="button" id="copyPwdBtn" onclick="copyCounterPwd()">
                            <i class="bi bi-clipboard me-1"></i> Copy
                        </button>
                    </div>
                </div>
            </div>
            <div style="padding:0.85rem 1.4rem;background:#f8fafc;border-top:1px solid var(--border-light);display:flex;justify-content:flex-end;">
                <button type="button" class="btn btn-primary rounded-pill px-4 btn-sm fw-bold" onclick="document.getElementById('tempPwdModal').style.display='none';" style="background:var(--blue);border:none;">
                    Done
                </button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php endif; ?>

<?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'super_admin'): ?>
<!-- ================================================================
     CSV Import Modal (Synchronized Across Gate Entry & Gift Distribution)
     ================================================================ -->
<div class="modal fade" id="importCsvModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:460px;margin:0.75rem auto;padding:0 10px;">
        <div class="modal-content" style="border-radius:16px;overflow:hidden;border:1px solid var(--border-light);">
            <form method="POST" action="admin.php" enctype="multipart/form-data">
                <input type="hidden" name="action" value="import_csv">
                <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">

                <!-- Header -->
                <div style="background:var(--navy);padding:1.1rem 1.5rem;display:flex;align-items:center;justify-content:space-between;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div class="brand-icon" style="width:32px;height:32px;font-size:0.95rem;">
                            <i class="bi bi-cloud-arrow-up"></i>
                        </div>
                        <span style="font-weight:700;font-size:0.95rem;color:#ffffff;">Bulk Import Visitors (CSV)</span>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Body -->
                <div style="padding:1.5rem;background:#ffffff;">
                    <div style="background:#f8fafc;border:1px solid var(--border-light);border-radius:10px;padding:0.85rem 1rem;margin-bottom:1rem;font-size:0.82rem;color:var(--text-muted);">
                        <div style="display:flex;align-items:center;gap:7px;margin-bottom:6px;">
                            <i class="bi bi-info-circle-fill" style="color:var(--blue);font-size:1rem;"></i>
                            <strong style="color:var(--text-dark);">Supported CSV Formats (Auto-Mapped)</strong>
                        </div>
                        <div style="font-family:monospace;background:#ffffff;border:1px solid var(--border-light);border-radius:7px;padding:0.5rem 0.75rem;font-size:0.75rem;color:var(--text-dark);margin-bottom:6px;line-height:1.4;">
                            <strong>Extended / Exported:</strong> sno, region, userid, schname, umname, desig, contact, emaild, fincert<br>
                            <strong>Simple:</strong> Name, Mobile Number
                        </div>
                        <ul style="margin:0;padding-left:1.1rem;line-height:1.7;font-size:0.76rem;">
                            <li>Simultaneously syncs attendees across <strong>Gate Entry</strong> and <strong>COE Kit Distribution</strong>.</li>
                            <li>Preserves Register Id, Region, FinCert ID, and existing check-in / COE Kit timestamps.</li>
                            <li>Phone numbers are automatically sanitized (+91 / 0 stripped).</li>
                        </ul>
                    </div>
                    <div>
                        <label style="display:block;font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;color:#475569;margin-bottom:6px;">
                            <i class="bi bi-filetype-csv" style="color:var(--blue);margin-right:4px;"></i> Select CSV File
                        </label>
                        <input type="file" class="form-control" name="csv_file" accept=".csv,text/csv" required style="border-radius:9px;">
                    </div>
                </div>

                <!-- Footer -->
                <div style="padding:0.85rem 1.5rem;background:#f8fafc;border-top:1px solid var(--border-light);display:flex;justify-content:flex-end;gap:8px;">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-3 btn-sm fw-semibold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm rounded-pill px-4 fw-bold" style="background:var(--blue);color:#ffffff;">
                        <i class="bi bi-cloud-arrow-up me-1"></i> Upload &amp; Import
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Sidebar Toggle (Mobile)
const sidebar        = document.getElementById('sidebar');
const sidebarToggle  = document.getElementById('sidebarToggle');
const sidebarOverlay = document.getElementById('sidebarOverlay');

function openSidebar() {
    sidebar.classList.add('open');
    sidebarOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('open');
    document.body.style.overflow = '';
}

if (sidebarToggle) {
    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
}

if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
}

// Close sidebar on Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeSidebar();
});

// Auto-close sidebar on mobile when navigation links or buttons are clicked
document.querySelectorAll('#sidebar .nav-item-link, #sidebar .btn-logout-sidebar').forEach(el => {
    el.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
            closeSidebar();
        }
    });
});

// =========================================================================
// Flash Notice Auto-Dismiss & URL Cleanup
// =========================================================================
const NOTIFICATION_DURATION_DEFAULT = 1000; // 1 second auto-dismiss
const NOTIFICATION_DURATION_ERROR   = 3000; // 3 seconds for genuine error alerts

let flashNoticeTimer = null;

function dismissFlashNotice(el) {
    if (!el || el.classList.contains('flash-dismissing')) return;
    if (flashNoticeTimer) {
        clearTimeout(flashNoticeTimer);
        flashNoticeTimer = null;
    }
    el.classList.add('flash-dismissing');
    setTimeout(() => {
        if (el.parentNode) {
            el.parentNode.removeChild(el);
        }
    }, 260);
}
window.dismissFlashNotice = dismissFlashNotice;

function initFlashNoticeDismissal() {
    const notice = document.querySelector('.flash-notice');
    if (!notice) return;

    if (flashNoticeTimer) {
        clearTimeout(flashNoticeTimer);
        flashNoticeTimer = null;
    }

    const isError = notice.dataset.isError === 'true';
    const duration = isError ? NOTIFICATION_DURATION_ERROR : NOTIFICATION_DURATION_DEFAULT;

    flashNoticeTimer = setTimeout(() => {
        dismissFlashNotice(notice);
    }, duration);

    // Clean `msg` and related query parameters from browser URL address bar immediately
    // so manual refresh will never re-trigger or stick the banner
    try {
        const url = new URL(window.location.href);
        let changed = false;
        ['msg', 'count', 'skipped', 'import_success'].forEach(p => {
            if (url.searchParams.has(p)) {
                url.searchParams.delete(p);
                changed = true;
            }
        });
        if (changed) {
            const query = url.searchParams.toString();
            const newUrl = url.pathname + (query ? '?' + query : '') + url.hash;
            window.history.replaceState(null, '', newUrl);
        }
    } catch (e) {
        // Fallback safety
    }
}

// Initialize on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFlashNoticeDismissal);
} else {
    initFlashNoticeDismissal();
}

// =========================================================================
// Client-Side Live Sorting & Polling Engine
// =========================================================================

function parseUtcEpoch(str) {
    if (!str) return 0;
    let s = String(str).trim();
    if (s === '' || s === '0000-00-00 00:00:00' || s === '0000-00-00') return 0;
    if (!/[Zz]|[+-]\d{2}:?\d{2}$/.test(s)) {
        s = s.replace(' ', 'T') + 'Z';
    }
    const d = new Date(s);
    return isNaN(d.getTime()) ? 0 : d.getTime();
}

/**
 * Re-sorts table rows in the DOM so that:
 * Gate: latest activity (max of Day 1 & Day 2) comes FIRST, pending comes AFTER (A-Z), ties broken by name A-Z.
 * Gift: collected gifts come FIRST (newest on top), pending comes AFTER (A-Z), ties broken by name A-Z.
 * Updates the # serial number badge to 1, 2, 3...
 */
function sortAdminRows(tbody, type = 'gate') {
    if (!tbody) return;
    const rows = Array.from(tbody.querySelectorAll('tr[data-id]'));
    if (!rows.length) return;

    rows.sort((a, b) => {
        if (type === 'gate') {
            const aD1 = (a.dataset.d1Checked === '1' && a.dataset.d1Time) ? parseUtcEpoch(a.dataset.d1Time) : 0;
            const aD2 = (a.dataset.d2Checked === '1' && a.dataset.d2Time) ? parseUtcEpoch(a.dataset.d2Time) : 0;
            const aTime = Math.max(aD1, aD2);

            const bD1 = (b.dataset.d1Checked === '1' && b.dataset.d1Time) ? parseUtcEpoch(b.dataset.d1Time) : 0;
            const bD2 = (b.dataset.d2Checked === '1' && b.dataset.d2Time) ? parseUtcEpoch(b.dataset.d2Time) : 0;
            const bTime = Math.max(bD1, bD2);

            const aHas = aTime > 0;
            const bHas = bTime > 0;

            if (aHas && !bHas) return -1;
            if (!aHas && bHas) return 1;

            if (aHas && bHas) {
                if (aTime !== bTime) {
                    return bTime - aTime; // Newest first
                }
                return (a.dataset.name || '').localeCompare(b.dataset.name || '', undefined, { sensitivity: 'base' });
            }
            return (a.dataset.name || '').localeCompare(b.dataset.name || '', undefined, { sensitivity: 'base' });
        } else {
            const aTime = (a.dataset.giftCollected === '1' && a.dataset.giftTime) ? parseUtcEpoch(a.dataset.giftTime) : 0;
            const bTime = (b.dataset.giftCollected === '1' && b.dataset.giftTime) ? parseUtcEpoch(b.dataset.giftTime) : 0;

            const aHas = aTime > 0;
            const bHas = bTime > 0;

            if (aHas && !bHas) return -1;
            if (!aHas && bHas) return 1;

            if (aHas && bHas) {
                if (aTime !== bTime) {
                    return bTime - aTime; // Newest first
                }
                return (a.dataset.name || '').localeCompare(b.dataset.name || '', undefined, { sensitivity: 'base' });
            }
            return (a.dataset.name || '').localeCompare(b.dataset.name || '', undefined, { sensitivity: 'base' });
        }
    });

    // Re-append in sorted order and update serial numbers
    const startOffset = parseInt(tbody.dataset.startOffset || '0', 10);
    rows.forEach((row, idx) => {
        tbody.appendChild(row);
        const badge = row.querySelector('.id-badge');
        if (badge) {
            badge.textContent = '#' + (startOffset + idx + 1);
        }
    });
}
window.sortAdminRows = sortAdminRows;

// Counter Management Helpers (Super Admin)
function copyCounterUsername(uname, btn) {
    if (!uname) return;
    function showOk() {
        if (!btn) return;
        const icon = btn.querySelector('i');
        if (icon) {
            const orig = icon.className;
            icon.className = 'bi bi-check2 text-success';
            setTimeout(() => { icon.className = orig; }, 1200);
        }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(uname).then(showOk).catch(() => {
            const ta = document.createElement('textarea');
            ta.value = uname;
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand('copy'); showOk(); } catch (err) {}
            document.body.removeChild(ta);
        });
    } else {
        const ta = document.createElement('textarea');
        ta.value = uname;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); showOk(); } catch (err) {}
        document.body.removeChild(ta);
    }
}
window.copyCounterUsername = copyCounterUsername;

function confirmResetCounterPassword(id, username, region) {
    if (confirm(`Generate and reset a new password for ${region} counter (${username})?`)) {
        window.location.href = `admin.php?tab=counters&action=reset_counter_pwd&counter_id=${id}`;
    }
}
window.confirmResetCounterPassword = confirmResetCounterPassword;

async function copyCounterPwd() {
    const input = document.getElementById('copyPasswordInput');
    const btn = document.getElementById('copyPwdBtn');
    if (!input) return;
    try {
        await navigator.clipboard.writeText(input.value);
        if (btn) {
            btn.innerHTML = `<i class="bi bi-check2 text-success me-1"></i> Copied!`;
            setTimeout(() => {
                btn.innerHTML = `<i class="bi bi-clipboard me-1"></i> Copy`;
            }, 2000);
        }
    } catch (e) {
        input.select();
        document.execCommand('copy');
        if (btn) {
            btn.innerHTML = `<i class="bi bi-check2 text-success me-1"></i> Copied!`;
            setTimeout(() => {
                btn.innerHTML = `<i class="bi bi-clipboard me-1"></i> Copy`;
            }, 2000);
        }
    }
}
window.copyCounterPwd = copyCounterPwd;

function openReassignModal(id, name, currentCounterId) {
    const inputId = document.getElementById('reassignVisitorId');
    const nameEl = document.getElementById('reassignVisitorName');
    const select = document.getElementById('reassignTargetCounter');
    if (inputId) inputId.value = id;
    if (nameEl) nameEl.textContent = name;
    if (select && currentCounterId) {
        select.value = currentCounterId;
    }
    const modalEl = document.getElementById('reassignCounterModal');
    if (modalEl && window.bootstrap) {
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
    }
}
window.openReassignModal = openReassignModal;

// Live Polling & Action Handling
let isFetchingLive = false;

async function pollLiveUpdates(highlightId = null) {
    const currentTab = '<?= $tab ?>';
    if (currentTab === 'counters') return;
    if (isFetchingLive) return;
    isFetchingLive = true;
    try {
        const params = new URLSearchParams(window.location.search);
        params.delete('msg');
        params.delete('count');
        params.delete('skipped');
        params.delete('import_success');
        params.set('ajax_live', '1');
        const res = await fetch('admin.php?' + params.toString(), {
            headers: { 'Accept': 'application/json' }
        });
        if (!res.ok) return;
        const data = await res.json();
        if (!data || !data.success) return;

        const tableBody = document.getElementById(data.tab === 'gate' ? 'gateTableBody' : 'giftTableBody');
        const subtitle = document.getElementById(data.tab === 'gate' ? 'gateSubtitle' : 'giftSubtitle');

        if (subtitle) {
            const noun = (data.tab === 'gate' ? 'visitors' : 'attendees');
            subtitle.innerHTML = `${data.count} ${noun} &bull; Latest check-in first`;
        }

        if (tableBody) {
            if (data.startOffset !== undefined) {
                tableBody.dataset.startOffset = data.startOffset;
            }
            const prevFirstRow = tableBody.querySelector('tr[data-id]');
            const prevFirstId = prevFirstRow ? prevFirstRow.dataset.id : null;

            if (tableBody.innerHTML.trim() !== data.rowsHtml.trim()) {
                tableBody.innerHTML = data.rowsHtml;

                const newFirstRow = tableBody.querySelector('tr[data-id]');
                const newFirstId = newFirstRow ? newFirstRow.dataset.id : null;

                if (highlightId) {
                    const targetRow = tableBody.querySelector(`tr[data-id="${highlightId}"]`);
                    if (targetRow) {
                        targetRow.classList.add('row-highlight-new');
                        setTimeout(() => targetRow.classList.remove('row-highlight-new'), 3000);
                    }
                } else if (newFirstId && newFirstId !== prevFirstId) {
                    // Top visitor changed due to incoming check-in
                    newFirstRow.classList.add('row-highlight-new');
                    setTimeout(() => newFirstRow.classList.remove('row-highlight-new'), 3000);
                }
            }
        }

        // Live update filter badge counts if elements exist
        if (data.metrics) {
            const m = data.metrics;
            const bGateAll = document.getElementById('badgeGateAll');
            const bGateD1 = document.getElementById('badgeGateD1');
            const bGateD2 = document.getElementById('badgeGateD2');
            const bGatePend = document.getElementById('badgeGatePending');
            if (bGateAll) bGateAll.textContent = m.totalVisitors;
            if (bGateD1) bGateD1.textContent = m.d1Count;
            if (bGateD2) bGateD2.textContent = m.d2Count;
            if (bGatePend) bGatePend.textContent = m.pendingBothCount;

            const bGiftAll = document.getElementById('badgeGiftAll');
            const bGiftGiven = document.getElementById('badgeGiftGiven');
            const bGiftPend = document.getElementById('badgeGiftPending');
            if (bGiftAll) bGiftAll.textContent = m.totalGiftElig;
            if (bGiftGiven) bGiftGiven.textContent = m.giftsGiven;
            if (bGiftPend) bGiftPend.textContent = m.giftsPending;
        }
    } catch (e) {
        // Safe silent fail on temporary network glitch
    } finally {
        isFetchingLive = false;
    }
}

// Action Button Interceptor (Async check-in / reset with smooth top jump)
document.addEventListener('click', async (e) => {
    const btn = e.target.closest('.action-btn');
    if (!btn || !btn.href || btn.href.startsWith('#')) return;

    if (e.defaultPrevented) return;

    e.preventDefault();
    const originalHtml = btn.innerHTML;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" style="width:0.75rem;height:0.75rem;"></span>';
    btn.style.pointerEvents = 'none';

    try {
        const res = await fetch(btn.href, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        if (res.ok) {
            const resData = await res.json().catch(() => null);
            const actedId = resData && resData.id ? resData.id : null;
            await pollLiveUpdates(actedId);
        } else {
            window.location.href = btn.href;
        }
    } catch (err) {
        window.location.href = btn.href;
    } finally {
        btn.innerHTML = originalHtml;
        btn.style.pointerEvents = '';
    }
});

// Periodic live poll every 2.5 seconds
setInterval(() => {
    pollLiveUpdates();
}, 2500);
</script>
</body>
</html>
