<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== COLUMNS IN COUNTERS ===\n";
foreach ($pdo->query("DESCRIBE counters")->fetchAll(PDO::FETCH_ASSOC) as $col) {
    echo "{$col['Field']} ({$col['Type']})\n";
}

echo "\n=== COLUMNS IN ADMINS ===\n";
foreach ($pdo->query("DESCRIBE admins")->fetchAll(PDO::FETCH_ASSOC) as $col) {
    echo "{$col['Field']} ({$col['Type']})\n";
}
