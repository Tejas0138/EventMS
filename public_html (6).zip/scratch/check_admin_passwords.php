<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$admins = $pdo->query("SELECT id, username, role, region, status, last_login, counter_id, password FROM admins ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);

echo "Total admin accounts: " . count($admins) . "\n\n";

$defaultAdmin = password_verify('admin123', $admins[0]['password']);
echo "Account 'admin' password is 'admin123'? " . ($defaultAdmin ? "YES (DEFAULT!)" : "NO (CUSTOM)") . "\n";

foreach ($admins as $a) {
    $isDefaultGuard = ($a['username'] === 'guard1') ? password_verify('guard123', $a['password']) : false;
    $guardNote = ($a['username'] === 'guard1') ? ($isDefaultGuard ? " [Default password 'guard123']" : " [Custom password]") : "";
    $loginInfo = !empty($a['last_login']) ? $a['last_login'] : "Never logged in";
    echo "- Username: {$a['username']} | Role: {$a['role']} | Status: {$a['status']} | Last Login: {$loginInfo}{$guardNote}\n";
}
