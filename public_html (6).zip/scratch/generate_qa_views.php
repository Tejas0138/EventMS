<?php
declare(strict_types=1);

$dir = __DIR__ . '/qa_views';
if (!is_dir($dir)) {
    mkdir($dir, 0777, true);
}

$views = [
    // 1. Portal Login
    'login' => [
        'file' => 'login.php',
        'session' => [],
        'get' => []
    ],
    // 2. Self checkin (Open)
    'self_checkin_open' => [
        'file' => 'gate_checkin.php',
        'session' => [],
        'get' => []
    ],
    // 3. Self checkin (Already Checked In - visitor OS_60927)
    'self_checkin_already_checked_in' => [
        'file' => 'gate_checkin.php',
        'session' => [],
        'get' => ['id' => 'OS_60927']
    ],
    // 4. Admin Gate Entry
    'admin_gate' => [
        'file' => 'admin.php',
        'session' => [
            'admin_logged_in' => true,
            'admin_username'  => 'admin',
            'admin_id'        => 1,
            'user_role'       => 'super_admin',
            'login_time'      => time()
        ],
        'get' => ['tab' => 'gate']
    ],
    // 5. Admin COE Kit (Super Admin)
    'admin_gift_super' => [
        'file' => 'admin.php',
        'session' => [
            'admin_logged_in' => true,
            'admin_username'  => 'admin',
            'admin_id'        => 1,
            'user_role'       => 'super_admin',
            'login_time'      => time()
        ],
        'get' => ['tab' => 'gift']
    ],
    // 6. Admin COE Kit (Counter pune1)
    'admin_gift_pune1' => [
        'file' => 'admin.php',
        'session' => [
            'admin_logged_in' => true,
            'admin_username'  => 'pune1',
            'admin_id'        => 32,
            'user_role'       => 'counter',
            'counter_id'      => 6,
            'counter_region'  => 'Pune 1',
            'login_time'      => time()
        ],
        'get' => ['tab' => 'gift']
    ],
    // 7. Admin Regional Counters
    'admin_counters' => [
        'file' => 'admin.php',
        'session' => [
            'admin_logged_in' => true,
            'admin_username'  => 'admin',
            'admin_id'        => 1,
            'user_role'       => 'super_admin',
            'login_time'      => time()
        ],
        'get' => ['tab' => 'counters']
    ],
    // 8. Admin Gate QR & Event Settings
    'admin_gate_qr' => [
        'file' => 'admin.php',
        'session' => [
            'admin_logged_in' => true,
            'admin_username'  => 'admin',
            'admin_id'        => 1,
            'user_role'       => 'super_admin',
            'login_time'      => time()
        ],
        'get' => ['tab' => 'gate_qr']
    ],
    // 9. Gate QR Print Poster
    'gate_qr_poster' => [
        'file' => 'gate_qr_poster.php',
        'session' => [],
        'get' => []
    ],
];

foreach ($views as $name => $cfg) {
    $sessExport = var_export($cfg['session'], true);
    $getExport  = var_export($cfg['get'], true);
    $targetFile = $cfg['file'];
    $script = <<<PHP
<?php
session_start();
\$_SESSION = {$sessExport};
\$_GET = {$getExport};
\$_SERVER['REQUEST_METHOD'] = 'GET';
\$_SERVER['HTTP_HOST'] = 'localhost:8080';
\$_SERVER['REQUEST_URI'] = '/EventMS/{$targetFile}?' . http_build_query(\$_GET);
chdir(__DIR__ . '/..');
require __DIR__ . '/../{$targetFile}';
PHP;
    $tmpFile = __DIR__ . "/render_{$name}.php";
    file_put_contents($tmpFile, $script);
    $cmd = '"C:\xampp\php\php.exe" ' . escapeshellarg($tmpFile);
    $output = shell_exec($cmd);
    unlink($tmpFile);
    file_put_contents("{$dir}/{$name}.html", $output);
    echo "Generated {$name}.html (size: " . strlen($output ?? '') . " bytes)\n";
}
