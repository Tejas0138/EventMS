<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

function testLogin(string $username, string $password): array {
    $baseUrl = 'http://localhost:8080/EventMS';
    $cookieFile = __DIR__ . '/test_cookie_' . preg_replace('/[^a-zA-Z0-9]/', '_', $username) . '.txt';
    if (file_exists($cookieFile)) {
        unlink($cookieFile);
    }

    // 1. GET login page for CSRF token & cookie
    $ch = curl_init("$baseUrl/login.php");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEJAR      => $cookieFile,
        CURLOPT_COOKIEFILE     => $cookieFile,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_TIMEOUT        => 10
    ]);
    $getHtml = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', (string)$getHtml, $matches);
    $csrfToken = $matches[1] ?? '';

    if ($csrfToken === '') {
        return [
            'success' => false,
            'code' => $httpCode,
            'error' => 'Failed to retrieve CSRF token'
        ];
    }

    // 2. POST login credentials
    curl_setopt_array($ch, [
        CURLOPT_URL            => "$baseUrl/login.php",
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query([
            'csrf_token' => $csrfToken,
            'username'   => $username,
            'password'   => $password
        ]),
        CURLOPT_FOLLOWLOCATION => false
    ]);
    $postResponse = curl_exec($ch);
    $postCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $redirectUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);

    // If login failed, postCode is usually 200 with error message on page
    if ($postCode === 200) {
        preg_match('/<div class="alert[^"]*">\s*<i[^>]*><\/i>\s*(.*?)\s*<\/div>/si', (string)$postResponse, $errMatch);
        $errMsg = trim(strip_tags($errMatch[1] ?? 'Invalid credentials'));
        return [
            'success'     => false,
            'code'        => 200,
            'redirect'    => '',
            'error'       => $errMsg,
            'cookie_file' => $cookieFile
        ];
    }

    // Follow redirect
    curl_setopt_array($ch, [
        CURLOPT_URL            => $redirectUrl ?: "$baseUrl/admin.php?tab=gift",
        CURLOPT_POST           => false,
        CURLOPT_HTTPGET        => true,
        CURLOPT_FOLLOWLOCATION => true
    ]);
    $pageHtml = curl_exec($ch);
    $finalCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    return [
        'success'     => ($postCode === 302),
        'code'        => $postCode,
        'final_code'  => $finalCode,
        'redirect'    => $redirectUrl,
        'final_url'   => $finalUrl,
        'html'        => (string)$pageHtml,
        'cookie_file' => $cookieFile
    ];
}

echo "====================================================\n";
echo "CHECK 1: LOG IN WITH 4 SPECIFIC COUNTERS\n";
echo "====================================================\n";
$check1Accounts = [
    'raipur' => [
        'pass' => 'raipur@123',
        'counter_name' => 'Raipur / Chandigarh Counter',
        'expected_visitors' => 68
    ],
    'pune1' => [
        'pass' => 'pune1@123',
        'counter_name' => 'Pune Counter 1',
        'expected_visitors' => 73
    ],
    'noida' => [
        'pass' => 'noida@123',
        'counter_name' => 'Noida Counter',
        'expected_visitors' => 76
    ],
    'delhiwest' => [
        'pass' => 'delhiwest@123',
        'counter_name' => 'Delhi West Counter',
        'expected_visitors' => 51
    ],
];

foreach ($check1Accounts as $user => $info) {
    $res = testLogin($user, $info['pass']);
    if (!$res['success']) {
        echo "FAIL: Login failed for $user: {$res['error']}\n";
        continue;
    }

    // Verify page is COE Kit page
    $isKitPage = (strpos($res['final_url'], 'tab=gift') !== false || strpos($res['html'], 'COE Kit Distribution') !== false);
    
    // Verify counter name appears
    $hasCounterName = (strpos($res['html'], $info['counter_name']) !== false);

    // Count visitors shown
    // In admin.php, badgeGiftAll shows total eligible visitors
    preg_match('/id="badgeGiftAll"[^>]*>(\d+)<\/span>/', $res['html'], $badgeMatch);
    $shownVisitors = isset($badgeMatch[1]) ? (int)$badgeMatch[1] : -1;

    $pass = ($isKitPage && $hasCounterName && $shownVisitors === $info['expected_visitors']);
    echo "[$user / {$info['pass']}]\n";
    echo "  Status: " . ($pass ? "PASS" : "FAIL") . "\n";
    echo "  Destination: {$res['final_url']}\n";
    echo "  Counter Name displayed: " . ($hasCounterName ? "'{$info['counter_name']}'" : "NOT FOUND") . "\n";
    echo "  Visitors shown: $shownVisitors (Expected: {$info['expected_visitors']})\n\n";

    if (file_exists($res['cookie_file'])) unlink($res['cookie_file']);
}

echo "====================================================\n";
echo "CHECK 2: OLD USERNAMES & WRONG PASSWORDS ARE REFUSED\n";
echo "====================================================\n";
$check2Tests = [
    ['user' => 'counter_noida', 'pass' => 'noida@123', 'desc' => 'Old username (counter_noida) with correct new pass'],
    ['user' => 'counter_noida', 'pass' => 'Noida@2026', 'desc' => 'Old username (counter_noida) with old pass'],
    ['user' => 'counter_raipur_chandigarh', 'pass' => 'raipur@123', 'desc' => 'Old username (counter_raipur_chandigarh) with new pass'],
    ['user' => 'noida', 'pass' => 'wrongpassword123', 'desc' => 'New username (noida) with WRONG password'],
    ['user' => 'raipur', 'pass' => 'raipur@wrong', 'desc' => 'New username (raipur) with WRONG password'],
    ['user' => 'counter_helpdesk', 'pass' => 'Helpdesk@2026', 'desc' => 'Disabled Helpdesk account'],
];

foreach ($check2Tests as $t) {
    $res = testLogin($t['user'], $t['pass']);
    $refused = (!$res['success']);
    echo "[{$t['desc']}]\n";
    echo "  Input: {$t['user']} / {$t['pass']}\n";
    echo "  Result: " . ($refused ? "PASS (Refused: '{$res['error']}')" : "FAIL (Incorrectly logged in)") . "\n\n";
    if (file_exists($res['cookie_file'])) unlink($res['cookie_file']);
}

echo "====================================================\n";
echo "CHECK 3: CASE-INSENSITIVE USERNAME (CAPITAL LETTERS)\n";
echo "====================================================\n";
$check3Tests = [
    ['user' => 'NOIDA', 'pass' => 'noida@123', 'counter_name' => 'Noida Counter'],
    ['user' => 'RAIPUR', 'pass' => 'raipur@123', 'counter_name' => 'Raipur / Chandigarh Counter'],
    ['user' => 'Pune1', 'pass' => 'pune1@123', 'counter_name' => 'Pune Counter 1'],
    ['user' => 'DELHIWEST', 'pass' => 'delhiwest@123', 'counter_name' => 'Delhi West Counter'],
];

foreach ($check3Tests as $t) {
    $res = testLogin($t['user'], $t['pass']);
    $hasName = (strpos($res['html'] ?? '', $t['counter_name']) !== false);
    $pass = ($res['success'] && $hasName);
    echo "[{$t['user']} / {$t['pass']}]\n";
    echo "  Result: " . ($pass ? "PASS (Successfully logged in as {$t['counter_name']})" : "FAIL") . "\n";
    echo "  Destination: {$res['final_url']}\n\n";
    if (file_exists($res['cookie_file'])) unlink($res['cookie_file']);
}

echo "====================================================\n";
echo "CHECK 4: COUNTERS PAGE (SUPER ADMIN VIEW)\n";
echo "====================================================\n";
// Load admin session and inspect Counters page HTML
$adminCookieFile = __DIR__ . '/test_admin_cookie.txt';
if (file_exists($adminCookieFile)) unlink($adminCookieFile);

// Login as super admin: let's verify admin credentials from DB or log in directly via session
$adminRow = $pdo->query("SELECT username, password FROM admins WHERE id = 1")->fetch(PDO::FETCH_ASSOC);

// Let's test login via login.php with admin
// We can use a test script with session or check password_verify
$isDefaultAdminPass = password_verify('admin123', $adminRow['password']) || password_verify('admin', $adminRow['password']) || password_verify('Admin@2026', $adminRow['password']);

// Or let's inspect the page content rendered for tab=counters
$_SESSION['admin_logged_in'] = true;
$_SESSION['admin_username'] = 'admin';
$_SESSION['admin_id'] = 1;
$_SESSION['user_role'] = 'super_admin';

// Execute admin.php?tab=counters query
$countersStmt = $pdo->query("
    SELECT c.id, c.name, c.code, c.username, c.name_range, c.is_active, c.last_login,
           a.id AS admin_id, a.status AS admin_status,
           COALESCE(g_agg.total_visitors, 0) AS total_visitors,
           COALESCE(g_agg.kits_distributed, 0) AS kits_distributed,
           COALESCE(g_agg.kits_pending, 0) AS kits_pending,
           (
               SELECT GROUP_CONCAT(NULLIF(TRIM(cr.region), '') ORDER BY cr.region SEPARATOR ', ')
               FROM `counter_regions` cr
               WHERE cr.counter_id = c.id AND TRIM(cr.region) != ''
           ) AS regions_covered
    FROM `counters` c
    LEFT JOIN `admins` a ON (a.username = c.username)
    LEFT JOIN (
        SELECT counter_id,
               COUNT(*) AS total_visitors,
               SUM(CASE WHEN is_gift_collected = 1 THEN 1 ELSE 0 END) AS kits_distributed,
               SUM(CASE WHEN is_gift_collected = 0 THEN 1 ELSE 0 END) AS kits_pending
        FROM `gift_distribution`
        WHERE counter_id IS NOT NULL AND counter_id > 0
        GROUP BY counter_id
    ) g_agg ON (g_agg.counter_id = c.id)
    WHERE c.is_active = 1 AND c.code != 'helpdesk'
    ORDER BY c.id ASC
");
$countersList = $countersStmt->fetchAll(PDO::FETCH_ASSOC);

$countActive = count($countersList);
$sumVisitors = array_sum(array_column($countersList, 'total_visitors'));
$totalDbVisitors = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
$hasHelpDesk = false;
foreach ($countersList as $c) {
    if (stripos($c['name'], 'help desk') !== false || $c['code'] === 'helpdesk') {
        $hasHelpDesk = true;
    }
}

echo "Total Active Counters Listed: $countActive (Expected: 20)\n";
echo "Help Desk Excluded: " . (!$hasHelpDesk ? "YES (PASS)" : "NO (FAIL)") . "\n";
echo "Sum of Visitors across Counters: $sumVisitors (DB Total: $totalDbVisitors)\n";
echo "Sum matches DB Total: " . ($sumVisitors === $totalDbVisitors ? "YES (PASS)" : "NO (FAIL)") . "\n\n";

echo "Counters and New Usernames:\n";
foreach ($countersList as $idx => $c) {
    echo "  " . ($idx + 1) . ". {$c['name']}: username='{$c['username']}', visitors={$c['total_visitors']}\n";
}
