<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

function readXlsxSheetRows(string $xlsxPath, string $sheetNameOrId = 'sheet1'): array {
    $zip = new ZipArchive();
    if ($zip->open($xlsxPath) !== true) {
        throw new RuntimeException("Cannot open $xlsxPath");
    }

    // Shared strings
    $sharedStrings = [];
    $ssXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssXml !== false) {
        $xml = simplexml_load_string($ssXml);
        foreach ($xml->si as $si) {
            $t = '';
            if (isset($si->t)) {
                $t = (string)$si->t;
            } elseif (isset($si->r)) {
                foreach ($si->r as $r) {
                    $t .= (string)$r->t;
                }
            }
            $sharedStrings[] = $t;
        }
    }

    // Find sheet target
    $wbXml = simplexml_load_string($zip->getFromName('xl/workbook.xml'));
    $targetSheetFile = 'xl/worksheets/sheet1.xml';
    $wbRels = simplexml_load_string($zip->getFromName('xl/_rels/workbook.xml.rels'));
    $relMap = [];
    foreach ($wbRels->Relationship as $rel) {
        $relMap[(string)$rel['Id']] = (string)$rel['Target'];
    }

    foreach ($wbXml->sheets->sheet as $s) {
        $sName = (string)$s['name'];
        $rId = (string)$s->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
        if (strcasecmp($sName, $sheetNameOrId) === 0 || $sheetNameOrId === 'sheet1') {
            $target = $relMap[$rId] ?? 'worksheets/sheet1.xml';
            $targetSheetFile = str_starts_with($target, 'xl/') ? $target : 'xl/' . ltrim($target, '/');
            break;
        }
    }

    $sheetXmlContent = $zip->getFromName($targetSheetFile);
    if ($sheetXmlContent === false) {
        throw new RuntimeException("Sheet $targetSheetFile not found in $xlsxPath");
    }

    $sXml = simplexml_load_string($sheetXmlContent);
    $rows = [];
    foreach ($sXml->sheetData->row as $r) {
        $rowNum = (int)$r['r'];
        $rowCells = [];
        foreach ($r->c as $c) {
            $colRef = preg_replace('/\d/', '', (string)$c['r']);
            $val = '';
            $type = (string)$c['t'];
            if ($type === 's') {
                $idx = (int)$c->v;
                $val = $sharedStrings[$idx] ?? '';
            } else {
                $val = (string)($c->v ?? '');
            }
            $rowCells[$colRef] = $val;
        }
        $rows[$rowNum] = $rowCells;
    }
    $zip->close();
    return $rows;
}

echo "=== INSPECTING RAW_DATA_AG.XLSX ===\n";
$agRows = readXlsxSheetRows(__DIR__ . '/../raw_data_AG.xlsx', 'sheet1');
echo "raw_data_AG total rows: " . count($agRows) . "\n";
echo "Row 1 (header): " . json_encode($agRows[1] ?? []) . "\n";
echo "Row 2: " . json_encode($agRows[2] ?? []) . "\n";

echo "\n=== INSPECTING AG_MISSING_DETAILS_S.XLSX ===\n";
$missingRows = readXlsxSheetRows(__DIR__ . '/../AG_Missing_Details_S.xlsx', 'Missing Details');
echo "AG_Missing_Details_S 'Missing Details' total rows: " . count($missingRows) . "\n";
for ($i = 1; $i <= 8; $i++) {
    if (isset($missingRows[$i])) {
        echo "Row $i: " . json_encode($missingRows[$i]) . "\n";
    }
}
