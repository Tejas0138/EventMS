<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== BASELINE DATABASE METRICS ===\n";
$totalAllowed = $pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
$totalGift = $pdo->query("SELECT COUNT(*) FROM gift_distribution")->fetchColumn();
echo "allowed_visitors total: $totalAllowed\n";
echo "gift_distribution total: $totalGift\n";

$d1 = $pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day1_checked_in = 1")->fetchColumn();
$d2 = $pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day2_checked_in = 1")->fetchColumn();
$kit = $pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE is_gift_collected = 1")->fetchColumn();
echo "Day 1 checked in: $d1\n";
echo "Day 2 checked in: $d2\n";
echo "Kits distributed: $kit\n";

// Empty region check
$emptyRegionAllowed = $pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE region IS NULL OR TRIM(region) = ''")->fetchColumn();
$emptyRegionGift = $pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE region IS NULL OR TRIM(region) = ''")->fetchColumn();
echo "Empty region in allowed_visitors: $emptyRegionAllowed\n";
echo "Empty region in gift_distribution: $emptyRegionGift\n";

// Empty mobile check
$emptyMobileAllowed = $pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE mobile IS NULL OR TRIM(mobile) = ''")->fetchColumn();
$emptyMobileGift = $pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE mobile IS NULL OR TRIM(mobile) = ''")->fetchColumn();
echo "Empty mobile in allowed_visitors: $emptyMobileAllowed\n";
echo "Empty mobile in gift_distribution: $emptyMobileGift\n";

// Let's list the empty region records
$emptyRegionRows = $pdo->query("SELECT id, user_id, name, region, mobile, counter_id FROM allowed_visitors WHERE region IS NULL OR TRIM(region) = '' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
echo "\n--- Empty Region Visitors (" . count($emptyRegionRows) . ") ---\n";
foreach ($emptyRegionRows as $r) {
    echo "ID: {$r['id']} | UserID: {$r['user_id']} | Name: {$r['name']} | Mobile: {$r['mobile']} | CounterID: {$r['counter_id']}\n";
}

// Let's list the empty mobile records
$emptyMobileRows = $pdo->query("SELECT id, user_id, name, region, mobile, counter_id FROM allowed_visitors WHERE mobile IS NULL OR TRIM(mobile) = '' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
echo "\n--- Empty Mobile Visitors (" . count($emptyMobileRows) . ") ---\n";
foreach ($emptyMobileRows as $r) {
    echo "ID: {$r['id']} | UserID: {$r['user_id']} | Name: {$r['name']} | Region: {$r['region']} | CounterID: {$r['counter_id']}\n";
}

// Check counter assignments
$counterCounts = $pdo->query("
    SELECT c.id, c.code, c.name, c.is_active, COUNT(v.id) as visitor_count
    FROM counters c
    LEFT JOIN allowed_visitors v ON v.counter_id = c.id
    GROUP BY c.id
    ORDER BY c.id
")->fetchAll(PDO::FETCH_ASSOC);
echo "\n--- Counter Visitor Counts (" . count($counterCounts) . " counters) ---\n";
$sumVisitors = 0;
foreach ($counterCounts as $c) {
    echo "ID: {$c['id']} | Code: {$c['code']} | Active: {$c['is_active']} | Count: {$c['visitor_count']} | Name: {$c['name']}\n";
    $sumVisitors += $c['visitor_count'];
}
echo "Sum of counter visitor counts: $sumVisitors\n";
