<?php
/**
 * Test Super Admin view of admin.php tabs
 */
$cookieFile = __DIR__ . '/admin_cookie.txt';
if (file_exists($cookieFile)) unlink($cookieFile);

// 1. Login as admin
$ch = curl_init('http://localhost:8080/EventMS/login.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
$html = curl_exec($ch);
curl_close($ch);

preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', $html, $matches);
$csrf = $matches[1] ?? '';

$ch = curl_init('http://localhost:8080/EventMS/login.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'csrf_token' => $csrf,
    'username' => 'admin',
    'password' => 'admin123'
]));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$res = curl_exec($ch);
curl_close($ch);

echo "Admin login successful.\n";

// 2. Fetch admin.php?tab=counters
$ch = curl_init('http://localhost:8080/EventMS/admin.php?tab=counters');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
$countersHtml = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "tab=counters HTTP code: $code\n";
echo "Contains '20 Regional Counters': " . (stripos($countersHtml, '20 Regional Counters') !== false ? 'YES' : 'NO') . "\n";
echo "Contains 'Total 1,270': " . (stripos($countersHtml, 'Total 1,270') !== false ? 'YES' : 'NO') . "\n";
echo "Contains 'Total 1270': " . (stripos($countersHtml, 'Total 1270') !== false ? 'YES' : 'NO') . "\n";
echo "Contains 'Help Desk' in table: " . (stripos($countersHtml, 'Help Desk Counter') !== false || stripos($countersHtml, 'counter_helpdesk') !== false ? 'YES' : 'NO') . "\n";

// 3. Fetch admin.php?tab=gate
$ch = curl_init('http://localhost:8080/EventMS/admin.php?tab=gate');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
$gateHtml = curl_exec($ch);
$codeGate = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "tab=gate HTTP code: $codeGate\n";

// 4. Fetch admin.php?tab=gift
$ch = curl_init('http://localhost:8080/EventMS/admin.php?tab=gift');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
$giftHtml = curl_exec($ch);
$codeGift = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "tab=gift HTTP code: $codeGift\n";
echo "Gift Counter select contains 'All Counters (20)': " . (stripos($giftHtml, 'All Counters (20)') !== false ? 'YES' : 'NO') . "\n";
echo "Gift Counter select contains Help Desk: " . (stripos($giftHtml, 'Help Desk') !== false ? 'YES' : 'NO') . "\n";

if (file_exists($cookieFile)) unlink($cookieFile);
