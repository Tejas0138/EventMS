<?php
declare(strict_types=1);

$file = 'C:/Users/kondh/Downloads/AG_Missing_Details_Sorted.xlsx';
if (!file_exists($file)) {
    echo "File not found in downloads.\n";
    exit;
}

$zip = new ZipArchive();
if ($zip->open($file) === true) {
    echo "Zip opened successfully. Entries:\n";
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if (str_contains($name, 'sheet') || str_contains($name, 'workbook')) {
            echo " - $name\n";
        }
    }
    // Read workbook.xml to see sheet names
    $wbXml = $zip->getFromName('xl/workbook.xml');
    echo "\nWorkbook XML:\n" . substr($wbXml, 0, 500) . "\n";
    $zip->close();
}
