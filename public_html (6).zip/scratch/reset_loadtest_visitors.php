<?php
require_once 'c:/xampp/htdocs/EventMS_loadtest/config/db.php';
$pdo = Database::getConnection();

// Double check database
if ($pdo->query("SELECT DATABASE()")->fetchColumn() !== 'eventms_loadtest') {
    die("FATAL: Not connected to eventms_loadtest\n");
}

$pdo->exec("UPDATE allowed_visitors SET is_checked_in = 0, checked_in_at = NULL, is_day1_checked_in = 0, day1_checked_in_at = NULL, is_day2_checked_in = 0, day2_checked_in_at = NULL WHERE added_by = 'loadtest'");
$pdo->exec("UPDATE gift_distribution SET is_gift_collected = 0, gift_collected_at = NULL, handed_over_by = NULL, counter_region = NULL WHERE added_by = 'loadtest'");
$pdo->exec("DELETE FROM rate_limits WHERE action = 'gate_self_checkin'");

echo "Loadtest visitors and rate_limits reset successfully in eventms_loadtest.\n";
