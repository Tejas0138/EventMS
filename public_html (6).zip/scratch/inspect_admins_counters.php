<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== ALL ADMINS ===\n";
$admins = $pdo->query("SELECT id, username, role, region, status, counter_id FROM admins ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
foreach ($admins as $a) {
    echo "ID: {$a['id']} | User: '{$a['username']}' | Role: '{$a['role']}' | Status: '{$a['status']}' | CounterID: '{$a['counter_id']}'\n";
}

echo "\n=== ALL COUNTERS ===\n";
$counters = $pdo->query("SELECT id, name, code, username, is_active FROM counters ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
foreach ($counters as $c) {
    echo "ID: {$c['id']} | Name: '{$c['name']}' | Code: '{$c['code']}' | User: '{$c['username']}' | Active: '{$c['is_active']}'\n";
}
