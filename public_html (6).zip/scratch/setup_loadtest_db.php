<?php
require_once 'c:/xampp\htdocs\EventMS_loadtest\config\db.php';
$pdo = Database::getConnection();

// Verify we are strictly in eventms_loadtest
$currentDb = $pdo->query("SELECT DATABASE()")->fetchColumn();
if ($currentDb !== 'eventms_loadtest') {
    die("FATAL ERROR: Not connected to eventms_loadtest! Connected to: " . $currentDb);
}

// 1. Update event_settings: today (2026-11-19) is Day 1, and Open
$today = date('Y-m-d');
$pdo->prepare("REPLACE INTO event_settings (setting_key, setting_value, updated_at, updated_by) VALUES ('day1_date', ?, NOW(), 'loadtest_setup')")->execute([$today]);
$pdo->prepare("REPLACE INTO event_settings (setting_key, setting_value, updated_at, updated_by) VALUES ('day2_date', '2026-11-20', NOW(), 'loadtest_setup')")->execute();
$pdo->prepare("REPLACE INTO event_settings (setting_key, setting_value, updated_at, updated_by) VALUES ('self_checkin_open', '1', NOW(), 'loadtest_setup')")->execute();

// 2. Create test admin in admins table
$adminPassHash = password_hash('testadmin@123', PASSWORD_BCRYPT);
$pdo->prepare("REPLACE INTO admins (username, password, role, status) VALUES ('testadmin', ?, 'super_admin', 'active')")->execute([$adminPassHash]);

// 3. Create 300 test visitors spread across all 20 counters (15 per counter)
$counterMap = [
    1 => 'Raipur',
    2 => 'Dehradun',
    3 => 'Gurugram',
    4 => 'Chennai',
    5 => 'Panchkula',
    6 => 'Pune',
    7 => 'Pune',
    8 => 'Pune',
    9 => 'Pune',
    10 => 'Noida',
    11 => 'Bengaluru',
    12 => 'Bhopal',
    13 => 'Bhubaneswar',
    14 => 'Ajmer',
    15 => 'Ahmedabad',
    16 => 'Patna',
    17 => 'Trivandrum',
    18 => 'Delhi West',
    19 => 'Delhi East',
    20 => 'Ranchi'
];

// Clean existing loadtest visitors if any
$pdo->exec("DELETE FROM allowed_visitors WHERE added_by = 'loadtest'");
$pdo->exec("DELETE FROM gift_distribution WHERE added_by = 'loadtest'");

$stmtV = $pdo->prepare("INSERT INTO allowed_visitors (name, mobile, is_checked_in, is_day1_checked_in, is_day2_checked_in, user_id, region, fincert, counter_id, added_by) VALUES (?, ?, 0, 0, 0, ?, ?, ?, ?, 'loadtest')");
$stmtG = $pdo->prepare("INSERT INTO gift_distribution (name, mobile, is_gift_collected, user_id, region, fincert, counter_id, added_by) VALUES (?, ?, 0, ?, ?, ?, ?, 'loadtest')");

$pdo->beginTransaction();
for ($i = 1; $i <= 300; $i++) {
    $regId = sprintf("LOADTEST_%03d", $i);
    $mobile = sprintf("900000%04d", $i);
    $name = sprintf("Load Test %03d", $i);
    $fincert = sprintf("LOADTEST/%04d", $i);
    
    // Spread evenly across 20 counters (15 each)
    $counterId = (($i - 1) % 20) + 1;
    $region = $counterMap[$counterId];
    
    $stmtV->execute([$name, $mobile, $regId, $region, $fincert, $counterId]);
    $stmtG->execute([$name, $mobile, $regId, $region, $fincert, $counterId]);
}
$pdo->commit();

// Verify counts
$vCount = $pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE added_by = 'loadtest'")->fetchColumn();
$gCount = $pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE added_by = 'loadtest'")->fetchColumn();
$totalV = $pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
$totalG = $pdo->query("SELECT COUNT(*) FROM gift_distribution")->fetchColumn();

echo json_encode([
    'status' => 'success',
    'database' => $currentDb,
    'loadtest_visitors_inserted' => (int)$vCount,
    'loadtest_gift_records_inserted' => (int)$gCount,
    'total_visitors_in_loadtest_db' => (int)$totalV,
    'total_gift_records_in_loadtest_db' => (int)$totalG
], JSON_PRETTY_PRINT);
