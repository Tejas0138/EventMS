<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$sql = "
    SELECT c.id, c.name, c.code, c.username, c.name_range, c.is_active, c.last_login,
           a.id AS admin_id, a.status AS admin_status,
           COALESCE(g_agg.total_visitors, 0) AS total_visitors,
           COALESCE(g_agg.kits_distributed, 0) AS kits_distributed,
           COALESCE(g_agg.kits_pending, 0) AS kits_pending,
           (
               SELECT GROUP_CONCAT(cr.region ORDER BY cr.region SEPARATOR ', ')
               FROM `counter_regions` cr
               WHERE cr.counter_id = c.id
           ) AS regions_covered
    FROM `counters` c
    LEFT JOIN `admins` a ON (a.username = c.username)
    LEFT JOIN (
        SELECT counter_id,
               COUNT(*) AS total_visitors,
               SUM(CASE WHEN is_gift_collected = 1 THEN 1 ELSE 0 END) AS kits_distributed,
               SUM(CASE WHEN is_gift_collected = 0 THEN 1 ELSE 0 END) AS kits_pending
        FROM `gift_distribution`
        WHERE counter_id IS NOT NULL AND counter_id > 0
        GROUP BY counter_id
    ) g_agg ON (g_agg.counter_id = c.id)
    ORDER BY c.id ASC
";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
$sumVisitors = 0;
$sumDistributed = 0;
$sumPending = 0;

echo sprintf("%-42s | %-10s | %-12s | %-10s | %s\n", "Counter Name", "Visitors", "Distributed", "Pending", "Regions/Range");
echo str_repeat("-", 100) . "\n";
foreach ($rows as $r) {
    $sumVisitors += (int)$r['total_visitors'];
    $sumDistributed += (int)$r['kits_distributed'];
    $sumPending += (int)$r['kits_pending'];
    $cov = !empty($r['name_range']) ? $r['name_range'] : $r['regions_covered'];
    echo sprintf("%-42s | %10d | %12d | %10d | %s\n", $r['name'], $r['total_visitors'], $r['kits_distributed'], $r['kits_pending'], $cov);
}
echo str_repeat("=", 100) . "\n";
echo sprintf("%-42s | %10d | %12d | %10d\n", "TOTAL", $sumVisitors, $sumDistributed, $sumPending);
