<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== SHOW CREATE TABLE allowed_visitors ===\n";
echo $pdo->query("SHOW CREATE TABLE allowed_visitors")->fetch(PDO::FETCH_ASSOC)['Create Table'] . "\n\n";

echo "=== SHOW CREATE TABLE gift_distribution ===\n";
echo $pdo->query("SHOW CREATE TABLE gift_distribution")->fetch(PDO::FETCH_ASSOC)['Create Table'] . "\n\n";

echo "=== SHOW CREATE TABLE audit_log ===\n";
echo $pdo->query("SHOW CREATE TABLE audit_log")->fetch(PDO::FETCH_ASSOC)['Create Table'] . "\n\n";

echo "=== SHOW TRIGGERS ===\n";
$triggers = $pdo->query("SHOW TRIGGERS")->fetchAll(PDO::FETCH_ASSOC);
print_r($triggers);
