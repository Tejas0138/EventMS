<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$pdo->beginTransaction();

try {
    // 1. Verify "Test"
    $stmtTest = $pdo->prepare("SELECT id, name, user_id, fincert, region, counter_id FROM allowed_visitors WHERE LOWER(TRIM(user_id)) = '1234' AND LOWER(TRIM(name)) = 'test'");
    $stmtTest->execute();
    $rowsTest = $stmtTest->fetchAll(PDO::FETCH_ASSOC);
    if (count($rowsTest) !== 1) {
        throw new RuntimeException("Expected exactly 1 match for Test in allowed_visitors, found " . count($rowsTest));
    }
    $testVisitor = $rowsTest[0];

    // 2. Verify "Test2"
    $stmtTest2 = $pdo->prepare("SELECT id, name, user_id, fincert, region, counter_id FROM allowed_visitors WHERE LOWER(TRIM(user_id)) = '23568' AND LOWER(TRIM(name)) = 'test2'");
    $stmtTest2->execute();
    $rowsTest2 = $stmtTest2->fetchAll(PDO::FETCH_ASSOC);
    if (count($rowsTest2) !== 1) {
        throw new RuntimeException("Expected exactly 1 match for Test2 in allowed_visitors, found " . count($rowsTest2));
    }
    $test2Visitor = $rowsTest2[0];

    // Verify in gift_distribution
    $stmtGiftTest = $pdo->prepare("SELECT id, name, user_id, fincert, region, counter_id FROM gift_distribution WHERE LOWER(TRIM(user_id)) = '1234' AND LOWER(TRIM(name)) = 'test'");
    $stmtGiftTest->execute();
    $rowsGiftTest = $stmtGiftTest->fetchAll(PDO::FETCH_ASSOC);
    if (count($rowsGiftTest) !== 1) {
        throw new RuntimeException("Expected exactly 1 match for Test in gift_distribution, found " . count($rowsGiftTest));
    }

    $stmtGiftTest2 = $pdo->prepare("SELECT id, name, user_id, fincert, region, counter_id FROM gift_distribution WHERE LOWER(TRIM(user_id)) = '23568' AND LOWER(TRIM(name)) = 'test2'");
    $stmtGiftTest2->execute();
    $rowsGiftTest2 = $stmtGiftTest2->fetchAll(PDO::FETCH_ASSOC);
    if (count($rowsGiftTest2) !== 1) {
        throw new RuntimeException("Expected exactly 1 match for Test2 in gift_distribution, found " . count($rowsGiftTest2));
    }

    echo "Found matching visitors:\n";
    echo " - Test: ID {$testVisitor['id']} (Gift ID {$rowsGiftTest[0]['id']}), Counter ID: {$testVisitor['counter_id']}\n";
    echo " - Test2: ID {$test2Visitor['id']} (Gift ID {$rowsGiftTest2[0]['id']}), Counter ID: {$test2Visitor['counter_id']}\n";

    // 3. Delete from allowed_visitors
    $delVis = $pdo->prepare("DELETE FROM allowed_visitors WHERE id IN (:id1, :id2)");
    $delVis->execute([':id1' => $testVisitor['id'], ':id2' => $test2Visitor['id']]);
    $affectedVis = $delVis->rowCount();
    if ($affectedVis !== 2) {
        throw new RuntimeException("Expected 2 deleted rows from allowed_visitors, got {$affectedVis}");
    }

    // 4. Delete from gift_distribution
    $delGift = $pdo->prepare("DELETE FROM gift_distribution WHERE id IN (:id1, :id2)");
    $delGift->execute([':id1' => $rowsGiftTest[0]['id'], ':id2' => $rowsGiftTest2[0]['id']]);
    $affectedGift = $delGift->rowCount();
    if ($affectedGift !== 2) {
        throw new RuntimeException("Expected 2 deleted rows from gift_distribution, got {$affectedGift}");
    }

    // 5. Delete audit_log entries belonging only to these two visitors
    $delAudit = $pdo->prepare("DELETE FROM audit_log WHERE LOWER(TRIM(target_id)) IN ('1234', '23568') AND LOWER(TRIM(target_name)) IN ('test', 'test2')");
    $delAudit->execute();
    $affectedAudit = $delAudit->rowCount();
    echo "Deleted {$affectedAudit} audit_log row(s)\n";

    // 6. Delete counter_reassignment_log entries if any
    $delReassign = $pdo->prepare("DELETE FROM counter_reassignment_log WHERE visitor_id IN (:id1, :id2) OR LOWER(TRIM(user_id)) IN ('1234', '23568')");
    $delReassign->execute([':id1' => $testVisitor['id'], ':id2' => $test2Visitor['id']]);

    // 7. Verification checks
    $totalAllowed = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
    $totalGift = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution")->fetchColumn();
    if ($totalAllowed !== 1270 || $totalGift !== 1270) {
        throw new RuntimeException("Validation failed: allowed_visitors has {$totalAllowed}, gift_distribution has {$totalGift}, expected 1270");
    }

    $pdo->commit();
    echo "Transaction COMMITTED successfully! Total visitors is now 1270 in both tables.\n";
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}
