<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$passwords = [
    // 5 Combined counters
    'counter_raipur_chandigarh'             => 'RaipurChandigarh@2026',
    'counter_dehradun_lucknow'               => 'DehradunLucknow@2026',
    'counter_gurugram_guwahati'              => 'GurugramGuwahati@2026',
    'counter_chennai_vijayawada'             => 'ChennaiVijayawada@2026',
    'counter_panchkula_prayagraj_hyderabad' => 'PanchkulaPrayagrajHyderabad@2026',

    // 4 Pune counters
    'counter_pune_1'                         => 'Pune@2026',
    'counter_pune_2'                         => 'Pune@2026',
    'counter_pune_3'                         => 'Pune@2026',
    'counter_pune_4'                         => 'Pune@2026',

    // 11 Single-region counters
    'counter_noida'                          => 'Noida@2026',
    'counter_bengaluru'                      => 'Bengaluru@2026',
    'counter_bhopal'                         => 'Bhopal@2026',
    'counter_bhubaneswar'                    => 'Bhubaneswar@2026',
    'counter_ajmer'                          => 'Ajmer@2026',
    'counter_ahmedabad'                      => 'Ahmedabad@2026',
    'counter_patna'                          => 'Patna@2026',
    'counter_trivandrum'                     => 'Trivandrum@2026',
    'counter_delhi_west'                     => 'DelhiWest@2026',
    'counter_delhi_east'                     => 'DelhiEast@2026',
    'counter_ranchi'                         => 'Ranchi@2026',

    // Help Desk (inactive)
    'counter_helpdesk'                       => 'HelpDesk@2026',
];

$legacyAdmins = [
    'counter_chandigarh' => 'Chandigarh@2026',
    'counter_chennai'    => 'Chennai@2026',
    'counter_dehradun'   => 'Dehradun@2026',
    'counter_gurugram'   => 'Gurugram@2026',
    'counter_guwahati'   => 'Guwahati@2026',
    'counter_hyderabad'  => 'Hyderabad@2026',
    'counter_lucknow'    => 'Lucknow@2026',
    'counter_panchkula'  => 'Panchkula@2026',
    'counter_prayagraj'  => 'Prayagraj@2026',
    'counter_pune'       => 'Pune@2026',
    'counter_raipur'     => 'Raipur@2026',
    'counter_vijayawada' => 'Vijayawada@2026',
];

$allAccounts = array_merge($passwords, $legacyAdmins);

$pdo->beginTransaction();

try {
    echo "=== UPDATING PASSWORDS IN DATABASE ===\n";

    $updCounter = $pdo->prepare("UPDATE counters SET password_hash = :hash WHERE username = :u");
    $updAdmin = $pdo->prepare("UPDATE admins SET password = :hash, failed_attempts = 0, locked_until = NULL WHERE username = :u");

    foreach ($passwords as $username => $plainPassword) {
        $hash = password_hash($plainPassword, PASSWORD_DEFAULT);
        $updCounter->execute([':hash' => $hash, ':u' => $username]);
        $updAdmin->execute([':hash' => $hash, ':u' => $username]);
        echo "Updated $username -> hash stored (plain: $plainPassword)\n";
    }

    foreach ($legacyAdmins as $username => $plainPassword) {
        $hash = password_hash($plainPassword, PASSWORD_DEFAULT);
        $updAdmin->execute([':hash' => $hash, ':u' => $username]);
        echo "Updated legacy $username -> hash stored (plain: $plainPassword)\n";
    }

    $pdo->commit();
    echo "\n=== ALL DATABASE PASSWORDS UPDATED SUCCESSFULLY ===\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    die("ERROR: " . $e->getMessage() . "\n");
}

// Generate updated counter_credentials.csv
$stmt = $pdo->query("
    SELECT c.id, c.name, c.code, c.username, c.name_range, c.password_hash,
           (SELECT GROUP_CONCAT(cr.region SEPARATOR ', ') FROM counter_regions cr WHERE cr.counter_id = c.id AND TRIM(cr.region) != '') AS regions_covered,
           (SELECT COUNT(*) FROM allowed_visitors v WHERE v.counter_id = c.id) AS visitor_count
    FROM counters c
    WHERE c.is_active = 1 AND c.code != 'helpdesk'
    ORDER BY c.id ASC
");
$counters = $stmt->fetchAll(PDO::FETCH_ASSOC);

$csvPath = __DIR__ . '/../counter_credentials.csv';
$fp = fopen($csvPath, 'w');
fputcsv($fp, ['counter_name', 'username', 'password', 'login_url', 'regions_covered', 'name_range', 'number_of_visitors']);

$totalVisitors = 0;
echo "\n=== GENERATING CSV ===\n";
foreach ($counters as $c) {
    $u = $c['username'];
    $pwd = $passwords[$u] ?? '';
    
    // Verify password against DB hash
    if (!password_verify($pwd, $c['password_hash'])) {
        echo "WARNING: Password for $u does not verify against counters.password_hash!\n";
    }
    
    $regions = trim((string)$c['regions_covered']);
    $vCount = (int)$c['visitor_count'];
    $totalVisitors += $vCount;
    
    fputcsv($fp, [
        $c['name'],
        $c['username'],
        $pwd,
        'http://localhost:8080/EventMS/login.php',
        $regions,
        $c['name_range'] ?? '',
        $vCount
    ]);
    
    echo sprintf("ID:%2d | %-40s | %-35s | %-30s | %3d visitors\n", $c['id'], $c['name'], $u, $pwd, $vCount);
}
fclose($fp);

echo "\nTotal active counters written to CSV: " . count($counters) . "\n";
echo "Total visitors sum: " . $totalVisitors . "\n";
