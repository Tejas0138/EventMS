<?php
/**
 * EventMS - Counter Restructuring Migration V2
 * Restructures counters from 24 (1-per-region) to 21 total counters:
 * - 5 Combined counters
 * - 4 Pune counters (alphabetically balanced 73, 73, 72, 72)
 * - 11 Single-region counters (passwords preserved)
 * - 1 Help Desk counter (password preserved)
 * - 12 retired counter accounts disabled in `admins`
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "========================================================\n";
echo "STEP 1: CREATING DATABASE TABLES & COLUMNS\n";
echo "========================================================\n";

// 1. `counters` table
$pdo->exec("
    CREATE TABLE IF NOT EXISTS `counters` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(100) NOT NULL,
        `code` VARCHAR(50) NOT NULL UNIQUE,
        `username` VARCHAR(50) NOT NULL UNIQUE,
        `password_hash` VARCHAR(255) NOT NULL,
        `name_range` VARCHAR(150) NULL DEFAULT NULL,
        `is_active` TINYINT(1) NOT NULL DEFAULT 1,
        `last_login` DATETIME NULL DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
");
echo "Table `counters` checked/created.\n";

// 2. `counter_regions` table
$pdo->exec("
    CREATE TABLE IF NOT EXISTS `counter_regions` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `counter_id` INT UNSIGNED NOT NULL,
        `region` VARCHAR(100) NOT NULL,
        KEY `idx_counter_id` (`counter_id`),
        KEY `idx_region` (`region`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
");
echo "Table `counter_regions` checked/created.\n";

// 3. `counter_reassignment_log` table
$pdo->exec("
    CREATE TABLE IF NOT EXISTS `counter_reassignment_log` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `visitor_id` INT UNSIGNED NOT NULL,
        `visitor_name` VARCHAR(100) NOT NULL,
        `user_id` VARCHAR(50) NULL,
        `old_counter_id` INT UNSIGNED NULL,
        `new_counter_id` INT UNSIGNED NOT NULL,
        `changed_by` VARCHAR(50) NOT NULL,
        `reason` VARCHAR(255) NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
");
echo "Table `counter_reassignment_log` checked/created.\n";

// 4. Add `counter_id` to `allowed_visitors` and `gift_distribution`
foreach (['allowed_visitors', 'gift_distribution'] as $tbl) {
    try {
        $pdo->exec("ALTER TABLE `{$tbl}` ADD COLUMN `counter_id` INT UNSIGNED NULL DEFAULT NULL");
        echo "Added column `counter_id` to `{$tbl}`.\n";
    } catch (\Throwable $t) {}
    try {
        $pdo->exec("ALTER TABLE `{$tbl}` ADD INDEX `idx_counter_id` (`counter_id`)");
    } catch (\Throwable $t) {}
}

// 5. Add `counter_id` to `admins`
try {
    $pdo->exec("ALTER TABLE `admins` ADD COLUMN `counter_id` INT UNSIGNED NULL DEFAULT NULL");
    echo "Added column `counter_id` to `admins`.\n";
} catch (\Throwable $t) {}

echo "\n========================================================\n";
echo "STEP 2: PRESERVED PASSWORDS FOR 12 KEPT ACCOUNTS\n";
echo "========================================================\n";

$existingCsvFile = __DIR__ . '/../counter_credentials.csv';
$csvKeptPasswords = [];
if (file_exists($existingCsvFile)) {
    if (($handle = fopen($existingCsvFile, 'r')) !== false) {
        $hdr = fgetcsv($handle);
        while (($row = fgetcsv($handle)) !== false) {
            if (!empty($row[1]) && !empty($row[2])) {
                $csvKeptPasswords[$row[1]] = trim($row[2]);
            }
        }
        fclose($handle);
    }
}

// Hardcoded fallback passwords from initial seed if CSV was modified
$fallbackKeptPasswords = [
    'counter_helpdesk'   => 'qGS6ZEXFZ$cU',
    'counter_ahmedabad'  => 'gzWRqR4r*29u',
    'counter_ajmer'      => '6AFrUaHD3FkQ',
    'counter_bengaluru'  => 'aJK2@fAZb99w',
    'counter_bhopal'     => 'vBnyxnZHY6XM',
    'counter_bhubaneswar'=> 'S6MEN$@Tb#VV',
    'counter_delhi_east' => 'jbrrUbHUxuaX',
    'counter_delhi_west' => 'HAMJrm#HXygB',
    'counter_noida'      => 'h9baz7GBrh%W',
    'counter_patna'      => 'EyytBmrr9WaR',
    'counter_ranchi'     => '8bVzdZQF@4G%',
    'counter_trivandrum' => '$aqFaeHytHsD',
];

function generateSafePassword(int $length = 12): string {
    $chars = '23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ@#$%*';
    $max = strlen($chars) - 1;
    $pwd = '';
    for ($i = 0; $i < $length; $i++) {
        $pwd .= $chars[random_int(0, $max)];
    }
    return $pwd;
}

echo "\n========================================================\n";
echo "STEP 3: DEFINING 21 COUNTERS\n";
echo "========================================================\n";

$countersDef = [
    // 5 Combined counters
    [
        'name'     => 'Raipur / Chandigarh Counter',
        'code'     => 'raipur_chandigarh',
        'username' => 'counter_raipur_chandigarh',
        'regions'  => ['Raipur', 'Chandigarh'],
        'range'    => null,
        'type'     => 'new'
    ],
    [
        'name'     => 'Dehradun / Lucknow Counter',
        'code'     => 'dehradun_lucknow',
        'username' => 'counter_dehradun_lucknow',
        'regions'  => ['Dehradun', 'Lucknow'],
        'range'    => null,
        'type'     => 'new'
    ],
    [
        'name'     => 'Gurugram / Guwahati Counter',
        'code'     => 'gurugram_guwahati',
        'username' => 'counter_gurugram_guwahati',
        'regions'  => ['Gurugram', 'Guwahati'],
        'range'    => null,
        'type'     => 'new'
    ],
    [
        'name'     => 'Chennai / Vijayawada Counter',
        'code'     => 'chennai_vijayawada',
        'username' => 'counter_chennai_vijayawada',
        'regions'  => ['Chennai', 'Vijayawada'],
        'range'    => null,
        'type'     => 'new'
    ],
    [
        'name'     => 'Panchkula / Prayagraj / Hyderabad Counter',
        'code'     => 'panchkula_prayagraj_hyderabad',
        'username' => 'counter_panchkula_prayagraj_hyderabad',
        'regions'  => ['Panchkula', 'Prayagraj', 'Hyderabad'],
        'range'    => null,
        'type'     => 'new'
    ],
    // 4 Pune counters
    [
        'name'     => 'Pune Counter 1',
        'code'     => 'pune_1',
        'username' => 'counter_pune_1',
        'regions'  => ['Pune'],
        'range'    => 'A to Chetan Sonawane',
        'type'     => 'new',
        'pune_grp' => 1
    ],
    [
        'name'     => 'Pune Counter 2',
        'code'     => 'pune_2',
        'username' => 'counter_pune_2',
        'regions'  => ['Pune'],
        'range'    => 'Chetana Naik to Namira Contractor',
        'type'     => 'new',
        'pune_grp' => 2
    ],
    [
        'name'     => 'Pune Counter 3',
        'code'     => 'pune_3',
        'username' => 'counter_pune_3',
        'regions'  => ['Pune'],
        'range'    => 'Namrata Bele to Sangeeta Rautji',
        'type'     => 'new',
        'pune_grp' => 3
    ],
    [
        'name'     => 'Pune Counter 4',
        'code'     => 'pune_4',
        'username' => 'counter_pune_4',
        'regions'  => ['Pune'],
        'range'    => 'Santosh Patil to Zeenat Syed',
        'type'     => 'new',
        'pune_grp' => 4
    ],
    // 11 Single-region counters (kept)
    [
        'name'     => 'Noida Counter',
        'code'     => 'noida',
        'username' => 'counter_noida',
        'regions'  => ['Noida'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Bengaluru Counter',
        'code'     => 'bengaluru',
        'username' => 'counter_bengaluru',
        'regions'  => ['Bengaluru'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Bhopal Counter',
        'code'     => 'bhopal',
        'username' => 'counter_bhopal',
        'regions'  => ['Bhopal'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Bhubaneswar Counter',
        'code'     => 'bhubaneswar',
        'username' => 'counter_bhubaneswar',
        'regions'  => ['Bhubaneswar'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Ajmer Counter',
        'code'     => 'ajmer',
        'username' => 'counter_ajmer',
        'regions'  => ['Ajmer'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Ahmedabad Counter',
        'code'     => 'ahmedabad',
        'username' => 'counter_ahmedabad',
        'regions'  => ['Ahmedabad'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Patna Counter',
        'code'     => 'patna',
        'username' => 'counter_patna',
        'regions'  => ['Patna'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Trivandrum Counter',
        'code'     => 'trivandrum',
        'username' => 'counter_trivandrum',
        'regions'  => ['Trivandrum'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Delhi West Counter',
        'code'     => 'delhi_west',
        'username' => 'counter_delhi_west',
        'regions'  => ['Delhi West'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Delhi East Counter',
        'code'     => 'delhi_east',
        'username' => 'counter_delhi_east',
        'regions'  => ['Delhi East'],
        'range'    => null,
        'type'     => 'kept'
    ],
    [
        'name'     => 'Ranchi Counter',
        'code'     => 'ranchi',
        'username' => 'counter_ranchi',
        'regions'  => ['Ranchi'],
        'range'    => null,
        'type'     => 'kept'
    ],
    // 1 Help Desk counter (kept)
    [
        'name'     => 'Help Desk',
        'code'     => 'helpdesk',
        'username' => 'counter_helpdesk',
        'regions'  => ['Help Desk', ''],
        'range'    => null,
        'type'     => 'kept'
    ]
];

echo "Total counters defined: " . count($countersDef) . "\n";

echo "\n========================================================\n";
echo "STEP 4: SEEDING / SYNCHRONIZING `counters` & `admins`\n";
echo "========================================================\n";

$finalCredentials = [];
$counterIdMap = []; // code => id

foreach ($countersDef as &$cDef) {
    $u = $cDef['username'];
    $plainPassword = '';

    // Check if account already exists in admins
    $adminStmt = $pdo->prepare("SELECT id, password, status FROM admins WHERE username = :u LIMIT 1");
    $adminStmt->execute([':u' => $u]);
    $existingAdmin = $adminStmt->fetch(PDO::FETCH_ASSOC);

    if ($cDef['type'] === 'kept') {
        $plainPassword = $csvKeptPasswords[$u] ?? $fallbackKeptPasswords[$u] ?? 'EventMS@2026';
        if ($existingAdmin) {
            $pwdHash = $existingAdmin['password'];
            // Re-hash if needed or keep existing
            $pdo->prepare("UPDATE admins SET status = 'active', region = :r WHERE id = :id")
                ->execute([':r' => $cDef['name'], ':id' => $existingAdmin['id']]);
        } else {
            $pwdHash = password_hash($plainPassword, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO admins (username, password, role, region, status) VALUES (:u, :p, 'counter', :r, 'active')")
                ->execute([':u' => $u, ':p' => $pwdHash, ':r' => $cDef['name']]);
            $existingAdmin = ['id' => $pdo->lastInsertId(), 'password' => $pwdHash];
        }
    } else {
        // New counter account
        if ($existingAdmin) {
            // If already created in a previous run of this script, retrieve password from CSV if possible
            $plainPassword = $csvKeptPasswords[$u] ?? generateSafePassword(12);
            $pwdHash = password_hash($plainPassword, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE admins SET password = :p, status = 'active', region = :r, failed_attempts = 0, locked_until = NULL WHERE id = :id")
                ->execute([':p' => $pwdHash, ':r' => $cDef['name'], ':id' => $existingAdmin['id']]);
        } else {
            $plainPassword = generateSafePassword(12);
            $pwdHash = password_hash($plainPassword, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO admins (username, password, role, region, status) VALUES (:u, :p, 'counter', :r, 'active')")
                ->execute([':u' => $u, ':p' => $pwdHash, ':r' => $cDef['name']]);
            $existingAdmin = ['id' => $pdo->lastInsertId(), 'password' => $pwdHash];
        }
    }

    // Now upsert into `counters` table
    $cntStmt = $pdo->prepare("SELECT id FROM counters WHERE code = :code LIMIT 1");
    $cntStmt->execute([':code' => $cDef['code']]);
    $existingCounterId = $cntStmt->fetchColumn();

    if ($existingCounterId) {
        $counterId = (int)$existingCounterId;
        $pdo->prepare("
            UPDATE counters 
            SET name = :name, username = :username, password_hash = :p, name_range = :range, is_active = 1 
            WHERE id = :id
        ")->execute([
            ':name'     => $cDef['name'],
            ':username' => $cDef['username'],
            ':p'        => $pwdHash,
            ':range'    => $cDef['range'],
            ':id'       => $counterId
        ]);
    } else {
        $pdo->prepare("
            INSERT INTO counters (name, code, username, password_hash, name_range, is_active)
            VALUES (:name, :code, :username, :p, :range, 1)
        ")->execute([
            ':name'     => $cDef['name'],
            ':code'     => $cDef['code'],
            ':username' => $cDef['username'],
            ':p'        => $pwdHash,
            ':range'    => $cDef['range'],
        ]);
        $counterId = (int)$pdo->lastInsertId();
    }

    $cDef['id'] = $counterId;
    $counterIdMap[$cDef['code']] = $counterId;

    // Link counter_id back to admins
    $pdo->prepare("UPDATE admins SET counter_id = :cid WHERE username = :u")
        ->execute([':cid' => $counterId, ':u' => $u]);

    // Update `counter_regions`
    $pdo->prepare("DELETE FROM counter_regions WHERE counter_id = :cid")->execute([':cid' => $counterId]);
    $crIns = $pdo->prepare("INSERT INTO counter_regions (counter_id, region) VALUES (:cid, :region)");
    foreach ($cDef['regions'] as $reg) {
        $crIns->execute([':cid' => $counterId, ':region' => $reg]);
    }

    $finalCredentials[] = [
        'counter_id'       => $counterId,
        'counter_name'     => $cDef['name'],
        'username'         => $cDef['username'],
        'password'         => $plainPassword,
        'type'             => $cDef['type'],
        'regions_covered'  => implode(', ', array_filter($cDef['regions'])),
        'name_range'       => $cDef['range'] ?? '',
        'visitors_count'   => 0
    ];

    echo sprintf(" - [%s] ID:%2d | %-25s | %s\n", strtoupper($cDef['type']), $counterId, $cDef['username'], $cDef['name']);
}

echo "\n========================================================\n";
echo "STEP 5: RETIRING THE 12 OLD COUNTER ACCOUNTS\n";
echo "========================================================\n";

$retiredUsernames = [
    'counter_raipur',
    'counter_chandigarh',
    'counter_dehradun',
    'counter_lucknow',
    'counter_gurugram',
    'counter_guwahati',
    'counter_chennai',
    'counter_vijayawada',
    'counter_panchkula',
    'counter_prayagraj',
    'counter_hyderabad',
    'counter_pune'
];

$retireStmt = $pdo->prepare("UPDATE admins SET status = 'disabled', counter_id = NULL WHERE username = :u");
foreach ($retiredUsernames as $ru) {
    $retireStmt->execute([':u' => $ru]);
    echo " - [DISABLED] {$ru}\n";
}

echo "\n========================================================\n";
echo "STEP 6: ASSIGNING VISITORS TO COUNTERS\n";
echo "========================================================\n";

// Function to clean name for sorting (ignoring titles)
function cleanNameForSort(string $name): string {
    $clean = trim($name);
    $clean = preg_replace('/^(dr\.?|mr\.?|mrs\.?|ms\.?|prof\.?|sh\.?|smt\.?|shri\.?)\s+/i', '', $clean);
    return trim($clean);
}

// 1. Assign Pune visitors (290)
$puneStmt = $pdo->query("SELECT id, name, user_id FROM allowed_visitors WHERE LOWER(TRIM(region)) = 'pune'");
$puneVisitors = $puneStmt->fetchAll(PDO::FETCH_ASSOC);

usort($puneVisitors, function($a, $b) {
    $nameA = cleanNameForSort($a['name']);
    $nameB = cleanNameForSort($b['name']);
    $cmp = strcasecmp($nameA, $nameB);
    if ($cmp !== 0) return $cmp;
    return strcasecmp($a['name'], $b['name']);
});

$puneGroups = [
    1 => array_slice($puneVisitors, 0, 73),
    2 => array_slice($puneVisitors, 73, 73),
    3 => array_slice($puneVisitors, 146, 72),
    4 => array_slice($puneVisitors, 218, 72),
];

$updVis = $pdo->prepare("UPDATE allowed_visitors SET counter_id = :cid WHERE id = :id");
$updGift = $pdo->prepare("UPDATE gift_distribution SET counter_id = :cid WHERE user_id = :uid");

foreach ($puneGroups as $grpNum => $slice) {
    $cid = $counterIdMap['pune_' . $grpNum];
    echo "Assigning Pune Group {$grpNum} (" . count($slice) . " visitors) to counter_id {$cid}...\n";
    foreach ($slice as $v) {
        $updVis->execute([':cid' => $cid, ':id' => $v['id']]);
        $updGift->execute([':cid' => $cid, ':uid' => $v['user_id']]);
    }
}

// 2. Assign Non-Pune visitors based on region
$regMapToCounter = [
    'Raipur'      => $counterIdMap['raipur_chandigarh'],
    'Chandigarh'  => $counterIdMap['raipur_chandigarh'],
    'Dehradun'    => $counterIdMap['dehradun_lucknow'],
    'Lucknow'     => $counterIdMap['dehradun_lucknow'],
    'Gurugram'    => $counterIdMap['gurugram_guwahati'],
    'Guwahati'    => $counterIdMap['gurugram_guwahati'],
    'Chennai'     => $counterIdMap['chennai_vijayawada'],
    'Vijayawada'  => $counterIdMap['chennai_vijayawada'],
    'Panchkula'   => $counterIdMap['panchkula_prayagraj_hyderabad'],
    'Prayagraj'   => $counterIdMap['panchkula_prayagraj_hyderabad'],
    'Hyderabad'   => $counterIdMap['panchkula_prayagraj_hyderabad'],
    'Noida'       => $counterIdMap['noida'],
    'Bengaluru'   => $counterIdMap['bengaluru'],
    'Bhopal'      => $counterIdMap['bhopal'],
    'Bhubaneswar' => $counterIdMap['bhubaneswar'],
    'Ajmer'       => $counterIdMap['ajmer'],
    'Ahmedabad'   => $counterIdMap['ahmedabad'],
    'Patna'       => $counterIdMap['patna'],
    'Trivandrum'  => $counterIdMap['trivandrum'],
    'Delhi West'  => $counterIdMap['delhi_west'],
    'Delhi East'  => $counterIdMap['delhi_east'],
    'Ranchi'      => $counterIdMap['ranchi'],
];

$helpDeskCid = $counterIdMap['helpdesk'];

// Query all non-pune visitors
$otherStmt = $pdo->query("SELECT id, name, user_id, region FROM allowed_visitors WHERE region IS NULL OR LOWER(TRIM(region)) != 'pune'");
while ($v = $otherStmt->fetch(PDO::FETCH_ASSOC)) {
    $reg = trim((string)($v['region'] ?? ''));
    $targetCid = $helpDeskCid;
    if ($reg !== '') {
        foreach ($regMapToCounter as $rKey => $cidVal) {
            if (strcasecmp($reg, $rKey) === 0) {
                $targetCid = $cidVal;
                break;
            }
        }
    }
    $updVis->execute([':cid' => $targetCid, ':id' => $v['id']]);
    $updGift->execute([':cid' => $targetCid, ':uid' => $v['user_id']]);
}

echo "All visitors successfully assigned!\n";

echo "\n========================================================\n";
echo "STEP 7: VERIFY COUNTS & WRITE CREDENTIALS CSV\n";
echo "========================================================\n";

$countStmt = $pdo->query("
    SELECT c.id, c.name, c.username, c.name_range, COUNT(v.id) as vcount
    FROM counters c
    LEFT JOIN allowed_visitors v ON v.counter_id = c.id
    GROUP BY c.id, c.name, c.username, c.name_range
    ORDER BY c.id ASC
");
$counterCounts = $countStmt->fetchAll(PDO::FETCH_ASSOC);

$totalSum = 0;
$countsById = [];
foreach ($counterCounts as $cc) {
    $countsById[$cc['id']] = (int)$cc['vcount'];
    $totalSum += (int)$cc['vcount'];
    echo sprintf("Counter #%2d | %-42s (%-32s) : %4d visitors\n", $cc['id'], $cc['name'], $cc['username'], $cc['vcount']);
}
echo "--------------------------------------------------------\n";
echo "TOTAL ASSIGNED VISITORS: {$totalSum} (Expected: 1269)\n";

// Update credential rows with visitor count
foreach ($finalCredentials as &$fc) {
    $fc['visitors_count'] = $countsById[$fc['counter_id']] ?? 0;
}

// Write to counter_credentials.csv
$csvOut = fopen(__DIR__ . '/../counter_credentials.csv', 'w');
fputcsv($csvOut, ['counter_name', 'username', 'password', 'login_url', 'regions_covered', 'name_range', 'number_of_visitors']);
foreach ($finalCredentials as $fc) {
    fputcsv($csvOut, [
        $fc['counter_name'],
        $fc['username'],
        $fc['password'],
        'http://localhost:8080/EventMS/login.php',
        $fc['regions_covered'] ?: ($fc['counter_name'] === 'Help Desk' ? 'Unassigned / Help Desk' : $fc['counter_name']),
        $fc['name_range'],
        $fc['visitors_count']
    ]);
}
fclose($csvOut);
echo "Wrote 21 counter credentials to counter_credentials.csv.\n";

echo "\n========================================================\n";
echo "STEP 8: THE 9 NEW COUNTER CREDENTIALS SUMMARY\n";
echo "========================================================\n";
echo sprintf("%-35s | %-36s | %-15s | %-30s | %s\n", "Counter Name", "Username", "Password", "Regions / Range", "Visitors");
echo str_repeat("-", 130) . "\n";
foreach ($finalCredentials as $fc) {
    if ($fc['type'] === 'new') {
        $detail = !empty($fc['name_range']) ? $fc['name_range'] : $fc['regions_covered'];
        echo sprintf("%-35s | %-36s | %-15s | %-30s | %d\n", $fc['counter_name'], $fc['username'], $fc['password'], $detail, $fc['visitors_count']);
    }
}
echo "========================================================\n";
