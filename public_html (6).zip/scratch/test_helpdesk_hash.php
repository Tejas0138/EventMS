<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();
$aHash = $pdo->query("SELECT password FROM admins WHERE username = 'counter_helpdesk'")->fetchColumn();
$cHash = $pdo->query("SELECT password_hash FROM counters WHERE username = 'counter_helpdesk'")->fetchColumn();
echo "admins password_verify HelpDesk@2026: " . (password_verify('HelpDesk@2026', $aHash) ? 'YES' : 'NO') . "\n";
echo "counters password_verify HelpDesk@2026: " . (password_verify('HelpDesk@2026', $cHash) ? 'YES' : 'NO') . "\n";
