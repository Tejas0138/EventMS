<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

// Check empty region in allowed_visitors
$emptyRegionStmt = $pdo->query("SELECT id, name, user_id, region FROM allowed_visitors WHERE region IS NULL OR TRIM(region) = ''");
$emptyRegion = $emptyRegionStmt->fetchAll(PDO::FETCH_ASSOC);

echo "Visitors with empty or NULL region in allowed_visitors: " . count($emptyRegion) . "\n";
foreach ($emptyRegion as $r) {
    echo "  - ID {$r['id']} | {$r['name']} | {$r['user_id']} | Region: '{$r['region']}'\n";
}

// Check unassigned or null counter in gift_distribution
$noCounterStmt = $pdo->query("
    SELECT g.id, g.user_id, g.counter_id, v.name, v.region 
    FROM gift_distribution g 
    JOIN allowed_visitors v ON g.user_id = v.user_id 
    WHERE g.counter_id IS NULL OR g.counter_id <= 0 OR g.counter_id = 21
");
$noCounter = $noCounterStmt->fetchAll(PDO::FETCH_ASSOC);
echo "Visitors with no counter or assigned to Helpdesk (ID 21) in gift_distribution: " . count($noCounter) . "\n";
foreach ($noCounter as $nc) {
    echo "  - Gift ID {$nc['id']} | Visitor: {$nc['name']} ({$nc['user_id']}) | Region: {$nc['region']} | Counter ID: {$nc['counter_id']}\n";
}

// Check total visitors count vs sum across active 20 counters
$totalVisitors = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
echo "Total allowed visitors: $totalVisitors\n";

$countersStmt = $pdo->query("
    SELECT c.id, c.name, COUNT(g.id) as assigned_count
    FROM counters c
    LEFT JOIN gift_distribution g ON g.counter_id = c.id
    WHERE c.id <= 20
    GROUP BY c.id, c.name
    ORDER BY c.id
");
$sumAssigned = 0;
while ($c = $countersStmt->fetch(PDO::FETCH_ASSOC)) {
    echo "Counter {$c['id']}: {$c['name']} -> {$c['assigned_count']} visitors\n";
    $sumAssigned += (int)$c['assigned_count'];
}
echo "Sum assigned across active 20 counters: $sumAssigned\n";
