<?php
require_once __DIR__ . '/test_pune_split.php'; // Defines cleanNameForSort and shows cutoffs

$testNames = [
    'MANPREET KAUR',
    'NIDHI NAVIN SHETTY',
    'RUKHSAR RAMZANALI POMETKAR'
];

echo "\n--- PUNE BOUNDARIES COMPARISON ---\n";
// Pune 1: <= 'Chetan Sonawane'
// Pune 2: > 'Chetan Sonawane' and <= 'Namira Contractor'
// Pune 3: > 'Namira Contractor' and <= 'Sangeeta Rautji'
// Pune 4: > 'Sangeeta Rautji'

foreach ($testNames as $name) {
    $cName = cleanNameForSort($name);
    echo "Name: '$name' (Sort: '$cName')\n";
    if (strcasecmp($cName, 'Chetan Sonawane') <= 0) {
        $puneGrp = 1;
        $counterId = 6;
    } elseif (strcasecmp($cName, 'Namira Yunus Contractor') <= 0) {
        $puneGrp = 2;
        $counterId = 7;
    } elseif (strcasecmp($cName, 'Sangeeta Rautji') <= 0) {
        $puneGrp = 3;
        $counterId = 8;
    } else {
        $puneGrp = 4;
        $counterId = 9;
    }
    echo " -> Pune Counter $puneGrp (ID: $counterId)\n";
}
