<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$rows = $pdo->query("
    SELECT c.id, c.name, 
           GROUP_CONCAT(cr.region ORDER BY cr.region SEPARATOR ', ') as regions,
           COUNT(g.id) as visitor_count
    FROM counters c
    LEFT JOIN counter_regions cr ON cr.counter_id = c.id
    LEFT JOIN gift_distribution g ON g.counter_id = c.id
    WHERE c.id <= 20
    GROUP BY c.id, c.name
    ORDER BY c.id
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($rows as $r) {
    echo "ID {$r['id']}: {$r['name']} | Regions: '{$r['regions']}' | Visitors: {$r['visitor_count']}\n";
}
