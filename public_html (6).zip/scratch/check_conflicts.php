<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

require_once __DIR__ . '/parse_excel_test.php';

$data = parseXlsx(__DIR__ . '/../raw_data_AG_updated.xlsx');
$missingDetails = $data['Missing Details'];

echo "=== CONFLICT AND VALIDATION CHECK ===\n";

$conflicts = [];
$phoneChecks = [];

for ($r = 6; $r <= 21; $r++) {
    if (!isset($missingDetails[$r])) continue;
    $row = $missingDetails[$r];
    $userId = trim($row['C'] ?? '');
    if (empty($userId)) continue;

    $sno = trim($row['A'] ?? '');
    $region = trim($row['B'] ?? '');
    $school = trim($row['D'] ?? '');
    $name = trim($row['E'] ?? '');
    $desig = trim($row['F'] ?? '');
    $contact = trim($row['G'] ?? '');
    $email = trim($row['H'] ?? '');
    $fincert = trim($row['I'] ?? '');
    $field = trim($row['J'] ?? '');

    // Check phone format
    $digits = preg_replace('/\D/', '', $contact);
    if (!empty($contact)) {
        // Check duplicate in DB
        $stmtDup = $pdo->prepare("SELECT id, user_id, name, mobile FROM allowed_visitors WHERE mobile = ? AND LOWER(TRIM(user_id)) != LOWER(TRIM(?))");
        $stmtDup->execute([$digits, $userId]);
        $dup = $stmtDup->fetch(PDO::FETCH_ASSOC);

        $phoneChecks[] = [
            'user_id' => $userId,
            'name' => $name,
            'raw_contact' => $contact,
            'digits' => $digits,
            'length' => strlen($digits),
            'duplicate_with' => $dup ? "{$dup['user_id']} ({$dup['name']})" : "No duplicate"
        ];
    }

    // Match in DB
    $stmt = $pdo->prepare("SELECT * FROM allowed_visitors WHERE LOWER(TRIM(user_id)) = LOWER(TRIM(?))");
    $stmt->execute([$userId]);
    $db = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($db) {
        // Compare each field where DB is NOT empty and sheet is DIFFERENT
        $compareFields = [
            'name' => [$db['name'], $name],
            'region' => [$db['region'], $region],
            'school_name' => [$db['school_name'], $school],
            'designation' => [$db['designation'], $desig],
            'mobile' => [$db['mobile'], $digits],
            'email' => [$db['email'], $email],
            'fincert' => [$db['fincert'], $fincert]
        ];

        foreach ($compareFields as $fName => $vals) {
            $dbVal = trim($vals[0] ?? '');
            $sheetVal = trim($vals[1] ?? '');
            if ($fName === 'region') {
                // normalize region comparison
                $dbValNorm = ucwords(strtolower($dbVal));
                $sheetValNorm = ucwords(strtolower($sheetVal));
            } else {
                $dbValNorm = $dbVal;
                $sheetValNorm = $sheetVal;
            }

            if (!empty($dbVal) && !empty($sheetVal) && strcasecmp($dbValNorm, $sheetValNorm) !== 0) {
                $conflicts[] = [
                    'user_id' => $userId,
                    'name' => $db['name'],
                    'field' => $fName,
                    'db_val' => $dbVal,
                    'sheet_val' => $sheetVal
                ];
            }
        }
    }
}

echo "\n--- PHONE VALIDATION & DUPLICATE CHECKS ---\n";
foreach ($phoneChecks as $p) {
    echo "UserID: {$p['user_id']} | Contact: {$p['digits']} (len: {$p['length']}) | Duplicate: {$p['duplicate_with']}\n";
}

echo "\n--- CONFLICTS (DB non-empty vs Sheet different) ---\n";
if (empty($conflicts)) {
    echo "0 conflicts found! All existing non-empty DB values match or are unchanged.\n";
} else {
    echo count($conflicts) . " conflict(s) found:\n";
    foreach ($conflicts as $c) {
        echo "UserID: {$c['user_id']} | Name: {$c['name']} | Field: {$c['field']} | DB: '{$c['db_val']}' | Sheet: '{$c['sheet_val']}'\n";
    }
}
