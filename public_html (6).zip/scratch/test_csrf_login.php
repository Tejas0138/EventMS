<?php
/**
 * Test login function with CSRF handling
 */
function postLoginWithCsrf($user, $pass) {
    $cookieFile = __DIR__ . '/test_cookie.txt';
    if (file_exists($cookieFile)) unlink($cookieFile);

    // 1. GET login page to obtain session cookie & CSRF token
    $ch = curl_init('http://localhost:8080/EventMS/login.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    $html = curl_exec($ch);
    curl_close($ch);

    // Extract CSRF token
    preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', $html, $matches);
    $csrf = $matches[1] ?? '';

    // 2. POST credentials with CSRF token and session cookie
    $ch = curl_init('http://localhost:8080/EventMS/login.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'csrf_token' => $csrf,
        'username' => $user,
        'password' => $pass
    ]));
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (file_exists($cookieFile)) unlink($cookieFile);
    return ['code' => $httpCode, 'body' => $response, 'csrf' => $csrf];
}

$res = postLoginWithCsrf('counter_helpdesk', 'qGS6ZEXFZ$cU');
echo "HTTP Code: {$res['code']}\n";
echo "Response body contains 'disabled': " . (stripos($res['body'], 'disabled') !== false ? 'YES' : 'NO') . "\n";
echo "Response body excerpt:\n";
preg_match('/<div class="alert[^>]*>(.*?)<\/div>/is', $res['body'], $alertMatches);
echo trim(strip_tags($alertMatches[0] ?? $res['body'])) . "\n";
