<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$testsPassed = 0;
$testsFailed = 0;

function assertTest(string $desc, bool $condition, string $details = '') {
    global $testsPassed, $testsFailed;
    if ($condition) {
        $testsPassed++;
        echo "[PASS] " . $desc . ($details ? " ($details)" : "") . "\n";
    } else {
        $testsFailed++;
        echo "[FAIL] " . $desc . ($details ? " ($details)" : "") . "\n";
    }
}

echo "=== EVENTMS VERIFICATION SUITE ===\n\n";

// 1. Total active counters = 21 in `counters`
$cCount = (int)$pdo->query("SELECT COUNT(*) FROM counters WHERE is_active = 1")->fetchColumn();
assertTest("Total active counters count", $cCount === 21, "Found: $cCount, Expected: 21");

// Check counter names & codes
$counters = $pdo->query("SELECT id, name, code, username, name_range FROM counters ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
assertTest("Loaded counters table", count($counters) === 21, "Count: " . count($counters));

// 2. Total assigned visitors = 1269 in both allowed_visitors and gift_distribution
$visTotal = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
$visAssigned = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id IS NOT NULL AND counter_id > 0")->fetchColumn();
assertTest("Total visitors in allowed_visitors", $visTotal === 1269, "Found: $visTotal");
assertTest("All allowed_visitors assigned to a counter", $visAssigned === 1269, "Assigned: $visAssigned / $visTotal");

$giftTotal = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution")->fetchColumn();
$giftAssigned = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE counter_id IS NOT NULL AND counter_id > 0")->fetchColumn();
assertTest("Total visitors in gift_distribution", $giftTotal === 1269, "Found: $giftTotal");
assertTest("All gift_distribution assigned to a counter", $giftAssigned === 1269, "Assigned: $giftAssigned / $giftTotal");

// 3. Pune split: groups 1-4 have counts 73, 73, 72, 72
$pune1 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_1')")->fetchColumn();
$pune2 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_2')")->fetchColumn();
$pune3 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_3')")->fetchColumn();
$pune4 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_4')")->fetchColumn();

assertTest("Pune Counter 1 attendee count", $pune1 === 73, "Found: $pune1, Expected: 73");
assertTest("Pune Counter 2 attendee count", $pune2 === 73, "Found: $pune2, Expected: 73");
assertTest("Pune Counter 3 attendee count", $pune3 === 72, "Found: $pune3, Expected: 72");
assertTest("Pune Counter 4 attendee count", $pune4 === 72, "Found: $pune4, Expected: 72");
assertTest("Total Pune attendees", ($pune1 + $pune2 + $pune3 + $pune4) === 290, "Sum: " . ($pune1 + $pune2 + $pune3 + $pune4));

// Verify first & last attendee names in each Pune counter
$p1Visitors = $pdo->query("SELECT name FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_1')")->fetchAll(PDO::FETCH_COLUMN);
usort($p1Visitors, function($a, $b) {
    return strcasecmp(cleanNameForSort($a), cleanNameForSort($b));
});
$p1First = reset($p1Visitors);
$p1Last = end($p1Visitors);

$p2Visitors = $pdo->query("SELECT name FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_2')")->fetchAll(PDO::FETCH_COLUMN);
usort($p2Visitors, function($a, $b) {
    return strcasecmp(cleanNameForSort($a), cleanNameForSort($b));
});
$p2First = reset($p2Visitors);
$p2Last = end($p2Visitors);

$p3Visitors = $pdo->query("SELECT name FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_3')")->fetchAll(PDO::FETCH_COLUMN);
usort($p3Visitors, function($a, $b) {
    return strcasecmp(cleanNameForSort($a), cleanNameForSort($b));
});
$p3First = reset($p3Visitors);
$p3Last = end($p3Visitors);

$p4Visitors = $pdo->query("SELECT name FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_4')")->fetchAll(PDO::FETCH_COLUMN);
usort($p4Visitors, function($a, $b) {
    return strcasecmp(cleanNameForSort($a), cleanNameForSort($b));
});
$p4First = reset($p4Visitors);
$p4Last = end($p4Visitors);

assertTest("Pune 1 range boundary", strcasecmp(cleanNameForSort($p1First), 'Aarti Bhujbal') === 0 && strcasecmp(cleanNameForSort($p1Last), 'Chetan Sonawane') === 0, "$p1First to $p1Last");
assertTest("Pune 2 range boundary", strcasecmp(cleanNameForSort($p2First), 'Chetana Samit Naik') === 0 && strcasecmp(cleanNameForSort($p2Last), 'Namira Yunus Contractor') === 0, "$p2First to $p2Last");
assertTest("Pune 3 range boundary", strcasecmp(cleanNameForSort($p3First), 'Namrata Nitin Bele') === 0 && strcasecmp(cleanNameForSort($p3Last), 'Sangeeta Rautji') === 0, "$p3First to $p3Last");
assertTest("Pune 4 range boundary", strcasecmp(cleanNameForSort($p4First), 'Santosh Bharat Patil') === 0 && strcasecmp(cleanNameForSort($p4Last), 'Zeenat Syed') === 0, "$p4First to $p4Last");

// 4. Verify 12 kept accounts passwords
$preservedAccounts = [
    'counter_helpdesk'    => 'qGS6ZEXFZ$cU',
    'counter_ahmedabad'   => 'gzWRqR4r*29u',
    'counter_ajmer'       => '6AFrUaHD3FkQ',
    'counter_bengaluru'   => 'aJK2@fAZb99w',
    'counter_bhopal'      => 'vBnyxnZHY6XM',
    'counter_bhubaneswar' => 'S6MEN$@Tb#VV',
    'counter_delhi_east'  => 'jbrrUbHUxuaX',
    'counter_delhi_west'  => 'HAMJrm#HXygB',
    'counter_noida'       => 'h9baz7GBrh%W',
    'counter_patna'       => 'EyytBmrr9WaR',
    'counter_ranchi'      => '8bVzdZQF@4G%',
    'counter_trivandrum'  => '$aqFaeHytHsD',
];

$allKeptMatch = true;
foreach ($preservedAccounts as $u => $p) {
    $h = $pdo->query("SELECT password FROM admins WHERE username = " . $pdo->quote($u))->fetchColumn();
    if (!$h || !password_verify($p, $h)) {
        $allKeptMatch = false;
        echo "[ERR] Password mismatch for kept account: $u\n";
    }
}
assertTest("12 Kept accounts preserved passwords verify", $allKeptMatch, "12 / 12 verified");

// 5. Verify 12 retired accounts have status = 'disabled' in admins
$retiredAccounts = [
    'counter_raipur', 'counter_chandigarh', 'counter_dehradun', 'counter_lucknow',
    'counter_gurugram', 'counter_guwahati', 'counter_chennai', 'counter_vijayawada',
    'counter_panchkula', 'counter_prayagraj', 'counter_hyderabad', 'counter_pune'
];
$retiredOk = true;
foreach ($retiredAccounts as $u) {
    $s = $pdo->query("SELECT status FROM admins WHERE username = " . $pdo->quote($u))->fetchColumn();
    if ($s !== 'disabled') {
        $retiredOk = false;
        echo "[ERR] Retired account not disabled: $u (status: $s)\n";
    }
}
assertTest("12 Retired accounts are disabled", $retiredOk, "12 / 12 disabled");

// 6. Verify 9 new accounts passwords
$newAccounts = [
    'counter_raipur_chandigarh'              => 'ncYb4wXA8esm',
    'counter_dehradun_lucknow'                => 'g9gk@5kuNRdw',
    'counter_gurugram_guwahati'               => 'ugmCY7GutVeB',
    'counter_chennai_vijayawada'              => 'eqrPXDc8n$Vr',
    'counter_panchkula_prayagraj_hyderabad'  => 'ss#MPf9YQwZj',
    'counter_pune_1'                          => 'v*GJwMTF5CW3',
    'counter_pune_2'                          => 'Y@9ExHgqSh7V',
    'counter_pune_3'                          => 'vrvqKGbeg%%P',
    'counter_pune_4'                          => 'eEw8wjUUbcR@',
];

$allNewMatch = true;
foreach ($newAccounts as $u => $p) {
    $h = $pdo->query("SELECT password FROM admins WHERE username = " . $pdo->quote($u))->fetchColumn();
    if (!$h || !password_verify($p, $h)) {
        $allNewMatch = false;
        echo "[ERR] Password mismatch for new account: $u\n";
    }
    // Also check counters table
    $ch = $pdo->query("SELECT password_hash FROM counters WHERE username = " . $pdo->quote($u))->fetchColumn();
    if (!$ch || !password_verify($p, $ch)) {
        $allNewMatch = false;
        echo "[ERR] Counters table password mismatch for new account: $u\n";
    }
}
assertTest("9 New accounts generated passwords verify in admins & counters", $allNewMatch, "9 / 9 verified");

// 7. Gate terminal check-in simulation
// Pune visitor
$puneVis = $pdo->query("SELECT v.*, c.name AS counter_name FROM allowed_visitors v JOIN counters c ON c.id = v.counter_id WHERE LOWER(TRIM(v.region)) = 'pune' LIMIT 1")->fetch(PDO::FETCH_ASSOC);
assertTest("Gate check-in logic: Pune attendee returns Pune Counter", strpos($puneVis['counter_name'], 'Pune Counter') === 0, "Counter: " . $puneVis['counter_name']);

// Combined region visitor (e.g. Raipur)
$raipurVis = $pdo->query("SELECT v.*, c.name AS counter_name FROM allowed_visitors v JOIN counters c ON c.id = v.counter_id WHERE LOWER(TRIM(v.region)) = 'raipur' LIMIT 1")->fetch(PDO::FETCH_ASSOC);
assertTest("Gate check-in logic: Raipur attendee returns Raipur / Chandigarh Counter", $raipurVis['counter_name'] === 'Raipur / Chandigarh Counter', "Counter: " . $raipurVis['counter_name']);

// Single region visitor (e.g. Noida)
$noidaVis = $pdo->query("SELECT v.*, c.name AS counter_name FROM allowed_visitors v JOIN counters c ON c.id = v.counter_id WHERE LOWER(TRIM(v.region)) = 'noida' LIMIT 1")->fetch(PDO::FETCH_ASSOC);
assertTest("Gate check-in logic: Noida attendee returns Noida Counter", $noidaVis['counter_name'] === 'Noida Counter', "Counter: " . $noidaVis['counter_name']);

// Empty region visitor -> Help Desk
$helpVis = $pdo->query("SELECT v.*, c.name AS counter_name FROM allowed_visitors v JOIN counters c ON c.id = v.counter_id WHERE v.region IS NULL OR TRIM(v.region) = '' LIMIT 1")->fetch(PDO::FETCH_ASSOC);
assertTest("Gate check-in logic: Empty region attendee returns Help Desk", $helpVis['counter_name'] === 'Help Desk', "Counter: " . $helpVis['counter_name']);

// 8. COE Kit terminal logic simulation (gift.php)
// Test attendee belonging to Pune Counter 1
$p1Attendee = $pdo->query("
    SELECT g.*, c.name AS assigned_counter_name, c.name_range AS assigned_counter_range, c.id AS assigned_cid
    FROM gift_distribution g
    JOIN counters c ON c.id = g.counter_id
    WHERE c.code = 'pune_1'
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC);

// Simulating logged in as Pune Counter 1 staff
$counterUserPune1 = [
    'role' => 'counter',
    'counter_id' => (int)$p1Attendee['assigned_cid'],
    'counter_name' => 'Pune Counter 1'
];
$matchP1 = ((int)$counterUserPune1['counter_id'] === (int)$p1Attendee['assigned_cid']);
assertTest("COE Kit Terminal: Pune-1 counter matches Pune-1 visitor", $matchP1, "Visitor: {$p1Attendee['name']} -> {$p1Attendee['assigned_counter_name']}");

// Test attendee belonging to Pune Counter 2 attempting claim at Pune Counter 1
$p2Attendee = $pdo->query("
    SELECT g.*, c.name AS assigned_counter_name, c.name_range AS assigned_counter_range, c.id AS assigned_cid
    FROM gift_distribution g
    JOIN counters c ON c.id = g.counter_id
    WHERE c.code = 'pune_2'
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC);

$wrongCounterP2AtP1 = ((int)$counterUserPune1['counter_id'] !== (int)$p2Attendee['assigned_cid']);
assertTest("COE Kit Terminal: Pune-1 rejects Pune-2 visitor with wrong counter", $wrongCounterP2AtP1, "Target: {$p2Attendee['assigned_counter_name']}");

// Simulating logged in as Super Admin
$superAdminUser = [
    'role' => 'super_admin',
    'counter_id' => null
];
$superAdminCanServeAll = ($superAdminUser['role'] === 'super_admin');
assertTest("COE Kit Terminal: Super Admin bypasses counter restrictions", $superAdminCanServeAll, "Full access allowed");

// 9. Counter reassignment simulation & audit log check
$testVis = $pdo->query("SELECT id, user_id, name, counter_id FROM allowed_visitors LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$origCid = (int)$testVis['counter_id'];
// Pick a different counter
$altCounter = $pdo->query("SELECT id, name FROM counters WHERE id != $origCid LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$newCid = (int)$altCounter['id'];

// Test reassignment update
$pdo->beginTransaction();
$pdo->prepare("UPDATE allowed_visitors SET counter_id = ? WHERE id = ?")->execute([$newCid, $testVis['id']]);
$pdo->prepare("UPDATE gift_distribution SET counter_id = ? WHERE user_id = ?")->execute([$newCid, $testVis['user_id']]);
$pdo->prepare("
    INSERT INTO counter_reassignment_log (visitor_id, visitor_name, user_id, old_counter_id, new_counter_id, changed_by, reason)
    VALUES (?, ?, ?, ?, ?, 'test_runner', 'automated verification test')
")->execute([$testVis['id'], $testVis['name'], $testVis['user_id'], $origCid, $newCid]);

$checkAv = (int)$pdo->query("SELECT counter_id FROM allowed_visitors WHERE id = {$testVis['id']}")->fetchColumn();
$checkGd = (int)$pdo->query("SELECT counter_id FROM gift_distribution WHERE user_id = " . $pdo->quote($testVis['user_id']))->fetchColumn();
$logEntry = $pdo->query("SELECT COUNT(*) FROM counter_reassignment_log WHERE visitor_id = {$testVis['id']} AND changed_by = 'test_runner'")->fetchColumn();

assertTest("Reassignment updates allowed_visitors.counter_id", $checkAv === $newCid, "Set to $newCid");
assertTest("Reassignment updates gift_distribution.counter_id", $checkGd === $newCid, "Set to $newCid");
assertTest("Reassignment writes to counter_reassignment_log", $logEntry > 0, "Audit log verified");

// Rollback test so original data is not modified
$pdo->rollBack();
$revertedAv = (int)$pdo->query("SELECT counter_id FROM allowed_visitors WHERE id = {$testVis['id']}")->fetchColumn();
assertTest("Reassignment test rollback clean", $revertedAv === $origCid, "Restored to original counter $origCid");

echo "\n==================================\n";
echo "SUMMARY: $testsPassed PASSED, $testsFailed FAILED\n";
if ($testsFailed === 0) {
    echo "ALL CHECKS PERFECTLY SATISFIED!\n";
}
