<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$stmt = $pdo->query("SELECT v.id, v.name, v.mobile, v.user_id, v.region, v.counter_id, c.name as cname, c.name_range 
                     FROM allowed_visitors v 
                     LEFT JOIN counters c ON c.id = v.counter_id 
                     WHERE v.name LIKE '%Aarti Bhujbal%'");
print_r($stmt->fetch(PDO::FETCH_ASSOC));
