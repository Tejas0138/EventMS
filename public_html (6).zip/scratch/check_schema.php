<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== allowed_visitors cols ===\n";
foreach ($pdo->query('DESCRIBE allowed_visitors')->fetchAll(PDO::FETCH_ASSOC) as $c) {
    echo "  {$c['Field']} ({$c['Type']})\n";
}

echo "=== gift_distribution cols ===\n";
foreach ($pdo->query('DESCRIBE gift_distribution')->fetchAll(PDO::FETCH_ASSOC) as $c) {
    echo "  {$c['Field']} ({$c['Type']})\n";
}

echo "=== tables list ===\n";
foreach ($pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $t) {
    echo "  $t\n";
}
