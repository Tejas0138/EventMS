<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$nullVisitors = $pdo->query("SELECT id, name, user_id, region, counter_id FROM allowed_visitors WHERE counter_id IS NULL OR counter_id = 0")->fetchAll(PDO::FETCH_ASSOC);
echo "Visitors with counter_id NULL or 0: " . count($nullVisitors) . "\n";
foreach ($nullVisitors as $nv) {
    echo "ID: {$nv['id']} | Name: {$nv['name']} | User ID: {$nv['user_id']} | Region: {$nv['region']}\n";
}

$puneCounters = $pdo->query("
    SELECT c.id, c.name, c.code, COUNT(v.id) as cnt 
    FROM counters c 
    LEFT JOIN allowed_visitors v ON v.counter_id = c.id 
    WHERE c.code LIKE 'pune_%' 
    GROUP BY c.id, c.name, c.code 
    ORDER BY c.id ASC
")->fetchAll(PDO::FETCH_ASSOC);

echo "\nPune Counters breakdown:\n";
foreach ($puneCounters as $pc) {
    echo "{$pc['name']} (ID: {$pc['id']}, Code: {$pc['code']}): {$pc['cnt']} attendees\n";
}
