<?php
require_once __DIR__ . '/../config/db.php';
$baseUrl = 'http://localhost:8080/EventMS';
$cookieFile = __DIR__ . '/cookie_pune1.txt';

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => "$baseUrl/admin.php?tab=gift",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEFILE     => $cookieFile,
    CURLOPT_FOLLOWLOCATION => true
]);
$page = curl_exec($ch);
curl_close($ch);

$hasBtn = (strpos($page, 'btnGateTabExport') !== false || strpos($page, 'gate_tab_csv') !== false);
echo "Counter user sees btnGateTabExport: " . ($hasBtn ? "YES (FAIL)" : "NO (PASS)") . "\n";
