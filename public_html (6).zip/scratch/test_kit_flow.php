<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "============================================================\n";
echo "EVENTMS - COE KIT ONLY AFTER GATE ENTRY VERIFICATION\n";
echo "============================================================\n\n";

$passCount = 0;
$failCount = 0;

function assertTest(bool $condition, string $title, string $details = '') {
    global $passCount, $failCount;
    if ($condition) {
        $passCount++;
        echo "[PASS] " . $title . ($details ? " - {$details}" : "") . "\n";
    } else {
        $failCount++;
        echo "[FAIL] " . $title . ($details ? " - {$details}" : "") . "\n";
    }
}

// -------------------------------------------------------------
// SNAPSHOT INITIAL STATE TO RESTORE AT THE END
// -------------------------------------------------------------
$snapshotVisitors = $pdo->query("SELECT id, user_id, is_day1_checked_in, day1_checked_in_at, is_day2_checked_in, day2_checked_in_at, is_checked_in, checked_in_at FROM allowed_visitors")->fetchAll(PDO::FETCH_ASSOC);
$snapshotGifts = $pdo->query("SELECT id, user_id, is_gift_collected, gift_collected_at, handed_over_by, counter_region, counter_id FROM gift_distribution")->fetchAll(PDO::FETCH_ASSOC);

try {
    // =========================================================
    // TEST 1: VISITOR WITH NO GATE ENTRY
    // =========================================================
    echo "--- TEST 1: Visitor with no gate entry ---\n";

    // Find a visitor with no gate entry and no kit
    $v1 = $pdo->query("
        SELECT g.*, a.is_day1_checked_in, a.is_day2_checked_in
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.is_gift_collected = 0 AND a.is_day1_checked_in = 0 AND a.is_day2_checked_in = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);

    assertTest(!empty($v1), "Found visitor with no gate entry: {$v1['name']} ({$v1['user_id']})");

    // 1A. Table Row rendering: Give Kit replaced by disabled grey pill "Not Entered"
    require_once __DIR__ . '/../admin.php'; // Defines renderGiftTableRows if not defined
    $rowHtml = renderGiftTableRows([$v1], 'pending', '', '', 1, 0, 0, false);
    assertTest(strpos($rowHtml, 'btn-not-entered') !== false, "Row HTML contains .btn-not-entered");
    assertTest(strpos($rowHtml, 'disabled') !== false, "Row HTML has disabled attribute on Not Entered pill");
    assertTest(strpos($rowHtml, 'pill-not-entered') !== false, "Row HTML Kit Status shows .pill-not-entered");
    assertTest(strpos($rowHtml, 'btn-mark-given') === false, "Row HTML does NOT contain active Give Kit button");

    // 1B. COE Kit Terminal refuses: status 'not_entered' and warning message
    // Simulate terminal verify by querying like gift.php
    $stmtT = $pdo->prepare("
        SELECT g.*, c.name AS assigned_counter_name, c.name_range AS assigned_counter_range,
               (CASE WHEN (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS is_gate_entered
        FROM `gift_distribution` g
        LEFT JOIN `counters` c ON c.id = g.counter_id
        LEFT JOIN `allowed_visitors` a ON a.user_id = g.user_id
        WHERE g.id = :id
    ");
    $stmtT->execute([':id' => $v1['id']]);
    $visTerminal = $stmtT->fetch(PDO::FETCH_ASSOC);

    $expectedMsg = "{$v1['name']}, your gate entry is not done yet. Please complete entry at the gate first, then come back for your COE Kit.";
    $isTerminalRefused = ((int)$visTerminal['is_gate_entered'] !== 1);
    assertTest($isTerminalRefused, "Terminal identifies visitor as not entered at gate");

    // 1C. Direct request to Give Kit endpoint refused by server (as Super Admin)
    $_SESSION['user_role'] = 'super_admin';
    $_SESSION['admin_username'] = 'superadmin';
    $chkStmt = $pdo->prepare("
        SELECT g.id, g.counter_id, g.region, g.is_gift_collected,
               (CASE WHEN (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS is_gate_entered
        FROM `gift_distribution` g
        LEFT JOIN `allowed_visitors` a ON a.user_id = g.user_id
        WHERE g.id = :id
    ");
    $chkStmt->execute([':id' => $v1['id']]);
    $visChk = $chkStmt->fetch(PDO::FETCH_ASSOC);

    $serverWouldRefuse = ((int)($visChk['is_gate_entered'] ?? 0) !== 1);
    assertTest($serverWouldRefuse, "Server-side check in mark_given refuses handover for unentered visitor (Super Admin)");

    // Ensure DB is not changed
    $giftState = $pdo->query("SELECT is_gift_collected FROM gift_distribution WHERE id = {$v1['id']}")->fetchColumn();
    assertTest((int)$giftState === 0, "Database is_gift_collected remains 0");


    // =========================================================
    // TEST 2: CHECK-IN & REGION-WISE COUNTER ISOLATION
    // =========================================================
    echo "\n--- TEST 2: Check-in and Region-wise counter appearance ---\n";

    // 2A. Lucknow Visitor (assigned to Dehradun / Lucknow Counter, id = 2)
    $lucknowVis = $pdo->query("
        SELECT g.*, a.id as a_id
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Lucknow' AND g.counter_id = 2 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    assertTest(!empty($lucknowVis), "Selected Lucknow visitor: {$lucknowVis['name']} ({$lucknowVis['user_id']})");

    // Check in at Day 1 gate
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$lucknowVis['a_id']}");

    // Query under counter_dehradun_lucknow (counter_id = 2)
    $stmtC2 = $pdo->prepare("
        SELECT g.*, (CASE WHEN (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS is_gate_entered,
               GREATEST(COALESCE(a.day1_checked_in_at, '1970-01-01 00:00:00'), COALESCE(a.day2_checked_in_at, '1970-01-01 00:00:00')) AS gate_entered_at
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 2 AND g.is_gift_collected = 0 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1)
        ORDER BY gate_entered_at DESC, g.name ASC
    ");
    $stmtC2->execute();
    $c2List = $stmtC2->fetchAll(PDO::FETCH_ASSOC);
    assertTest(!empty($c2List) && $c2List[0]['id'] == $lucknowVis['id'], "Lucknow visitor appears at top of 'Entered' tab for Dehradun / Lucknow Counter");

    // Query under counter_noida (counter_id = 10)
    $stmtNoida = $pdo->prepare("
        SELECT g.id
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 10 AND g.is_gift_collected = 0 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1)
    ");
    $stmtNoida->execute();
    $noidaIds = $stmtNoida->fetchAll(PDO::FETCH_COLUMN);
    assertTest(!in_array($lucknowVis['id'], $noidaIds), "Lucknow visitor does NOT appear in Noida Counter");

    // 2B. Repeat with Raipur Visitor (counter_id = 1)
    $raipurVis = $pdo->query("
        SELECT g.*, a.id as a_id
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Raipur' AND g.counter_id = 1 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$raipurVis['a_id']}");
    $raipurInCounter1 = $pdo->query("
        SELECT g.id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 1 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) AND g.id = {$raipurVis['id']}
    ")->fetchColumn();
    $raipurInNoida = $pdo->query("
        SELECT g.id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 10 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) AND g.id = {$raipurVis['id']}
    ")->fetchColumn();
    assertTest(!empty($raipurInCounter1) && empty($raipurInNoida), "Raipur visitor appears in Raipur/Chandigarh Counter, not in Noida Counter");

    // 2C. Repeat with Pune Visitor (e.g. Pune Counter 1, counter_id = 6)
    $puneVis = $pdo->query("
        SELECT g.*, a.id as a_id
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Pune' AND g.counter_id = 6 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$puneVis['a_id']}");
    $puneInPune1 = $pdo->query("
        SELECT g.id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 6 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) AND g.id = {$puneVis['id']}
    ")->fetchColumn();
    $puneInPune2 = $pdo->query("
        SELECT g.id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 7 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) AND g.id = {$puneVis['id']}
    ")->fetchColumn();
    assertTest(!empty($puneInPune1) && empty($puneInPune2), "Pune visitor appears in assigned Pune Counter 1, not in Pune Counter 2");

    // 2D. Repeat with Noida Visitor (counter_id = 10)
    $noidaVis = $pdo->query("
        SELECT g.*, a.id as a_id
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Noida' AND g.counter_id = 10 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$noidaVis['a_id']}");
    $noidaInNoida = $pdo->query("
        SELECT g.id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 10 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) AND g.id = {$noidaVis['id']}
    ")->fetchColumn();
    assertTest(!empty($noidaInNoida), "Noida visitor appears in Noida Counter");

    // 2E. Day 2 only check-in
    $d2Vis = $pdo->query("
        SELECT g.*, a.id as a_id
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.is_gift_collected = 0 AND a.is_day1_checked_in = 0 AND a.is_day2_checked_in = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 0, is_day2_checked_in = 1, day2_checked_in_at = UTC_TIMESTAMP() WHERE id = {$d2Vis['a_id']}");
    $isD2Entered = $pdo->query("
        SELECT (CASE WHEN (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END)
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.id = {$d2Vis['id']}
    ")->fetchColumn();
    assertTest((int)$isD2Entered === 1, "Visitor with Day 2 check-in ONLY is recognized as Entered");


    // =========================================================
    // TEST 3: GIVE KIT & RESET KIT METRICS AND INVARIANTS
    // =========================================================
    echo "\n--- TEST 3: Give Kit and Reset Kit metrics & mathematical invariants ---\n";

    // Query initial counts for Dehradun/Lucknow Counter
    $cntBefore = $pdo->query("
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN g.is_gift_collected = 1 THEN 1 ELSE 0 END) AS given,
            SUM(CASE WHEN g.is_gift_collected = 0 THEN 1 ELSE 0 END) AS pend,
            SUM(CASE WHEN g.is_gift_collected = 0 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS entered,
            SUM(CASE WHEN g.is_gift_collected = 0 AND (a.is_day1_checked_in = 0 AND a.is_day2_checked_in = 0) THEN 1 ELSE 0 END) AS not_entered
        FROM gift_distribution g
        LEFT JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 2
    ")->fetch(PDO::FETCH_ASSOC);

    assertTest((int)$cntBefore['pend'] === ((int)$cntBefore['entered'] + (int)$cntBefore['not_entered']), "Invariant holds: Pending = Entered + Not Entered ({$cntBefore['pend']} = {$cntBefore['entered']} + {$cntBefore['not_entered']})");
    assertTest((int)$cntBefore['total'] === ((int)$cntBefore['given'] + (int)$cntBefore['pend']), "Invariant holds: All = Kit Collected + Pending ({$cntBefore['total']} = {$cntBefore['given']} + {$cntBefore['pend']})");

    // Give kit to lucknowVis
    $pdo->exec("UPDATE gift_distribution SET is_gift_collected = 1, gift_collected_at = UTC_TIMESTAMP(), handed_over_by = 'admin', counter_region = 'Dehradun / Lucknow Counter' WHERE id = {$lucknowVis['id']}");

    $cntAfterGive = $pdo->query("
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN g.is_gift_collected = 1 THEN 1 ELSE 0 END) AS given,
            SUM(CASE WHEN g.is_gift_collected = 0 THEN 1 ELSE 0 END) AS pend,
            SUM(CASE WHEN g.is_gift_collected = 0 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS entered,
            SUM(CASE WHEN g.is_gift_collected = 0 AND (a.is_day1_checked_in = 0 AND a.is_day2_checked_in = 0) THEN 1 ELSE 0 END) AS not_entered
        FROM gift_distribution g
        LEFT JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 2
    ")->fetch(PDO::FETCH_ASSOC);

    assertTest((int)$cntAfterGive['given'] === ((int)$cntBefore['given'] + 1), "Kits Collected increased by 1 ({$cntBefore['given']} -> {$cntAfterGive['given']})");
    assertTest((int)$cntAfterGive['pend'] === ((int)$cntBefore['pend'] - 1), "Pending Kits decreased by 1 ({$cntBefore['pend']} -> {$cntAfterGive['pend']})");
    assertTest((int)$cntAfterGive['entered'] === ((int)$cntBefore['entered'] - 1), "Entered tab count decreased by 1 ({$cntBefore['entered']} -> {$cntAfterGive['entered']})");
    assertTest((int)$cntAfterGive['pend'] === ((int)$cntAfterGive['entered'] + (int)$cntAfterGive['not_entered']), "Invariant holds after give: Pending = Entered + Not Entered");
    assertTest((int)$cntAfterGive['total'] === ((int)$cntAfterGive['given'] + (int)$cntAfterGive['pend']), "Invariant holds after give: All = Kit Collected + Pending");

    // Reset kit back
    $pdo->exec("UPDATE gift_distribution SET is_gift_collected = 0, gift_collected_at = NULL, handed_over_by = NULL WHERE id = {$lucknowVis['id']}");
    $cntAfterReset = $pdo->query("
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN g.is_gift_collected = 1 THEN 1 ELSE 0 END) AS given,
            SUM(CASE WHEN g.is_gift_collected = 0 THEN 1 ELSE 0 END) AS pend,
            SUM(CASE WHEN g.is_gift_collected = 0 AND (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS entered,
            SUM(CASE WHEN g.is_gift_collected = 0 AND (a.is_day1_checked_in = 0 AND a.is_day2_checked_in = 0) THEN 1 ELSE 0 END) AS not_entered
        FROM gift_distribution g
        LEFT JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 2
    ")->fetch(PDO::FETCH_ASSOC);

    assertTest((int)$cntAfterReset['given'] === (int)$cntBefore['given'], "After reset: Kits Collected restored");
    assertTest((int)$cntAfterReset['pend'] === (int)$cntBefore['pend'], "After reset: Pending Kits restored");


    // =========================================================
    // TEST 4: TAMPERED KIT REQUEST FOR VISITOR OF ANOTHER COUNTER
    // =========================================================
    echo "\n--- TEST 4: Tampered request for visitor of another counter ---\n";

    // Simulate counter staff logged in as counter_noida (counter_id = 10)
    $isCounter = true;
    $counterId = 10;
    $counterAllowedRegions = ['Noida'];
    $counterRegion = 'Noida';

    // Attempt to give kit to lucknowVis (counter_id = 2)
    $targetVisId = $lucknowVis['id'];
    $chkStmt = $pdo->prepare("
        SELECT g.id, g.counter_id, g.region, g.is_gift_collected,
               (CASE WHEN (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS is_gate_entered
        FROM `gift_distribution` g
        LEFT JOIN `allowed_visitors` a ON a.user_id = g.user_id
        WHERE g.id = :id
    ");
    $chkStmt->execute([':id' => $targetVisId]);
    $visRow = $chkStmt->fetch(PDO::FETCH_ASSOC);

    $visCounterId = (int)($visRow['counter_id'] ?? 0);
    $isRegionAllowed = ($visCounterId === $counterId);

    assertTest(!$isRegionAllowed, "Counter isolation: Noida counter staff blocked from giving kit to Lucknow visitor (403 Permission Denied)");


    // =========================================================
    // TEST 5: ALREADY COLLECTED KITS UNCHANGED
    // =========================================================
    echo "\n--- TEST 5: Already collected kits unchanged ---\n";
    $alreadyCollectedCount = $pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE is_gift_collected = 1")->fetchColumn();
    echo "Currently collected kits in DB: {$alreadyCollectedCount}\n";
    assertTest($alreadyCollectedCount >= 0, "Collected kits query succeeds");

} finally {
    // =========================================================
    // TEST 6: RESTORE DATABASE TO ORIGINAL STATE
    // =========================================================
    echo "\n--- TEST 6: Clean up and restore snapshot ---\n";
    $restoreVisitors = $pdo->prepare("
        UPDATE allowed_visitors 
        SET is_day1_checked_in = :d1, day1_checked_in_at = :d1_at,
            is_day2_checked_in = :d2, day2_checked_in_at = :d2_at,
            is_checked_in = :ci, checked_in_at = :ci_at
        WHERE id = :id
    ");
    foreach ($snapshotVisitors as $sv) {
        $restoreVisitors->execute([
            ':id'    => $sv['id'],
            ':d1'    => $sv['is_day1_checked_in'],
            ':d1_at' => $sv['day1_checked_in_at'],
            ':d2'    => $sv['is_day2_checked_in'],
            ':d2_at' => $sv['day2_checked_in_at'],
            ':ci'    => $sv['is_checked_in'],
            ':ci_at' => $sv['checked_in_at'],
        ]);
    }

    $restoreGifts = $pdo->prepare("
        UPDATE gift_distribution
        SET is_gift_collected = :coll, gift_collected_at = :coll_at,
            handed_over_by = :who, counter_region = :creg, counter_id = :cid
        WHERE id = :id
    ");
    foreach ($snapshotGifts as $sg) {
        $restoreGifts->execute([
            ':id'      => $sg['id'],
            ':coll'    => $sg['is_gift_collected'],
            ':coll_at' => $sg['gift_collected_at'],
            ':who'     => $sg['handed_over_by'],
            ':creg'    => $sg['counter_region'],
            ':cid'     => $sg['counter_id'],
        ]);
    }

    echo "All test check-ins and kits successfully restored to exact original snapshot.\n";
}

echo "\n============================================================\n";
echo "SUMMARY: {$passCount} PASSED, {$failCount} FAILED\n";
echo "============================================================\n";
