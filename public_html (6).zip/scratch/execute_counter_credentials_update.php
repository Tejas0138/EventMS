<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$counterUpdates = [
    1 => ['name' => 'Raipur / Chandigarh Counter', 'username' => 'raipur', 'password' => 'raipur@123'],
    2 => ['name' => 'Dehradun / Lucknow Counter', 'username' => 'dehradun', 'password' => 'dehradun@123'],
    3 => ['name' => 'Gurugram / Guwahati Counter', 'username' => 'gurugram', 'password' => 'gurugram@123'],
    4 => ['name' => 'Chennai / Vijayawada Counter', 'username' => 'chennai', 'password' => 'chennai@123'],
    5 => ['name' => 'Panchkula / Prayagraj / Hyderabad Counter', 'username' => 'panchkula', 'password' => 'panchkula@123'],
    6 => ['name' => 'Pune Counter 1', 'username' => 'pune1', 'password' => 'pune1@123'],
    7 => ['name' => 'Pune Counter 2', 'username' => 'pune2', 'password' => 'pune2@123'],
    8 => ['name' => 'Pune Counter 3', 'username' => 'pune3', 'password' => 'pune3@123'],
    9 => ['name' => 'Pune Counter 4', 'username' => 'pune4', 'password' => 'pune4@123'],
    10 => ['name' => 'Noida Counter', 'username' => 'noida', 'password' => 'noida@123'],
    11 => ['name' => 'Bengaluru Counter', 'username' => 'bengaluru', 'password' => 'bengaluru@123'],
    12 => ['name' => 'Bhopal Counter', 'username' => 'bhopal', 'password' => 'bhopal@123'],
    13 => ['name' => 'Bhubaneswar Counter', 'username' => 'bhubaneswar', 'password' => 'bhubaneswar@123'],
    14 => ['name' => 'Ajmer Counter', 'username' => 'ajmer', 'password' => 'ajmer@123'],
    15 => ['name' => 'Ahmedabad Counter', 'username' => 'ahmedabad', 'password' => 'ahmedabad@123'],
    16 => ['name' => 'Patna Counter', 'username' => 'patna', 'password' => 'patna@123'],
    17 => ['name' => 'Trivandrum Counter', 'username' => 'trivandrum', 'password' => 'trivandrum@123'],
    18 => ['name' => 'Delhi West Counter', 'username' => 'delhiwest', 'password' => 'delhiwest@123'],
    19 => ['name' => 'Delhi East Counter', 'username' => 'delhieast', 'password' => 'delhieast@123'],
    20 => ['name' => 'Ranchi Counter', 'username' => 'ranchi', 'password' => 'ranchi@123'],
];

$pdo->beginTransaction();

try {
    $cStmt = $pdo->prepare("
        UPDATE counters 
        SET username = :u, password_hash = :p, is_active = 1 
        WHERE id = :id AND name = :name
    ");

    $aStmt = $pdo->prepare("
        UPDATE admins 
        SET username = :u, password = :p, status = 'active', failed_attempts = 0, locked_until = NULL 
        WHERE counter_id = :id
    ");

    $updatedCounters = 0;
    $updatedAdmins = 0;

    foreach ($counterUpdates as $id => $info) {
        $hash = password_hash($info['password'], PASSWORD_DEFAULT);

        // Update counters
        $cStmt->execute([
            ':u'    => $info['username'],
            ':p'    => $hash,
            ':id'   => $id,
            ':name' => $info['name']
        ]);
        $updatedCounters += $cStmt->rowCount();

        // Update admins
        $aStmt->execute([
            ':u'  => $info['username'],
            ':p'  => $hash,
            ':id' => $id
        ]);
        $updatedAdmins += $aStmt->rowCount();
    }

    echo "Counters updated: $updatedCounters\n";
    echo "Admins updated: $updatedAdmins\n";

    // Help Desk (ID 21) handling: disable so it cannot log in and is hidden from Counters page
    $pdo->prepare("UPDATE counters SET is_active = 0 WHERE id = 21")->execute();
    $pdo->prepare("
        UPDATE admins 
        SET status = 'disabled', failed_attempts = 0, locked_until = NULL 
        WHERE counter_id = 21 OR username = 'counter_helpdesk'
    ")->execute();

    // Confirm super admin is untouched
    $adminRow = $pdo->query("SELECT id, username, role, status FROM admins WHERE username = 'admin'")->fetch(PDO::FETCH_ASSOC);
    echo "Super Admin check: ID {$adminRow['id']} | User: '{$adminRow['username']}' | Role: '{$adminRow['role']}' | Status: '{$adminRow['status']}'\n";

    $pdo->commit();
    echo "Transaction committed successfully!\n";
} catch (\Throwable $e) {
    $pdo->rollBack();
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}

// Generate new counter_credentials.csv
$csvPath = __DIR__ . '/../counter_credentials.csv';
$csvFile = fopen($csvPath, 'w');
fputcsv($csvFile, [
    'counter_name',
    'username',
    'password',
    'login_url',
    'regions_covered',
    'number_of_visitors'
]);

// Query the 20 active counters in order
$countersData = $pdo->query("
    SELECT c.id, c.name, c.username,
           (
               SELECT GROUP_CONCAT(NULLIF(TRIM(cr.region), '') ORDER BY cr.region SEPARATOR ', ')
               FROM `counter_regions` cr
               WHERE cr.counter_id = c.id AND TRIM(cr.region) != ''
           ) AS regions_covered,
           COALESCE(g_agg.total_visitors, 0) AS total_visitors
    FROM `counters` c
    LEFT JOIN (
        SELECT counter_id, COUNT(*) AS total_visitors
        FROM `gift_distribution`
        WHERE counter_id IS NOT NULL AND counter_id > 0
        GROUP BY counter_id
    ) g_agg ON (g_agg.counter_id = c.id)
    WHERE c.is_active = 1 AND c.code != 'helpdesk'
    ORDER BY c.id ASC
")->fetchAll(PDO::FETCH_ASSOC);

$totalCsvVisitors = 0;
foreach ($countersData as $c) {
    $id = (int)$c['id'];
    $plainPass = $counterUpdates[$id]['password'] ?? '';
    fputcsv($csvFile, [
        $c['name'],
        $c['username'],
        $plainPass,
        'http://localhost:8080/EventMS/login.php',
        $c['regions_covered'] ?? '',
        $c['total_visitors']
    ]);
    $totalCsvVisitors += (int)$c['total_visitors'];
}

fclose($csvFile);
echo "counter_credentials.csv written with " . count($countersData) . " counters, total visitors: $totalCsvVisitors\n";
