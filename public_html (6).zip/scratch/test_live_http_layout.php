<?php
/**
 * Test Live HTTP response from admin.php for both tab=gift and tab=gate.
 */

declare(strict_types=1);

$baseUrl = 'http://localhost:8080/EventMS';
$cookieFile = sys_get_temp_dir() . '/eventms_admin_cookie.txt';
if (file_exists($cookieFile)) {
    unlink($cookieFile);
}

echo "========================================================\n";
echo "       HTTP LIVE LAYOUT AND HTML VERIFICATION          \n";
echo "========================================================\n\n";

$testsPassed = 0;
$totalTests = 0;

function assertCheck(bool $condition, string $message): void {
    global $testsPassed, $totalTests;
    $totalTests++;
    if ($condition) {
        $testsPassed++;
        echo " [PASS] $message\n";
    } else {
        echo " [FAIL] $message\n";
    }
}

// Step 1: Login as Super Admin
$ch = curl_init($baseUrl . '/login.php');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_FOLLOWLOCATION => true
]);
$loginPage = curl_exec($ch);
curl_close($ch);

preg_match('/name="csrf_token"\s+value="([^"]+)"/', (string)$loginPage, $m);
$csrfToken = $m[1] ?? '';

$ch = curl_init($baseUrl . '/login.php');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query([
        'username' => 'admin',
        'password' => 'admin123',
        'csrf_token' => $csrfToken
    ]),
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_FOLLOWLOCATION => true
]);
$loginRes = curl_exec($ch);
$loginHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

assertCheck($loginHttpCode === 200, "Super admin logged in successfully (HTTP $loginHttpCode)");

// Step 2: Fetch tab=gift
$ch = curl_init($baseUrl . '/admin.php?tab=gift');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_FOLLOWLOCATION => true
]);
$giftHtml = curl_exec($ch);
$giftHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

assertCheck($giftHttpCode === 200, "tab=gift loaded successfully (HTTP $giftHttpCode)");

// Verify elements in tab=gift
assertCheck(strpos($giftHtml, '<table class="crisp-table table-gift">') !== false,
    'table-gift markup is present');
assertCheck(strpos($giftHtml, 'class="region-counter-stack"') !== false,
    'Region & Counter cell uses region-counter-stack');
assertCheck(strpos($giftHtml, 'class="counter-name-wrap"') !== false,
    'Counter name is wrapped in counter-name-wrap');
assertCheck(strpos($giftHtml, 'class="counter-name-text"') !== false,
    'Counter name text is wrapped in counter-name-text');
assertCheck(strpos($giftHtml, 'class="btn-move-counter action-btn"') !== false,
    'Move button uses class btn-move-counter action-btn');
assertCheck(strpos($giftHtml, 'border-radius:6px;padding:6px 10px') === false,
    'Legacy inline styles on Move button are completely removed');
assertCheck(strpos($giftHtml, 'class="btn-mark-given action-btn"') !== false,
    'Give Kit button uses btn-mark-given action-btn');
assertCheck(strpos($giftHtml, 'title="Reassign to another counter"') !== false,
    'Move button has native title attribute');
assertCheck(strpos($giftHtml, 'title="Mark COE Kit as given to attendee"') !== false,
    'Give Kit button has native title attribute');

// Check if combined counter has <wbr>
// Search for / <wbr> in the gift page
assertCheck(strpos($giftHtml, '/ <wbr>') !== false,
    'Combined counters have <wbr> inserted after slashes');

// Step 3: Fetch tab=gate
$ch = curl_init($baseUrl . '/admin.php?tab=gate');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_FOLLOWLOCATION => true
]);
$gateHtml = curl_exec($ch);
$gateHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

assertCheck($gateHttpCode === 200, "tab=gate loaded successfully (HTTP $gateHttpCode)");
assertCheck(strpos($gateHtml, '<table class="crisp-table table-gate">') !== false,
    'table-gate markup is present');
assertCheck(strpos($gateHtml, 'title="Check in Day 1"') !== false,
    'Day 1 button has native title attribute');
assertCheck(strpos($gateHtml, 'title="Check in Day 2"') !== false,
    'Day 2 button has native title attribute');

// Step 4: Verify CSS directly in admin.php
$adminContent = file_get_contents(__DIR__ . '/../admin.php');
assertCheck(strpos($adminContent, '.crisp-table.table-gift') !== false && strpos($adminContent, 'min-width: 1514px') !== false,
    'CSS has table-gift min-width: 1514px');
assertCheck(strpos($adminContent, '.crisp-table.table-gate') !== false && strpos($adminContent, 'min-width: 1464px') !== false,
    'CSS has table-gate min-width: 1464px');
assertCheck(strpos($adminContent, 'padding: 14px 14px !important;') !== false,
    'CSS enforces 14px 14px cell padding');
assertCheck(strpos($adminContent, 'height: 76px !important;') !== false,
    'CSS enforces uniform row height 76px');
assertCheck(strpos($adminContent, 'width: 270px !important;') !== false,
    'CSS sets col-region width: 270px on desktop');
assertCheck(strpos($adminContent, 'width: 240px !important;') !== false,
    'CSS sets col-actions width: 240px on desktop');
assertCheck(strpos($adminContent, 'width: 108px !important;') !== false,
    'CSS sets action button width: 108px on desktop');
assertCheck(strpos($adminContent, 'width: 110px !important;') !== false,
    'CSS sets col-gift-status .status-pill width: 110px on desktop');
assertCheck(strpos($adminContent, '.action-btn-group .btn-move-counter') !== false,
    'CSS includes btn-move-counter in mobile action button grid');

// Cleanup
if (file_exists($cookieFile)) {
    unlink($cookieFile);
}

echo "\n--------------------------------------------------------\n";
echo "SUMMARY: $testsPassed / $totalTests tests passed.\n";
echo "========================================================\n";
exit($testsPassed === $totalTests ? 0 : 1);
