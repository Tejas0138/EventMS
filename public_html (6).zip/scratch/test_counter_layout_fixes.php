<?php
/**
 * Verification script for COE Kit Distribution layout, header, toolbar, table, and actions.
 */

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$baseUrl = 'http://localhost:8080/EventMS';

function makeCurl($cookieFile) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    return $ch;
}

function loginWithCsrf($ch, $baseUrl, $username, $password) {
    // 1. GET login.php to grab CSRF token
    curl_setopt($ch, CURLOPT_URL, "$baseUrl/login.php");
    curl_setopt($ch, CURLOPT_POST, false);
    $loginPageHtml = curl_exec($ch);

    preg_match('/name="csrf_token"\s+value="([^"]+)"/', $loginPageHtml, $m);
    $csrf = $m[1] ?? '';

    // 2. POST login credentials
    curl_setopt($ch, CURLOPT_URL, "$baseUrl/login.php");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'csrf_token' => $csrf,
        'username'   => $username,
        'password'   => $password,
    ]));
    $res = curl_exec($ch);
    return $res;
}

function getPage($ch, $url) {
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, false);
    return curl_exec($ch);
}

$allPass = true;

function assertCondition($name, $condition, $details = '') {
    global $allPass;
    if ($condition) {
        echo "  [PASS] $name\n";
    } else {
        echo "  [FAIL] $name - $details\n";
        $allPass = false;
    }
}

echo "========================================================\n";
echo "TEST 1: counter_pune_1 (Single Region / Range Counter)\n";
echo "========================================================\n";

$cookiePune1 = tempnam(sys_get_temp_dir(), 'pune1_');
$chPune1 = makeCurl($cookiePune1);
loginWithCsrf($chPune1, $baseUrl, 'counter_pune_1', 'Pune1@2026');
$puneHtml = getPage($chPune1, "$baseUrl/admin.php?tab=gift");

// 1. Title & Header
assertCondition(
    "Title is 'COE Kit Distribution'",
    strpos($puneHtml, '📦 COE Kit Distribution') !== false && strpos($puneHtml, '📦 COE Kit Distribution Control') === false,
    "Title mismatch"
);
assertCondition(
    "Counter badge shows 'Pune Counter 1'",
    strpos($puneHtml, 'Pune Counter 1') !== false,
    "Badge not found"
);
assertCondition(
    "Subtitle contains Pune range without repeating counter name",
    strpos($puneHtml, 'Names A to Chetan Sonawane &bull;') !== false && strpos($puneHtml, 'kits distributed') !== false,
    "Subtitle incorrect: " . substr(strip_tags($puneHtml), 0, 300)
);

// 2. Stat Card
assertCondition(
    "Stat card says 'Visitors at this counter'",
    strpos($puneHtml, 'Visitors at this counter') !== false,
    "Stat card label missing"
);
assertCondition(
    "Stat card subtitle says 'Assigned to Pune Counter 1'",
    strpos($puneHtml, 'Assigned to Pune Counter 1') !== false,
    "Stat card subtitle missing"
);

// 3. Toolbar & Pill check
assertCondition(
    "Toolbar placeholder is 'Search name, Register Id, mobile...'",
    strpos($puneHtml, 'placeholder="Search name, Register Id, mobile..."') !== false,
    "Search placeholder mismatch"
);
assertCondition(
    "Locked counter/region pill is NOT rendered in HTML",
    strpos($puneHtml, 'Pune Counter 1 (A to Chetan Sonawane) (') === false && strpos($puneHtml, 'All Regions in Counter') === false,
    "Locked pill found in HTML"
);
assertCondition(
    "Single region/Pune counter has NO region select in toolbar",
    strpos($puneHtml, '<select name="dregion"') === false,
    "Region select unexpectedly present"
);

// 4. Table structure
assertCondition(
    "Table has classes 'table-counter-view table-single-region'",
    strpos($puneHtml, 'crisp-table table-gift table-counter-view table-single-region') !== false,
    "Table classes mismatch"
);
assertCondition(
    "Region column header is 'Region' (not 'Region & Counter')",
    strpos($puneHtml, '<th class="col-region">Region</th>') !== false,
    "Header mismatch"
);

// Extract tbody content
preg_match('/<tbody id="giftTableBody"[^>]*>(.*?)<\/tbody>/s', $puneHtml, $tbm);
$tbodyHtml = $tbm[1] ?? '';

assertCondition(
    "Region cell shows only region chip (no stacked counter name in tbody)",
    strpos($tbodyHtml, '<span class="card-meta-label">Region</span>') !== false && strpos($tbodyHtml, 'counter-name-wrap') === false,
    "Counter stack unexpectedly present in single region row"
);
assertCondition(
    "Actions column has single 'Give Kit' button per pending attendee (no Move button)",
    strpos($tbodyHtml, 'btn-mark-given action-btn') !== false && strpos($tbodyHtml, 'btn-move-counter') === false,
    "Action button mismatch"
);

// 5. Test Give Kit action and Reset Kit action for Pune 1
// Find first attendee in Pune 1
$stmt = $pdo->prepare("SELECT id, name, is_gift_collected FROM gift_distribution WHERE counter_id = (SELECT id FROM counters WHERE username = 'counter_pune_1') LIMIT 1");
$stmt->execute();
$testAttendee = $stmt->fetch(PDO::FETCH_ASSOC);

if ($testAttendee) {
    $attId = $testAttendee['id'];
    $attName = $testAttendee['name'];
    $origStatus = (int)$testAttendee['is_gift_collected'];

    echo "  Testing Give Kit on attendee #$attId ($attName)...\n";
    $giveRes = getPage($chPune1, "$baseUrl/admin.php?tab=gift&action=mark_given&id=$attId");
    assertCondition("mark_given executed without 403", strpos($giveRes, '403') === false && strpos($giveRes, 'Access Denied') === false);
    
    // Check DB
    $checkStmt = $pdo->prepare("SELECT is_gift_collected, handed_over_by FROM gift_distribution WHERE id = ?");
    $checkStmt->execute([$attId]);
    $chk = $checkStmt->fetch(PDO::FETCH_ASSOC);
    assertCondition("Database shows is_gift_collected = 1", (int)$chk['is_gift_collected'] === 1, "DB status: " . $chk['is_gift_collected']);

    // Check HTML shows ONLY Reset Kit button (no Kit Given extra badge)
    $afterGiveHtml = getPage($chPune1, "$baseUrl/admin.php?tab=gift");
    assertCondition(
        "Row shows single 'Reset Kit' button for collected attendee",
        strpos($afterGiveHtml, "action=reset_gift&id=$attId") !== false || strpos($afterGiveHtml, "action=reset_gift&amp;id=$attId") !== false,
        "Reset button not found"
    );
    assertCondition(
        "Kit Given claimed badge is omitted for counter user",
        strpos($afterGiveHtml, 'badge-claimed action-btn') === false,
        "Kit Given badge still present"
    );

    // Reset back
    echo "  Testing Reset Kit on attendee #$attId ($attName)...\n";
    $resetRes = getPage($chPune1, "$baseUrl/admin.php?tab=gift&action=reset_gift&id=$attId");
    assertCondition("reset_gift executed without 403", strpos($resetRes, '403') === false && strpos($resetRes, 'Access Denied') === false);

    $checkStmt->execute([$attId]);
    $chk2 = $checkStmt->fetch(PDO::FETCH_ASSOC);
    assertCondition("Database reverted to is_gift_collected = 0", (int)$chk2['is_gift_collected'] === 0, "DB status: " . $chk2['is_gift_collected']);

    // If original status was collected, restore it
    if ($origStatus === 1) {
        $pdo->prepare("UPDATE gift_distribution SET is_gift_collected = 1 WHERE id = ?")->execute([$attId]);
    }
}

echo "\n========================================================\n";
echo "TEST 2: counter_raipur_chandigarh (Combined Counter)\n";
echo "========================================================\n";

$cookieRc = tempnam(sys_get_temp_dir(), 'rc_');
$chRc = makeCurl($cookieRc);
loginWithCsrf($chRc, $baseUrl, 'counter_raipur_chandigarh', 'Raipur@2026');
$rcHtml = getPage($chRc, "$baseUrl/admin.php?tab=gift");

assertCondition(
    "Title is 'COE Kit Distribution'",
    strpos($rcHtml, '📦 COE Kit Distribution') !== false,
    "Title mismatch"
);
assertCondition(
    "Counter badge shows 'Raipur / Chandigarh Counter'",
    strpos($rcHtml, 'Raipur / Chandigarh Counter') !== false,
    "Badge not found"
);
assertCondition(
    "Subtitle contains covered regions",
    strpos($rcHtml, 'Covering') !== false && strpos($rcHtml, 'Raipur') !== false && strpos($rcHtml, 'Chandigarh') !== false,
    "Subtitle mismatch"
);
assertCondition(
    "Toolbar has Region dropdown with 'All my regions (2)'",
    strpos($rcHtml, 'All my regions (2)') !== false && strpos($rcHtml, 'value="Raipur"') !== false && strpos($rcHtml, 'value="Chandigarh"') !== false,
    "Region dropdown options missing"
);
assertCondition(
    "Table has classes 'table-counter-view table-combined-region'",
    strpos($rcHtml, 'crisp-table table-gift table-counter-view table-combined-region') !== false,
    "Table classes mismatch"
);
assertCondition(
    "Region column header is 'Region & Counter'",
    strpos($rcHtml, '<th class="col-region">Region &amp; Counter</th>') !== false,
    "Header mismatch"
);

preg_match('/<tbody id="giftTableBody"[^>]*>(.*?)<\/tbody>/s', $rcHtml, $rcTbm);
$rcTbodyHtml = $rcTbm[1] ?? '';
assertCondition(
    "Region cell has counter-name-wrap with <wbr>",
    strpos($rcTbodyHtml, 'counter-name-wrap') !== false && strpos($rcTbodyHtml, '<wbr>') !== false,
    "Counter stack or wbr missing in tbody"
);

echo "\n========================================================\n";
echo "TEST 3: counter_noida (Single Region Counter)\n";
echo "========================================================\n";

$cookieNoida = tempnam(sys_get_temp_dir(), 'noida_');
$chNoida = makeCurl($cookieNoida);
loginWithCsrf($chNoida, $baseUrl, 'counter_noida', 'Noida@2026');
$noidaHtml = getPage($chNoida, "$baseUrl/admin.php?tab=gift");

assertCondition(
    "Counter badge shows 'Noida Counter'",
    strpos($noidaHtml, 'Noida Counter') !== false,
    "Badge not found"
);
assertCondition(
    "Single region counter has NO region select in toolbar",
    strpos($noidaHtml, '<select name="dregion"') === false,
    "Region select unexpectedly present"
);
assertCondition(
    "Table has class 'table-single-region'",
    strpos($noidaHtml, 'table-single-region') !== false,
    "table-single-region class missing"
);
assertCondition(
    "Header is 'Region'",
    strpos($noidaHtml, '<th class="col-region">Region</th>') !== false,
    "Header mismatch"
);

echo "\n========================================================\n";
echo "TEST 4: Super Admin View (admin / admin123)\n";
echo "========================================================\n";

$cookieAdmin = tempnam(sys_get_temp_dir(), 'admin_');
$chAdmin = makeCurl($cookieAdmin);
loginWithCsrf($chAdmin, $baseUrl, 'admin', 'admin123');
$adminHtml = getPage($chAdmin, "$baseUrl/admin.php?tab=gift");

assertCondition(
    "Title is 'COE Kit Distribution Control'",
    strpos($adminHtml, '📦 COE Kit Distribution Control') !== false,
    "Title mismatch"
);
assertCondition(
    "Super Admin toolbar has both Counter and Region select dropdowns",
    strpos($adminHtml, 'name="dcounter"') !== false && strpos($adminHtml, 'name="dregion"') !== false,
    "Dropdowns missing in Super Admin toolbar"
);
assertCondition(
    "Super Admin table has both Give Kit and Move action buttons",
    strpos($adminHtml, 'btn-mark-given action-btn') !== false && strpos($adminHtml, 'btn-move-counter action-btn') !== false,
    "Action buttons mismatch"
);

echo "\n========================================================\n";
echo "TEST 5: CSS Rules Verification in admin.php\n";
echo "========================================================\n";

$adminCode = file_get_contents('admin.php');

assertCondition(
    "CSS DOES NOT have sticky col-actions rules",
    strpos($adminCode, '.crisp-table th.col-actions') === false && strpos($adminCode, 'position: sticky !important;\n                right: 0') === false,
    "Sticky col-actions rules still present in CSS"
);
assertCondition(
    "CSS has crisp-table border-collapse: separate and border-spacing: 0",
    strpos($adminCode, 'border-collapse: separate;') !== false && strpos($adminCode, 'border-spacing: 0;') !== false,
    "Border collapse separate missing"
);
assertCondition(
    "CSS has content-card overflow: visible",
    strpos($adminCode, "overflow: visible;") !== false,
    "overflow: visible on content-card missing"
);
assertCondition(
    "CSS defines table min-widths: 1524px (admin), 1304px (single), 1394px (combined)",
    strpos($adminCode, 'min-width: 1524px;') !== false &&
    strpos($adminCode, 'min-width: 1304px !important;') !== false &&
    strpos($adminCode, 'min-width: 1394px !important;') !== false,
    "Table min-widths missing"
);
assertCondition(
    "CSS defines col-actions widths: 250px (admin), 150px (counter-view)",
    strpos($adminCode, 'width: 250px !important;') !== false &&
    strpos($adminCode, 'width: 150px !important;') !== false,
    "col-actions widths missing"
);
assertCondition(
    "CSS defines action buttons as 112px x 36px",
    strpos($adminCode, 'width: 112px !important;') !== false &&
    strpos($adminCode, 'min-width: 112px !important;') !== false &&
    strpos($adminCode, 'height: 36px !important;') !== false,
    "Action button 112px dimensions missing"
);

echo "\n========================================================\n";
if ($allPass) {
    echo ">>> ALL TESTS PASSED SUCCESSFULLY! <<<\n";
    exit(0);
} else {
    echo ">>> SOME TESTS FAILED! <<<\n";
    exit(1);
}
