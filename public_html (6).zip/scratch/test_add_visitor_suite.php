<?php
/**
 * Comprehensive Verification Suite for "Add Visitor" Feature
 * Tests all 9 user scenarios against live EventMS application.
 */

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$baseUrl = 'http://localhost:8080/EventMS';
$cookieFileAdmin = __DIR__ . '/cookie_admin.txt';
$cookieFileCounter = __DIR__ . '/cookie_counter.txt';

if (file_exists($cookieFileAdmin)) unlink($cookieFileAdmin);
if (file_exists($cookieFileCounter)) unlink($cookieFileCounter);

$passCount = 0;
$failCount = 0;

function assertTest(bool $cond, string $title, string $details = '') {
    global $passCount, $failCount;
    if ($cond) {
        $passCount++;
        echo "  [PASS] {$title}\n";
    } else {
        $failCount++;
        echo "  [FAIL] {$title}\n";
        if ($details) echo "         Details: {$details}\n";
    }
}

function httpReq($url, $method = 'GET', $data = [], $cookieFile = null, $headers = []) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    if ($cookieFile) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    }
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    }
    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    $res = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);
    return ['body' => $res, 'status' => $info['http_code'], 'url' => $info['url']];
}

function doLogin($user, $pass, $cookieFile) {
    global $baseUrl;
    if (file_exists($cookieFile)) unlink($cookieFile);
    // 1. GET login page to obtain session cookie & CSRF token
    $ch = curl_init("{$baseUrl}/login.php");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    $html = curl_exec($ch);
    curl_close($ch);

    preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', $html, $matches);
    $csrf = $matches[1] ?? '';

    // 2. POST credentials
    $ch = curl_init("{$baseUrl}/login.php");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'csrf_token' => $csrf,
        'username'   => $user,
        'password'   => $pass
    ]));
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['body' => $res, 'status' => $code];
}

echo "=== STARTING ADD VISITOR TEST SUITE ===\n\n";

// Step 0: Login as Super Admin
echo "Step 0: Authenticating Super Admin...\n";
$loginRes = doLogin('admin', 'admin123', $cookieFileAdmin);

$adminPage = httpReq("{$baseUrl}/admin.php?tab=gate", 'GET', [], $cookieFileAdmin);
assertTest($adminPage['status'] === 200 && strpos($adminPage['body'], 'Add Visitor') !== false, "Super Admin sees 'Add Visitor' button on Gate Entry tab");

// Check CSRF token in admin page
preg_match('/name="csrf_token" value="([a-f0-9]+)"/', $adminPage['body'], $csrfMatch);
$csrfToken = $csrfMatch[1] ?? '';
assertTest(!empty($csrfToken), "CSRF token extracted from admin page: " . substr($csrfToken, 0, 8) . "...");

// Check baseline count
$baselineCount = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors`")->fetchColumn();
echo "Baseline visitor count: {$baselineCount}\n\n";

// =========================================================================
// TEST 1: Trivandrum Visitor with All Fields
// =========================================================================
echo "TEST 1: Adding Trivandrum visitor with all fields...\n";
$t1Post = [
    'action'        => 'add_visitor',
    'tab'           => 'gate',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => 'Test Shibili Trivandrum',
    'user_id'       => 'TEST_TRIV_001',
    'region'        => 'Trivandrum',
    'fincert'       => 'NTC-2026/TRV/0001',
    'mobile'        => '9876543210',
    'email'         => 'shibili.test@example.com',
    'school_name'   => 'St. Thomas School',
    'designation'   => 'PGT Mathematics'
];

$resT1 = httpReq("{$baseUrl}/admin.php", 'POST', $t1Post, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonT1 = json_decode($resT1['body'], true);

assertTest(($jsonT1['status'] ?? '') === 'success', "Trivandrum visitor successfully added via AJAX", $resT1['body']);
assertTest(($jsonT1['counter_name'] ?? '') === 'Trivandrum Counter', "Assigned to Trivandrum Counter (ID: " . ($jsonT1['counter_id'] ?? '') . ")");

$trivCount = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors` WHERE user_id = 'TEST_TRIV_001'")->fetchColumn();
assertTest($trivCount === 1, "Visitor exists in allowed_visitors table");
$trivGiftCount = (int)$pdo->query("SELECT COUNT(*) FROM `gift_distribution` WHERE user_id = 'TEST_TRIV_001'")->fetchColumn();
assertTest($trivGiftCount === 1, "Visitor exists in gift_distribution table");

// Test Day 1 Check-In at Gate Terminal by Mobile
$gateCheckMob = httpReq("{$baseUrl}/index.php", 'POST', [
    'mobile' => '9876543210',
    'day'    => '1'
], null, ['X-Requested-With: XMLHttpRequest']);
$gateMobJson = json_decode($gateCheckMob['body'], true);
assertTest(($gateMobJson['status'] ?? '') === 'success', "Visitor checked in at Day 1 Gate Terminal via mobile number");
assertTest(strpos($gateMobJson['message'] ?? '', 'Welcome') !== false || ($gateMobJson['status'] ?? '') === 'success', "Gate Terminal approved Day 1 entry");

// Test Gate check-in status in DB
$d1DbStatus = (int)$pdo->query("SELECT is_day1_checked_in FROM `allowed_visitors` WHERE user_id = 'TEST_TRIV_001'")->fetchColumn();
assertTest($d1DbStatus === 1, "is_day1_checked_in is 1 in database");

echo "\n";

// =========================================================================
// TEST 2: Pune Visitor Assigned to Pune Counter 3
// =========================================================================
echo "TEST 2: Adding Pune visitor (Pallavi Patil) -> Pune Counter 3...\n";
$t2Post = [
    'action'        => 'add_visitor',
    'tab'           => 'gate',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => 'Dr. Pallavi Patil',
    'user_id'       => 'TEST_PUNE_003',
    'region'        => 'Pune',
    'fincert'       => 'NTC-2026/PUN/0003',
    'mobile'        => '9876543211',
    'email'         => 'pallavi.test@example.com',
    'school_name'   => 'Pune Academy',
    'designation'   => 'Vice Principal'
];

$resT2 = httpReq("{$baseUrl}/admin.php", 'POST', $t2Post, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonT2 = json_decode($resT2['body'], true);

assertTest(($jsonT2['status'] ?? '') === 'success', "Pune visitor successfully added via AJAX", $resT2['body']);
assertTest(($jsonT2['counter_name'] ?? '') === 'Pune Counter 3', "Dr. Pallavi Patil resolved to Pune Counter 3 without shifting others");

// Check counter ID in database
$puneCid = (int)$pdo->query("SELECT counter_id FROM `allowed_visitors` WHERE user_id = 'TEST_PUNE_003'")->fetchColumn();
$puneCounterRow = $pdo->query("SELECT name, code FROM counters WHERE id = {$puneCid}")->fetch(PDO::FETCH_ASSOC);
assertTest(($puneCounterRow['code'] ?? '') === 'pune_3', "Database confirms counter_id maps to 'pune_3' (ID: {$puneCid})");

echo "\n";

// =========================================================================
// TEST 3: Combined Counter Region (Raipur -> Raipur / Chandigarh Counter)
// =========================================================================
echo "TEST 3: Adding Raipur visitor -> Raipur / Chandigarh Counter...\n";
$t3Post = [
    'action'        => 'add_visitor',
    'tab'           => 'gate',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => 'Ramesh Patel',
    'user_id'       => 'TEST_RAIPUR_001',
    'region'        => 'Raipur',
    'fincert'       => '',
    'mobile'        => '9876543212',
    'email'         => '',
    'school_name'   => '',
    'designation'   => ''
];

$resT3 = httpReq("{$baseUrl}/admin.php", 'POST', $t3Post, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonT3 = json_decode($resT3['body'], true);

assertTest(($jsonT3['status'] ?? '') === 'success', "Raipur visitor successfully added via AJAX", $resT3['body']);
assertTest(($jsonT3['counter_name'] ?? '') === 'Raipur / Chandigarh Counter', "Assigned to combined 'Raipur / Chandigarh Counter' (ID: " . ($jsonT3['counter_id'] ?? '') . ")");

echo "\n";

// =========================================================================
// TEST 4: Duplicate Checks (Register Id, Mobile, FinCert)
// =========================================================================
echo "TEST 4: Testing Duplicate Checks...\n";

// A) Duplicate Register Id (case insensitive) -> MUST BE BLOCKED
$dupUidPost = [
    'action'        => 'add_visitor',
    'tab'           => 'gate',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => 'Imposter User',
    'user_id'       => 'test_triv_001', // Lowercase of TEST_TRIV_001
    'region'        => 'Trivandrum',
];
$resDupUid = httpReq("{$baseUrl}/admin.php", 'POST', $dupUidPost, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonDupUid = json_decode($resDupUid['body'], true);

assertTest(($jsonDupUid['status'] ?? '') === 'error', "Duplicate Register Id (different case) is BLOCKED");
assertTest(isset($jsonDupUid['errors']['user_id']) && strpos($jsonDupUid['errors']['user_id'], 'already exists') !== false, "Error message mentions 'already exists': " . ($jsonDupUid['errors']['user_id'] ?? ''));

// B) Duplicate Mobile & Duplicate FinCert -> Warning with 'Add anyway'
$dupWarnPost = [
    'action'        => 'add_visitor',
    'tab'           => 'gate',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => 'Duplicate Tester',
    'user_id'       => 'TEST_DUP_001',
    'region'        => 'Ahmedabad',
    'mobile'        => '9876543210', // already belongs to Test Shibili Trivandrum
    'fincert'       => 'NTC-2026/TRV/0001' // already belongs to Test Shibili Trivandrum
];
$resDupWarn = httpReq("{$baseUrl}/admin.php", 'POST', $dupWarnPost, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonDupWarn = json_decode($resDupWarn['body'], true);

assertTest(($jsonDupWarn['status'] ?? '') === 'warning', "Duplicate mobile and FinCert return 'warning' status");
assertTest(isset($jsonDupWarn['warnings']['mobile']), "Warning contains mobile warning mentioning existing attendee");
assertTest(isset($jsonDupWarn['warnings']['fincert']), "Warning contains fincert warning mentioning existing attendee");

// C) Submitting with confirm checkboxes -> Allowed!
$dupWarnPost['confirm_duplicate_mobile'] = '1';
$dupWarnPost['confirm_duplicate_fincert'] = '1';
$resDupConf = httpReq("{$baseUrl}/admin.php", 'POST', $dupWarnPost, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonDupConf = json_decode($resDupConf['body'], true);
assertTest(($jsonDupConf['status'] ?? '') === 'success', "When 'Add anyway' checkboxes are checked, visitor is successfully saved");

echo "\n";

// =========================================================================
// TEST 5: Invalid inputs (7 digits mobile, empty name, invalid email, no region)
// =========================================================================
echo "TEST 5: Testing validation on invalid inputs...\n";
$invPost = [
    'action'        => 'add_visitor',
    'tab'           => 'gate',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => ' ', // Empty name
    'user_id'       => 'TEST_INV_001',
    'region'        => '', // No region
    'mobile'        => '1234567', // 7 digits (invalid)
    'email'         => 'not-an-email', // invalid email
];
$resInv = httpReq("{$baseUrl}/admin.php", 'POST', $invPost, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonInv = json_decode($resInv['body'], true);

assertTest(($jsonInv['status'] ?? '') === 'error', "Invalid form submission returns 'error' status");
assertTest(isset($jsonInv['errors']['name']), "Name error: " . ($jsonInv['errors']['name'] ?? ''));
assertTest(isset($jsonInv['errors']['region']), "Region error: " . ($jsonInv['errors']['region'] ?? ''));
assertTest(isset($jsonInv['errors']['mobile']), "Mobile error: " . ($jsonInv['errors']['mobile'] ?? ''));
assertTest(isset($jsonInv['errors']['email']), "Email error: " . ($jsonInv['errors']['email'] ?? ''));

$invCheck = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors` WHERE user_id = 'TEST_INV_001'")->fetchColumn();
assertTest($invCheck === 0, "Nothing was saved in database for invalid submission");

echo "\n";

// =========================================================================
// TEST 6: Empty FinCert (hides Id line on approval card) & 8-digit mobile
// =========================================================================
echo "TEST 6: Testing Empty FinCert & 8-digit mobile...\n";
$t6Post = [
    'action'        => 'add_visitor',
    'tab'           => 'gate',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => 'Overseas Visitor',
    'user_id'       => 'TEST_OVERSEAS_8DIGIT',
    'region'        => 'Bengaluru',
    'mobile'        => '88776655', // 8-digit overseas mobile
    'fincert'       => '', // Empty fincert
];
$resT6 = httpReq("{$baseUrl}/admin.php", 'POST', $t6Post, $cookieFileAdmin, ['X-Requested-With: XMLHttpRequest']);
$jsonT6 = json_decode($resT6['body'], true);

assertTest(($jsonT6['status'] ?? '') === 'success', "8-digit overseas mobile is allowed and saved");

// Test Day 1 Check-In at Gate Terminal by Register Id
$gateCheckUid = httpReq("{$baseUrl}/index.php", 'POST', [
    'mobile' => 'TEST_OVERSEAS_8DIGIT',
    'day'    => '1'
], null, ['X-Requested-With: XMLHttpRequest']);
$gateUidJson = json_decode($gateCheckUid['body'], true);
assertTest(($gateUidJson['status'] ?? '') === 'success', "Visitor checked in at Day 1 Gate Terminal via Register Id");
assertTest(empty($gateUidJson['fincert']), "fincert returned is null/empty");

echo "\n";

// =========================================================================
// TEST 7: Counter User Cannot See Button & Gets 403 on Manual POST
// =========================================================================
echo "TEST 7: Counter user permission restrictions...\n";
// Login as Counter staff (e.g. counter_pune_1)
$cLoginRes = doLogin('counter_pune_1', 'Pune@2026', $cookieFileCounter);

$cGiftPage = httpReq("{$baseUrl}/admin.php?tab=gift", 'GET', [], $cookieFileCounter);
assertTest(strpos($cGiftPage['body'], 'data-bs-target="#addVisitorModal"') === false, "Counter user DOES NOT see 'Add Visitor' button in gift tab");

// Try manual POST as Counter user -> Expect HTTP 403 Forbidden
$cPostHack = [
    'action'        => 'add_visitor',
    'tab'           => 'gift',
    'csrf_token'    => $csrfToken,
    'ajax'          => '1',
    'name'          => 'Hacker Attendee',
    'user_id'       => 'TEST_HACK_001',
    'region'        => 'Pune',
];
$resHack = httpReq("{$baseUrl}/admin.php", 'POST', $cPostHack, $cookieFileCounter, ['X-Requested-With: XMLHttpRequest']);
assertTest($resHack['status'] === 403, "Manual POST to add_visitor as counter user returns HTTP 403 Forbidden");

echo "\n";

// =========================================================================
// TEST 8: COE Kit Distribution Tab also has Add Visitor button for Super Admin
// =========================================================================
echo "TEST 8: Checking COE Kit Distribution tab for Super Admin...\n";
$superGiftPage = httpReq("{$baseUrl}/admin.php?tab=gift", 'GET', [], $cookieFileAdmin);
assertTest(strpos($superGiftPage['body'], 'data-bs-target="#addVisitorModal"') !== false, "Super Admin sees 'Add Visitor' button on COE Kit Distribution tab");

echo "\n";

// =========================================================================
// TEST 9: Audit Log Verification & Cleanup
// =========================================================================
echo "TEST 9: Checking Audit Log & Reverting Database to Exact Baseline...\n";
$auditRows = $pdo->query("SELECT * FROM `audit_log` WHERE action = 'add_visitor' ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
assertTest(count($auditRows) >= 4, "Audit log contains entries for added visitors");
assertTest(($auditRows[0]['performed_by'] ?? '') === 'admin', "Audit log records admin as performed_by");

// Delete all test records created during testing
$testIds = ['TEST_TRIV_001', 'TEST_PUNE_003', 'TEST_RAIPUR_001', 'TEST_DUP_001', 'TEST_OVERSEAS_8DIGIT', 'TEST_HACK_001', 'TEST_INV_001'];
$inPlaceholders = implode(',', array_fill(0, count($testIds), '?'));

$delAv = $pdo->prepare("DELETE FROM `allowed_visitors` WHERE user_id IN ($inPlaceholders)");
$delAv->execute($testIds);

$delGd = $pdo->prepare("DELETE FROM `gift_distribution` WHERE user_id IN ($inPlaceholders)");
$delGd->execute($testIds);

$delAudit = $pdo->prepare("DELETE FROM `audit_log` WHERE target_id IN ($inPlaceholders)");
$delAudit->execute($testIds);

$finalCountAv = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors`")->fetchColumn();
$finalCountGd = (int)$pdo->query("SELECT COUNT(*) FROM `gift_distribution`")->fetchColumn();

assertTest($finalCountAv === $baselineCount, "allowed_visitors total reverted to exact baseline ({$finalCountAv} == {$baselineCount})");
assertTest($finalCountGd === $baselineCount, "gift_distribution total reverted to exact baseline ({$finalCountGd} == {$baselineCount})");

echo "\n=== TEST SUITE COMPLETE ===\n";
echo "Total Passed: {$passCount}\n";
echo "Total Failed: {$failCount}\n";

if ($failCount === 0) {
    echo "\n>>> ALL 9 SCENARIOS VERIFIED SUCCESSFULLY! <<<\n";
} else {
    echo "\n>>> SOME TESTS FAILED! <<<\n";
}
