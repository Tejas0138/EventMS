<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$missing = $pdo->query('SELECT COUNT(*) FROM gift_distribution g LEFT JOIN allowed_visitors a ON a.user_id = g.user_id WHERE a.user_id IS NULL')->fetchColumn();
echo "Gift distribution records without matching allowed_visitors: $missing\n";
