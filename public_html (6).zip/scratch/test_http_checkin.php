<?php
$url = 'http://localhost:8080/EventMS/index.php';
$data = ['identifier' => '9049455369', 'day' => 1];

$options = [
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/json\r\nAccept: application/json\r\n",
        'content' => json_encode($data),
        'ignore_errors' => true
    ]
];

$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);
$decoded = json_decode($result, true);

echo "HTTP Response from Gate Terminal:\n";
print_r($decoded);
