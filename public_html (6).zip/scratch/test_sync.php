<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

function cleanNameForSort(string $name): string {
    $clean = trim($name);
    $clean = preg_replace('/^(dr\.?|mr\.?|mrs\.?|ms\.?|prof\.?|sh\.?|smt\.?|shri\.?)\s+/i', '', $clean);
    return trim($clean);
}

function syncVisitorCounters(PDO $pdo): int {
    // 1. Fetch counters map: code => id
    $cStmt = $pdo->query("SELECT id, code FROM counters");
    $counterMap = $cStmt->fetchAll(PDO::FETCH_KEY_PAIR);
    if (empty($counterMap)) {
        return 0;
    }

    $helpDeskId = (int)($counterMap['helpdesk'] ?? 0);

    // Build region to counter_id mapping from counter_regions
    $crStmt = $pdo->query("
        SELECT cr.region, cr.counter_id 
        FROM counter_regions cr
        JOIN counters c ON c.id = cr.counter_id
        WHERE c.code NOT LIKE 'pune_%'
    ");
    $regionMap = [];
    while ($r = $crStmt->fetch(PDO::FETCH_ASSOC)) {
        $reg = trim((string)$r['region']);
        if ($reg !== '') {
            $regionMap[mb_strtolower($reg, 'UTF-8')] = (int)$r['counter_id'];
        }
    }

    $updVis = $pdo->prepare("UPDATE allowed_visitors SET counter_id = :cid WHERE id = :id");
    $updGift = $pdo->prepare("UPDATE gift_distribution SET counter_id = :cid WHERE user_id = :uid");

    $updated = 0;

    // Check if any Pune visitors need assignment
    $puneCheck = $pdo->query("
        SELECT id, name, user_id 
        FROM allowed_visitors 
        WHERE LOWER(TRIM(region)) = 'pune' AND (counter_id IS NULL OR counter_id = 0)
    ")->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($puneCheck)) {
        // Need to re-sort all Pune visitors to keep the 73, 73, 72, 72 balance
        $allPune = $pdo->query("SELECT id, name, user_id FROM allowed_visitors WHERE LOWER(TRIM(region)) = 'pune'")->fetchAll(PDO::FETCH_ASSOC);
        usort($allPune, function($a, $b) {
            $nameA = cleanNameForSort($a['name']);
            $nameB = cleanNameForSort($b['name']);
            $cmp = strcasecmp($nameA, $nameB);
            if ($cmp !== 0) return $cmp;
            return strcasecmp($a['name'], $b['name']);
        });

        $totalPune = count($allPune);
        // Split into 4 balanced groups
        $base = (int)floor($totalPune / 4);
        $rem = $totalPune % 4;
        $g1Size = $base + ($rem > 0 ? 1 : 0);
        $g2Size = $base + ($rem > 1 ? 1 : 0);
        $g3Size = $base + ($rem > 2 ? 1 : 0);
        $g4Size = $base;

        $g1 = array_slice($allPune, 0, $g1Size);
        $g2 = array_slice($allPune, $g1Size, $g2Size);
        $g3 = array_slice($allPune, $g1Size + $g2Size, $g3Size);
        $g4 = array_slice($allPune, $g1Size + $g2Size + $g3Size);

        $slices = [
            1 => $g1,
            2 => $g2,
            3 => $g3,
            4 => $g4
        ];

        foreach ($slices as $grpNum => $slice) {
            $cid = (int)($counterMap['pune_' . $grpNum] ?? 0);
            if ($cid > 0) {
                foreach ($slice as $v) {
                    $updVis->execute([':cid' => $cid, ':id' => $v['id']]);
                    if (!empty($v['user_id'])) {
                        $updGift->execute([':cid' => $cid, ':uid' => $v['user_id']]);
                    }
                    $updated++;
                }
            }
        }
    }

    // Now assign any non-pune visitors with counter_id IS NULL or 0
    $unassigned = $pdo->query("
        SELECT id, name, user_id, region 
        FROM allowed_visitors 
        WHERE (region IS NULL OR LOWER(TRIM(region)) != 'pune') 
          AND (counter_id IS NULL OR counter_id = 0)
    ")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($unassigned as $u) {
        $rClean = mb_strtolower(trim((string)($u['region'] ?? '')), 'UTF-8');
        $targetCid = $regionMap[$rClean] ?? $helpDeskId;
        if ($targetCid > 0) {
            $updVis->execute([':cid' => $targetCid, ':id' => $u['id']]);
            if (!empty($u['user_id'])) {
                $updGift->execute([':cid' => $targetCid, ':uid' => $u['user_id']]);
            }
            $updated++;
        }
    }

    // Also sync gift_distribution records that have counter_id IS NULL or 0
    $pdo->exec("
        UPDATE gift_distribution g
        JOIN allowed_visitors v ON (v.user_id = g.user_id AND v.user_id IS NOT NULL AND v.user_id != '')
        SET g.counter_id = v.counter_id
        WHERE g.counter_id IS NULL OR g.counter_id = 0
    ");

    return $updated;
}

$synced = syncVisitorCounters($pdo);
echo "Synced count: {$synced}\n";

$checkNull = $pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id IS NULL OR counter_id = 0")->fetchColumn();
echo "Remaining unassigned in allowed_visitors: {$checkNull}\n";
$checkNullGift = $pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE counter_id IS NULL OR counter_id = 0")->fetchColumn();
echo "Remaining unassigned in gift_distribution: {$checkNullGift}\n";
