<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$sql = "
    SELECT 
        v.id, v.name, v.user_id, v.region, v.counter_id, c.name as counter_name,
        v.is_checked_in, v.checked_in_at,
        v.is_day1_checked_in, v.day1_checked_in_at,
        v.is_day2_checked_in, v.day2_checked_in_at,
        g.is_gift_collected, g.gift_collected_at, g.handed_over_by
    FROM allowed_visitors v
    LEFT JOIN counters c ON c.id = v.counter_id
    LEFT JOIN gift_distribution g ON g.user_id = v.user_id
    WHERE v.is_checked_in = 1 
       OR v.is_day1_checked_in = 1 
       OR v.is_day2_checked_in = 1 
       OR g.is_gift_collected = 1
    ORDER BY v.id ASC
";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
echo "Total visitors with check-ins or kit: " . count($rows) . "\n";
foreach ($rows as $r) {
    echo "ID: {$r['id']} | Name: {$r['name']} | RegID: {$r['user_id']} | Counter: {$r['counter_name']} ({$r['counter_id']})\n";
    echo "  Day1: {$r['is_day1_checked_in']} at {$r['day1_checked_in_at']} | Day2: {$r['is_day2_checked_in']} at {$r['day2_checked_in_at']}\n";
    echo "  Kit: {$r['is_gift_collected']} at {$r['gift_collected_at']} by {$r['handed_over_by']}\n";
}
