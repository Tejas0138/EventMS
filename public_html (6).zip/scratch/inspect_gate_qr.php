<?php
require_once __DIR__ . '/../config/db.php';
$baseUrl = 'http://localhost:8080/EventMS';
$cookieFile = __DIR__ . '/test_admin_cookie.txt';

// Login as admin
$ch = curl_init("$baseUrl/login.php");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR      => $cookieFile,
    CURLOPT_COOKIEFILE     => $cookieFile,
]);
$html = curl_exec($ch);
preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', (string)$html, $m);
$token = $m[1] ?? '';

curl_setopt_array($ch, [
    CURLOPT_POST       => true,
    CURLOPT_POSTFIELDS => http_build_query([
        'csrf_token' => $token,
        'username'   => 'admin',
        'password'   => 'admin123'
    ]),
    CURLOPT_FOLLOWLOCATION => true
]);
curl_exec($ch);

// GET admin.php?tab=gate_qr
curl_setopt_array($ch, [
    CURLOPT_URL => "$baseUrl/admin.php?tab=gate_qr",
    CURLOPT_POST => false,
    CURLOPT_HTTPGET => true,
    CURLOPT_FOLLOWLOCATION => true
]);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
echo "HTTP code: $code\n";
echo "Length: " . strlen($res) . "\n";
echo "Title: ";
preg_match('/<title>(.*?)<\/title>/', $res, $tm);
echo ($tm[1] ?? 'None') . "\n";
preg_match('/<div class="content-card-title">(.*?)<\/div>/s', $res, $cm);
echo "Card title: " . trim(strip_tags($cm[1] ?? 'None')) . "\n";
