<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$totalAllowed = (int)$pdo->query("SELECT COUNT(*) FROM `allowed_visitors`")->fetchColumn();
$totalGift = (int)$pdo->query("SELECT COUNT(*) FROM `gift_distribution`")->fetchColumn();

$countersStmt = $pdo->query("
    SELECT c.id, c.counter_no, c.name, c.code, c.username, c.name_range,
           COALESCE(g_agg.total_visitors, 0) AS total_visitors
    FROM `counters` c
    LEFT JOIN (
        SELECT counter_id,
               COUNT(*) AS total_visitors
        FROM `gift_distribution`
        WHERE counter_id IS NOT NULL AND counter_id > 0
        GROUP BY counter_id
    ) g_agg ON (g_agg.counter_id = c.id)
    WHERE c.is_active = 1 AND c.code != 'helpdesk'
    ORDER BY COALESCE(c.counter_no, 999) ASC, c.id ASC
");
$countersList = $countersStmt->fetchAll(PDO::FETCH_ASSOC);

$sumCounters = 0;
foreach ($countersList as $c) {
    echo "Counter {$c['counter_no']} | {$c['name']} ({$c['username']}): {$c['total_visitors']} visitors\n";
    $sumCounters += (int)$c['total_visitors'];
}

echo "\nSummary:\n";
echo "Total allowed_visitors: {$totalAllowed}\n";
echo "Total gift_distribution: {$totalGift}\n";
echo "Sum across active counters: {$sumCounters}\n";
echo "Difference: " . ($totalAllowed - $sumCounters) . "\n";
