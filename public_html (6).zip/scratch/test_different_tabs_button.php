<?php
require_once __DIR__ . '/../config/db.php';
$baseUrl = 'http://localhost:8080/EventMS';
$cookieFile = __DIR__ . '/test_admin_cookie.txt';

$scenarios = [
    'Day 1 Tab' => 'admin.php?tab=gate&gfilter=day1',
    'Day 1 + Pune' => 'admin.php?tab=gate&gfilter=day1&gregion=Pune',
    'Day 2 (0 count)' => 'admin.php?tab=gate&gfilter=day2',
    'Pending Both' => 'admin.php?tab=gate&gfilter=pending_both',
];

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEFILE     => $cookieFile,
    CURLOPT_FOLLOWLOCATION => true
]);

foreach ($scenarios as $label => $path) {
    curl_setopt($ch, CURLOPT_URL, "$baseUrl/$path");
    $page = curl_exec($ch);
    preg_match('/id="btnGateTabExport"[^>]*>.*?<\/(?:a|button)>/s', $page, $m);
    echo "[$label: $path]\n";
    echo ($m[0] ?? 'NOT FOUND') . "\n\n";
}
curl_close($ch);
