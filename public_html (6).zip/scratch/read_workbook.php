<?php
$zip = new ZipArchive();
$file = __DIR__ . '/../raw_data_AG_updated.xlsx';
if ($zip->open($file) === TRUE) {
    echo "=== WORKBOOK.XML ===\n";
    echo $zip->getFromName('xl/workbook.xml') . "\n";
    $zip->close();
}
