<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$stmt = $pdo->query("SELECT region, COUNT(*) as cnt FROM allowed_visitors GROUP BY region");
$regions = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

print_r($regions);

$counterDefinitions = [
    // 5 Combined
    ['name' => 'Raipur / Chandigarh Counter', 'regions' => ['Raipur', 'Chandigarh']],
    ['name' => 'Dehradun / Lucknow Counter', 'regions' => ['Dehradun', 'Lucknow']],
    ['name' => 'Gurugram / Guwahati Counter', 'regions' => ['Gurugram', 'Guwahati']],
    ['name' => 'Chennai / Vijayawada Counter', 'regions' => ['Chennai', 'Vijayawada']],
    ['name' => 'Panchkula / Prayagraj / Hyderabad Counter', 'regions' => ['Panchkula', 'Prayagraj', 'Hyderabad']],
    // 4 Pune
    ['name' => 'Pune Counter 1', 'regions' => ['Pune'], 'pune_group' => 1, 'expected' => 73],
    ['name' => 'Pune Counter 2', 'regions' => ['Pune'], 'pune_group' => 2, 'expected' => 73],
    ['name' => 'Pune Counter 3', 'regions' => ['Pune'], 'pune_group' => 3, 'expected' => 72],
    ['name' => 'Pune Counter 4', 'regions' => ['Pune'], 'pune_group' => 4, 'expected' => 72],
    // 11 Single-region
    ['name' => 'Noida Counter', 'regions' => ['Noida']],
    ['name' => 'Bengaluru Counter', 'regions' => ['Bengaluru']],
    ['name' => 'Bhopal Counter', 'regions' => ['Bhopal']],
    ['name' => 'Bhubaneswar Counter', 'regions' => ['Bhubaneswar']],
    ['name' => 'Ajmer Counter', 'regions' => ['Ajmer']],
    ['name' => 'Ahmedabad Counter', 'regions' => ['Ahmedabad']],
    ['name' => 'Patna Counter', 'regions' => ['Patna']],
    ['name' => 'Trivandrum Counter', 'regions' => ['Trivandrum']],
    ['name' => 'Delhi West Counter', 'regions' => ['Delhi West']],
    ['name' => 'Delhi East Counter', 'regions' => ['Delhi East']],
    ['name' => 'Ranchi Counter', 'regions' => ['Ranchi']],
    // 1 Help Desk
    ['name' => 'Help Desk', 'regions' => ['Help Desk', '']]
];

$totalVisitors = 0;
foreach ($counterDefinitions as $c) {
    $cTotal = 0;
    if (isset($c['pune_group'])) {
        $cTotal = $c['expected'];
    } else {
        foreach ($c['regions'] as $r) {
            if ($r === 'Help Desk' || $r === '') {
                // Find empty or null
                $cTotal += $regions[''] ?? $regions[null] ?? 0;
            } else {
                $cTotal += $regions[$r] ?? 0;
            }
        }
    }
    echo sprintf("%-42s : %4d\n", $c['name'], $cTotal);
    $totalVisitors += $cTotal;
}

echo "Total across 21 counters: {$totalVisitors}\n";
