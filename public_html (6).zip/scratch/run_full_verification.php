<?php
/**
 * Verification test suite for Step 5
 */
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$testsPassed = 0;
$testsFailed = 0;

function assertCheck($desc, $cond, $detail = '') {
    global $testsPassed, $testsFailed;
    if ($cond) {
        $testsPassed++;
        echo "  [PASS] $desc" . ($detail ? " ($detail)" : "") . "\n";
    } else {
        $testsFailed++;
        echo "  [FAIL] $desc" . ($detail ? " ($detail)" : "") . "\n";
    }
}

echo "========================================================\n";
echo "STEP 5: COMPREHENSIVE TESTING & VERIFICATION\n";
echo "========================================================\n\n";

// --- TEST 1: Database totals and empty fields ---
echo "--- 1. DATABASE TOTALS AND INTEGRITY ---\n";
$cntA = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
$cntG = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution")->fetchColumn();
assertCheck("allowed_visitors total is 1270", $cntA === 1270, "Found: $cntA");
assertCheck("gift_distribution total is 1270", $cntG === 1270, "Found: $cntG");

$emptyReg = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE region IS NULL OR TRIM(region) = ''")->fetchColumn();
$emptyMob = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE mobile IS NULL OR TRIM(mobile) = ''")->fetchColumn();
assertCheck("0 empty regions in allowed_visitors", $emptyReg === 0, "Found: $emptyReg");
assertCheck("0 empty contacts in allowed_visitors", $emptyMob === 0, "Found: $emptyMob");

// --- TEST 2: Active counters and total sum ---
echo "\n--- 2. ACTIVE COUNTERS & VISITOR DISTRIBUTION ---\n";
$counters = $pdo->query("
    SELECT c.id, c.code, c.name, c.is_active,
           COUNT(v.id) as v_count
    FROM counters c
    LEFT JOIN allowed_visitors v ON v.counter_id = c.id
    WHERE c.is_active = 1 AND c.code != 'helpdesk'
    GROUP BY c.id
    ORDER BY c.id
")->fetchAll(PDO::FETCH_ASSOC);

assertCheck("Active counters count is exactly 20", count($counters) === 20, "Count: " . count($counters));

$sumVisitors = 0;
foreach ($counters as $c) {
    $sumVisitors += (int)$c['v_count'];
}
assertCheck("Sum across 20 active counters is exactly 1270", $sumVisitors === 1270, "Sum: $sumVisitors");

$helpdeskActive = (int)$pdo->query("SELECT is_active FROM counters WHERE code = 'helpdesk'")->fetchColumn();
$helpdeskVisitors = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id = 21")->fetchColumn();
assertCheck("Help Desk counter is deactivated (is_active = 0)", $helpdeskActive === 0);
assertCheck("0 visitors assigned to Help Desk", $helpdeskVisitors === 0);

// --- TEST 3: HTTP Gate Terminal check-in for new visitor (OS_3071828) ---
echo "\n--- 3. TEST NEW VISITOR (OS_3071828 / SHIBILI C K M) GATE TERMINAL CHECK-IN ---\n";

function postGateTerminal($data) {
    $url = 'http://localhost:8080/EventMS/index.php';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'X-Requested-With: XMLHttpRequest',
        'Accept: application/json'
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $httpCode, 'data' => json_decode($response, true), 'raw' => $response];
}

// Check-in Day 1 via Mobile
$resD1 = postGateTerminal([
    'day' => 1,
    'identifier' => '9995020200'
]);

assertCheck("Day 1 check-in via mobile returns HTTP 200", $resD1['code'] === 200);
$jsonD1 = $resD1['data'];
assertCheck("Day 1 check-in status is success", ($jsonD1['status'] ?? '') === 'success');
assertCheck("Name is 'SHIBILI C K M'", ($jsonD1['name'] ?? '') === 'SHIBILI C K M');
assertCheck("Counter is 'Trivandrum Counter'", ($jsonD1['counter_name'] ?? '') === 'Trivandrum Counter');
assertCheck("Counter is NOT Help Desk", stripos(($jsonD1['counter_name'] ?? ''), 'Help Desk') === false);

// Check-in Day 2 via Register Id
$resD2 = postGateTerminal([
    'day' => 2,
    'identifier' => 'OS_3071828'
]);
assertCheck("Day 2 check-in via Register Id returns HTTP 200", $resD2['code'] === 200);
$jsonD2 = $resD2['data'];
assertCheck("Day 2 check-in status is success", ($jsonD2['status'] ?? '') === 'success');
assertCheck("Name is 'SHIBILI C K M'", ($jsonD2['name'] ?? '') === 'SHIBILI C K M');
assertCheck("Counter is 'Trivandrum Counter'", ($jsonD2['counter_name'] ?? '') === 'Trivandrum Counter');

// Test Duplicate Day 1 check-in
$resDup = postGateTerminal([
    'day' => 1,
    'identifier' => '9995020200'
]);
assertCheck("Duplicate Day 1 check-in returns duplicate status", ($resDup['data']['status'] ?? '') === 'duplicate');

// Clean up / Reset new visitor check-in to Pending (0)
$pdo->prepare("UPDATE allowed_visitors SET is_checked_in = 0, checked_in_at = NULL, is_day1_checked_in = 0, day1_checked_in_at = NULL, is_day2_checked_in = 0, day2_checked_in_at = NULL WHERE user_id = 'OS_3071828'")->execute();
$resetCheck = $pdo->query("SELECT is_day1_checked_in, is_day2_checked_in FROM allowed_visitors WHERE user_id = 'OS_3071828'")->fetch(PDO::FETCH_ASSOC);
assertCheck("Reset new visitor check-ins back to Pending (0)", (int)$resetCheck['is_day1_checked_in'] === 0 && (int)$resetCheck['is_day2_checked_in'] === 0);

// --- TEST 4: Test 2 of the 12 updated-region visitors ---
echo "\n--- 4. TEST 2 UPDATED-REGION VISITORS ON GATE TERMINAL ---\n";
// Visitor 1: MANPREET KAUR (OS_3310708) -> Pune Counter 2
$resPune = postGateTerminal([
    'day' => 1,
    'identifier' => 'OS_3310708'
]);
$jsonPune = $resPune['data'];
assertCheck("MANPREET KAUR assigned to Pune Counter 2", ($jsonPune['counter_name'] ?? '') === 'Pune Counter 2', "Found: " . ($jsonPune['counter_name'] ?? ''));
assertCheck("Pune Counter 2 has range chip", !empty($jsonPune['counter_range']));
// Reset back
$pdo->prepare("UPDATE allowed_visitors SET is_checked_in = 0, checked_in_at = NULL, is_day1_checked_in = 0, day1_checked_in_at = NULL WHERE user_id = 'OS_3310708'")->execute();

// Visitor 2: Shivani Singh (OS_1556598) -> Raipur / Chandigarh Counter
$resChd = postGateTerminal([
    'day' => 1,
    'identifier' => 'OS_1556598'
]);
$jsonChd = $resChd['data'];
assertCheck("Shivani Singh assigned to Raipur / Chandigarh Counter", ($jsonChd['counter_name'] ?? '') === 'Raipur / Chandigarh Counter', "Found: " . ($jsonChd['counter_name'] ?? ''));
assertCheck("Counter is NOT Help Desk", stripos(($jsonChd['counter_name'] ?? ''), 'Help Desk') === false);
// Reset back
$pdo->prepare("UPDATE allowed_visitors SET is_checked_in = 0, checked_in_at = NULL, is_day1_checked_in = 0, day1_checked_in_at = NULL WHERE user_id = 'OS_1556598'")->execute();

// --- TEST 5: Test mobile search for the 2 updated-contact visitors ---
echo "\n--- 5. TEST MOBILE SEARCH FOR THE 2 UPDATED-CONTACT VISITORS ---\n";
// Contact 1: Dr. Jyotsna Sharma (8588851984)
$resMob1 = postGateTerminal([
    'day' => 1,
    'identifier' => '8588851984'
]);
$jsonMob1 = $resMob1['data'];
assertCheck("Search 8588851984 finds Dr. Jyotsna Sharma", stripos(($jsonMob1['name'] ?? ''), 'Jyotsna Sharma') !== false);
assertCheck("Dr. Jyotsna Sharma counter is Noida Counter", ($jsonMob1['counter_name'] ?? '') === 'Noida Counter');
// Reset back
$pdo->prepare("UPDATE allowed_visitors SET is_checked_in = 0, checked_in_at = NULL, is_day1_checked_in = 0, day1_checked_in_at = NULL WHERE mobile = '8588851984'")->execute();

// Contact 2: Ms. Shivani Luthra (8800093733)
$resMob2 = postGateTerminal([
    'day' => 1,
    'identifier' => '8800093733'
]);
$jsonMob2 = $resMob2['data'];
assertCheck("Search 8800093733 finds Ms. Shivani Luthra", stripos(($jsonMob2['name'] ?? ''), 'Shivani Luthra') !== false);
assertCheck("Ms. Shivani Luthra counter is Delhi East Counter", ($jsonMob2['counter_name'] ?? '') === 'Delhi East Counter');
// Reset back
$pdo->prepare("UPDATE allowed_visitors SET is_checked_in = 0, checked_in_at = NULL, is_day1_checked_in = 0, day1_checked_in_at = NULL WHERE mobile = '8800093733'")->execute();

// --- TEST 6: Test counter_helpdesk login disabled ---
echo "\n--- 6. TEST COUNTER_HELPDESK LOGIN REJECTION ---\n";
function postLoginWithCsrf($user, $pass) {
    $cookieFile = __DIR__ . '/test_cookie.txt';
    if (file_exists($cookieFile)) unlink($cookieFile);

    // 1. GET login page to obtain session cookie & CSRF token
    $ch = curl_init('http://localhost:8080/EventMS/login.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    $html = curl_exec($ch);
    curl_close($ch);

    // Extract CSRF token
    preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', $html, $matches);
    $csrf = $matches[1] ?? '';

    // 2. POST credentials with CSRF token and session cookie
    $ch = curl_init('http://localhost:8080/EventMS/login.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'csrf_token' => $csrf,
        'username' => $user,
        'password' => $pass
    ]));
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (file_exists($cookieFile)) unlink($cookieFile);
    return ['code' => $httpCode, 'body' => $response];
}
$loginRes = postLoginWithCsrf('counter_helpdesk', 'HelpDesk@2026');
assertCheck("Help desk login rejected with disabled message", stripos($loginRes['body'], 'disabled') !== false);

// --- TEST 7: Check-in and Gift History baseline check ---
echo "\n--- 7. BASELINE CHECK-IN AND GIFT HISTORY PRESERVED ---\n";
$d1Total = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day1_checked_in = 1")->fetchColumn();
$d2Total = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day2_checked_in = 1")->fetchColumn();
$kitTotal = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE is_gift_collected = 1")->fetchColumn();
assertCheck("Day 1 check-ins count preserved (exactly 3)", $d1Total === 3, "Count: $d1Total");
assertCheck("Day 2 check-ins count preserved (exactly 0)", $d2Total === 0, "Count: $d2Total");
assertCheck("Gift kits collected count preserved (exactly 0)", $kitTotal === 0, "Count: $kitTotal");

echo "\n========================================================\n";
echo "SUMMARY: $testsPassed PASSED, $testsFailed FAILED\n";
echo "========================================================\n";
