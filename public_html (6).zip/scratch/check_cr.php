<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$cols = $pdo->query("DESCRIBE counter_regions")->fetchAll(PDO::FETCH_ASSOC);
foreach ($cols as $col) {
    echo "{$col['Field']} ({$col['Type']})\n";
}
$rows = $pdo->query("SELECT * FROM counter_regions")->fetchAll(PDO::FETCH_ASSOC);
print_r($rows);
