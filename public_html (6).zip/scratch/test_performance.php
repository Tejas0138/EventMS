<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

function benchmark(string $name, callable $fn): float {
    $start = microtime(true);
    $fn();
    $duration = (microtime(true) - $start) * 1000;
    echo sprintf("%-45s : %8.2f ms\n", $name, $duration);
    return $duration;
}

echo "=== DATABASE QUERY PERFORMANCE ===\n";

benchmark("1. Gate list (50 rows with counts)", function() use ($pdo) {
    $stmt = $pdo->query("SELECT * FROM allowed_visitors ORDER BY id ASC LIMIT 50");
    $stmt->fetchAll();
    $total = $pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
});

benchmark("2. Gift list (50 rows with joins)", function() use ($pdo) {
    $sql = "SELECT g.*, c.name AS assigned_counter_name,
                   (CASE WHEN (a.is_day1_checked_in = 1 OR a.is_day2_checked_in = 1) THEN 1 ELSE 0 END) AS is_gate_entered,
                   GREATEST(COALESCE(a.day1_checked_in_at, '1970-01-01 00:00:00'), COALESCE(a.day2_checked_in_at, '1970-01-01 00:00:00'), COALESCE(a.checked_in_at, '1970-01-01 00:00:00')) AS gate_entered_at
            FROM `gift_distribution` g
            LEFT JOIN `counters` c ON c.id = g.counter_id
            LEFT JOIN `allowed_visitors` a ON a.user_id = g.user_id
            ORDER BY g.name ASC LIMIT 50";
    $stmt = $pdo->query($sql);
    $stmt->fetchAll();
});

benchmark("3. Counters aggregation query", function() use ($pdo) {
    $sql = "
        SELECT c.id, c.counter_no, c.name, c.code, c.username, c.name_range, c.is_active, c.last_login,
               COALESCE(g_agg.total_visitors, 0) AS total_visitors,
               COALESCE(g_agg.kits_distributed, 0) AS kits_distributed,
               COALESCE(g_agg.kits_pending, 0) AS kits_pending,
               (
                   SELECT GROUP_CONCAT(NULLIF(TRIM(cr.region), '') ORDER BY cr.region SEPARATOR ', ')
                   FROM `counter_regions` cr
                   WHERE cr.counter_id = c.id AND TRIM(cr.region) != ''
               ) AS regions_covered
        FROM `counters` c
        LEFT JOIN (
            SELECT counter_id,
                   COUNT(*) AS total_visitors,
                   SUM(CASE WHEN is_gift_collected = 1 THEN 1 ELSE 0 END) AS kits_distributed,
                   SUM(CASE WHEN is_gift_collected = 0 THEN 1 ELSE 0 END) AS kits_pending
            FROM `gift_distribution`
            WHERE counter_id IS NOT NULL AND counter_id > 0
            GROUP BY counter_id
        ) g_agg ON (g_agg.counter_id = c.id)
        WHERE c.is_active = 1 AND c.code != 'helpdesk'
        ORDER BY COALESCE(c.counter_no, 999) ASC, c.id ASC
    ";
    $stmt = $pdo->query($sql);
    $stmt->fetchAll();
});

benchmark("4. Gate CSV Full Export (1270 rows)", function() use ($pdo) {
    $sql = "SELECT id, name, user_id, fincert, region, mobile, is_day1_checked_in, day1_checked_in_at, is_day2_checked_in, day2_checked_in_at FROM allowed_visitors ORDER BY id ASC";
    $stmt = $pdo->query($sql);
    $stmt->fetchAll();
});

benchmark("5. Gift CSV Full Export (1270 rows with join)", function() use ($pdo) {
    $sql = "SELECT g.*, c.name as counter_name, a.is_day1_checked_in, a.is_day2_checked_in 
            FROM gift_distribution g 
            LEFT JOIN counters c ON c.id = g.counter_id 
            LEFT JOIN allowed_visitors a ON a.user_id = g.user_id
            ORDER BY g.name ASC";
    $stmt = $pdo->query($sql);
    $stmt->fetchAll();
});
