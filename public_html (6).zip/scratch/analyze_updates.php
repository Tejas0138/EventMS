<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

require_once __DIR__ . '/parse_excel_test.php'; // has parseXlsx function

$data = parseXlsx(__DIR__ . '/../raw_data_AG_updated.xlsx');
$missingDetails = $data['Missing Details'];

echo "=== CHECKING ROWS FROM 'Missing Details' ===\n";

// Row 5 is header
$headers = $missingDetails[5];
print_r($headers);

$rowsToProcess = [];
for ($r = 6; $r <= count($missingDetails) + 1; $r++) {
    if (!isset($missingDetails[$r])) continue;
    $row = $missingDetails[$r];
    $sno = trim($row['A'] ?? '');
    $region = trim($row['B'] ?? '');
    $userId = trim($row['C'] ?? '');
    $school = trim($row['D'] ?? '');
    $name = trim($row['E'] ?? '');
    $desig = trim($row['F'] ?? '');
    $contact = trim($row['G'] ?? '');
    $email = trim($row['H'] ?? '');
    $fincert = trim($row['I'] ?? '');
    $field = trim($row['J'] ?? '');
    $sourceRow = trim($row['K'] ?? '');

    if (empty($userId)) continue;

    $rowsToProcess[] = [
        'r' => $r,
        'sno' => $sno,
        'region' => $region,
        'user_id' => $userId,
        'school' => $school,
        'name' => $name,
        'desig' => $desig,
        'contact' => $contact,
        'email' => $email,
        'fincert' => $fincert,
        'field' => $field,
        'sourceRow' => $sourceRow
    ];
}

echo "Total rows extracted: " . count($rowsToProcess) . "\n";

foreach ($rowsToProcess as $item) {
    echo "\n----------------------------------------\n";
    echo "Processing User ID: {$item['user_id']} ({$item['name']})\n";
    echo "Sheet Field: {$item['field']} | Sheet Region: '{$item['region']}' | Sheet Contact: '{$item['contact']}' | FinCert: '{$item['fincert']}'\n";

    // Query DB
    $stmt = $pdo->prepare("SELECT * FROM allowed_visitors WHERE LOWER(TRIM(user_id)) = LOWER(TRIM(?))");
    $stmt->execute([$item['user_id']]);
    $dbVisitor = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($dbVisitor) {
        echo "Found in allowed_visitors: ID={$dbVisitor['id']}\n";
        echo "DB Region: '{$dbVisitor['region']}'\n";
        echo "DB Mobile: '{$dbVisitor['mobile']}'\n";
        echo "DB Name: '{$dbVisitor['name']}'\n";
        echo "DB Email: '{$dbVisitor['email']}'\n";
        echo "DB FinCert: '{$dbVisitor['fincert']}'\n";
        echo "DB CounterID: {$dbVisitor['counter_id']}\n";
    } else {
        echo "NOT FOUND in allowed_visitors -> THIS IS A NEW VISITOR!\n";
    }
}
