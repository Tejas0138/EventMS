<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "Database connected successfully.\n";
$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
echo "Tables: " . implode(', ', $tables) . "\n";

foreach ($tables as $t) {
    $count = $pdo->query("SELECT COUNT(*) FROM `{$t}`")->fetchColumn();
    echo "Table {$t}: {$count} rows\n";
}
