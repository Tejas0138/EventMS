<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();
$rows = $pdo->query("SELECT id, username, role, region, counter_id FROM admins")->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
    echo "ID: {$r['id']} | Username: {$r['username']} | Role: {$r['role']} | Region: {$r['region']} | CounterID: {$r['counter_id']}\n";
}
