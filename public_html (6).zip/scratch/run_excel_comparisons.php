<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

function parseXlsx(string $filePath, string $sheetName): array {
    $zip = new ZipArchive();
    if ($zip->open($filePath) !== true) {
        throw new RuntimeException("Cannot open $filePath");
    }

    // Shared strings
    $sharedStrings = [];
    $ssContent = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssContent !== false) {
        $ssClean = preg_replace('/<(\/)?([a-zA-Z0-9]+:)/', '<$1', $ssContent);
        $sXml = simplexml_load_string($ssClean);
        foreach ($sXml->si as $si) {
            $t = '';
            if (isset($si->t)) {
                $t = (string)$si->t;
            } elseif (isset($si->r)) {
                foreach ($si->r as $r) {
                    $t .= (string)$r->t;
                }
            }
            $sharedStrings[] = $t;
        }
    }

    // Workbook
    $wbClean = preg_replace('/<(\/)?([a-zA-Z0-9]+:)/', '<$1', $zip->getFromName('xl/workbook.xml'));
    $wb = simplexml_load_string($wbClean);

    $relsClean = preg_replace('/<(\/)?([a-zA-Z0-9]+:)/', '<$1', $zip->getFromName('xl/_rels/workbook.xml.rels'));
    $rels = simplexml_load_string($relsClean);
    $relMap = [];
    foreach ($rels->Relationship as $rel) {
        $relMap[(string)$rel['Id']] = (string)$rel['Target'];
    }

    $targetFile = 'xl/worksheets/sheet1.xml';
    foreach ($wb->sheets->sheet as $s) {
        if (strcasecmp((string)$s['name'], $sheetName) === 0) {
            $rId = (string)$s['id'];
            if (!$rId) {
                // Check all attributes
                foreach ($s->attributes() as $attrName => $attrVal) {
                    if (str_ends_with((string)$attrName, 'id')) {
                        $rId = (string)$attrVal;
                    }
                }
            }
            $target = $relMap[$rId] ?? 'worksheets/sheet1.xml';
            $targetFile = str_starts_with($target, 'xl/') ? $target : 'xl/' . ltrim($target, '/');
            break;
        }
    }

    $sheetContent = $zip->getFromName($targetFile);
    if ($sheetContent === false) {
        throw new RuntimeException("Target sheet $targetFile not found in $filePath");
    }
    $sheetClean = preg_replace('/<(\/)?([a-zA-Z0-9]+:)/', '<$1', $sheetContent);
    $sheetXml = simplexml_load_string($sheetClean);

    $rows = [];
    foreach ($sheetXml->sheetData->row as $r) {
        $rowNum = (int)$r['r'];
        $rowCells = [];
        foreach ($r->c as $c) {
            $col = preg_replace('/\d/', '', (string)$c['r']);
            $val = '';
            $type = (string)$c['t'];
            if ($type === 's') {
                $idx = (int)$c->v;
                $val = $sharedStrings[$idx] ?? '';
            } else {
                $val = (string)($c->v ?? '');
            }
            $rowCells[$col] = $val;
        }
        $rows[$rowNum] = $rowCells;
    }
    $zip->close();
    return $rows;
}

$pdo = Database::getConnection();

// Load all visitors from DB
$dbStmt = $pdo->query("SELECT id, name, user_id, region, fincert FROM allowed_visitors");
$dbVisitors = [];
while ($row = $dbStmt->fetch(PDO::FETCH_ASSOC)) {
    $k = strtolower(trim($row['user_id']));
    $dbVisitors[$k] = $row;
}
echo "Total visitors in DB: " . count($dbVisitors) . "\n\n";

// 1. Check raw_data_AG.xlsx
echo "=== COMPARING AGAINST raw_data_AG.xlsx ===\n";
$agRows = parseXlsx(__DIR__ . '/../raw_data_AG.xlsx', 'sheet1');
// Row 1 header: A:sno, B:region, C:userid, D:schname, E:umname, F:desig, G:contact, H:emaild, I:fincert
$agCompared = 0;
$agMatches = 0;
$agMismatches = [];

for ($r = 2; $r <= max(array_keys($agRows)); $r++) {
    if (!isset($agRows[$r])) continue;
    $row = $agRows[$r];
    $uid = trim($row['C'] ?? '');
    if ($uid === '') continue;

    $agCompared++;
    $uidKey = strtolower($uid);
    $excelFincert = trim($row['I'] ?? '');
    
    if (!isset($dbVisitors[$uidKey])) {
        $agMismatches[] = [
            'row' => $r,
            'userid' => $uid,
            'reason' => 'Not found in DB',
            'excel_fincert' => $excelFincert,
            'db_fincert' => null
        ];
        continue;
    }

    $dbFincert = trim((string)($dbVisitors[$uidKey]['fincert'] ?? ''));

    // Special expected difference: Amrita Singh OS_927864 was intentionally set to empty per user instruction!
    if (strcasecmp($excelFincert, $dbFincert) === 0) {
        $agMatches++;
    } else {
        $agMismatches[] = [
            'row' => $r,
            'userid' => $uid,
            'name' => $dbVisitors[$uidKey]['name'],
            'excel_fincert' => $excelFincert,
            'db_fincert' => $dbFincert,
            'note' => ($uidKey === 'os_927864' ? 'Expected: FinCert cleared for Amrita Singh in previous prompt' : 'Mismatch')
        ];
    }
}

echo "raw_data_AG.xlsx compared: $agCompared\n";
echo "raw_data_AG.xlsx matches: $agMatches\n";
echo "raw_data_AG.xlsx mismatches: " . count($agMismatches) . "\n";
foreach ($agMismatches as $m) {
    echo "  - UserID: {$m['userid']} ({$m['name']}) | Excel: '{$m['excel_fincert']}' | DB: '{$m['db_fincert']}' | Note: {$m['note']}\n";
}

// 2. Check AG_Missing_Details_S.xlsx
echo "\n=== COMPARING AGAINST AG_Missing_Details_S.xlsx (Sheet: 'Missing Details') ===\n";
$missingRows = parseXlsx(__DIR__ . '/../AG_Missing_Details_S.xlsx', 'Missing Details');

// Find header row (expected row 5)
echo "Row 5 headers in Missing Details: " . json_encode($missingRows[5] ?? []) . "\n";
// Let's identify columns for User ID and FinCert
$headerRow = $missingRows[5] ?? [];
$uidCol = null;
$fcCol = null;
foreach ($headerRow as $col => $val) {
    if (stripos($val, 'user') !== false && stripos($val, 'id') !== false) {
        $uidCol = $col;
    }
    if (stripos($val, 'fincert') !== false || stripos($val, 'fin cert') !== false) {
        $fcCol = $col;
    }
}
echo "Detected User ID col: $uidCol ('" . ($headerRow[$uidCol] ?? '') . "'), FinCert col: $fcCol ('" . ($headerRow[$fcCol] ?? '') . "')\n";

$misCompared = 0;
$misMatches = 0;
$misMismatches = [];

for ($r = 6; $r <= max(array_keys($missingRows)); $r++) {
    if (!isset($missingRows[$r])) continue;
    $row = $missingRows[$r];
    $uid = trim($row[$uidCol] ?? '');
    if ($uid === '') continue;

    $misCompared++;
    $uidKey = strtolower($uid);
    $excelFincert = trim($row[$fcCol] ?? '');

    if (!isset($dbVisitors[$uidKey])) {
        $misMismatches[] = [
            'row' => $r,
            'userid' => $uid,
            'reason' => 'Not found in DB',
            'excel_fincert' => $excelFincert,
            'db_fincert' => null
        ];
        continue;
    }

    $dbFincert = trim((string)($dbVisitors[$uidKey]['fincert'] ?? ''));

    if (strcasecmp($excelFincert, $dbFincert) === 0) {
        $misMatches++;
    } else {
        $misMismatches[] = [
            'row' => $r,
            'userid' => $uid,
            'name' => $dbVisitors[$uidKey]['name'],
            'excel_fincert' => $excelFincert,
            'db_fincert' => $dbFincert,
            'note' => ($uidKey === 'os_927864' ? 'Expected: FinCert cleared for Amrita Singh in previous prompt' : 'Mismatch')
        ];
    }
}

echo "AG_Missing_Details_S.xlsx compared: $misCompared\n";
echo "AG_Missing_Details_S.xlsx matches: $misMatches\n";
echo "AG_Missing_Details_S.xlsx mismatches: " . count($misMismatches) . "\n";
foreach ($misMismatches as $m) {
    echo "  - UserID: {$m['userid']} ({$m['name']}) | Excel: '{$m['excel_fincert']}' | DB: '{$m['db_fincert']}' | Note: {$m['note']}\n";
}
