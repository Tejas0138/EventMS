<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

function testLoginAccount($user, $pass) {
    $cookieFile = __DIR__ . "/test_login_{$user}.txt";
    if (file_exists($cookieFile)) unlink($cookieFile);

    // 1. GET login page for CSRF
    $ch = curl_init('http://localhost:8080/EventMS/login.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    $html = curl_exec($ch);
    curl_close($ch);

    preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', $html, $matches);
    $csrf = $matches[1] ?? '';

    // 2. POST login credentials
    $ch = curl_init('http://localhost:8080/EventMS/login.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'csrf_token' => $csrf,
        'username' => $user,
        'password' => $pass
    ]));
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_HEADER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (file_exists($cookieFile)) unlink($cookieFile);

    $isRedirect = ($httpCode === 302 || $httpCode === 301);
    $isSuccess = $isRedirect && (stripos($response, 'Location: admin.php?tab=gift') !== false || stripos($response, 'Location: admin.php') !== false);
    return ['code' => $httpCode, 'success' => $isSuccess, 'response' => $response];
}

$accountsToTest = [
    'counter_raipur_chandigarh'             => 'RaipurChandigarh@2026',
    'counter_dehradun_lucknow'               => 'DehradunLucknow@2026',
    'counter_gurugram_guwahati'              => 'GurugramGuwahati@2026',
    'counter_chennai_vijayawada'             => 'ChennaiVijayawada@2026',
    'counter_panchkula_prayagraj_hyderabad' => 'PanchkulaPrayagrajHyderabad@2026',
    'counter_pune_1'                         => 'Pune@2026',
    'counter_pune_2'                         => 'Pune@2026',
    'counter_pune_3'                         => 'Pune@2026',
    'counter_pune_4'                         => 'Pune@2026',
    'counter_noida'                          => 'Noida@2026',
    'counter_bengaluru'                      => 'Bengaluru@2026',
    'counter_bhopal'                         => 'Bhopal@2026',
    'counter_bhubaneswar'                    => 'Bhubaneswar@2026',
    'counter_ajmer'                          => 'Ajmer@2026',
    'counter_ahmedabad'                      => 'Ahmedabad@2026',
    'counter_patna'                          => 'Patna@2026',
    'counter_trivandrum'                     => 'Trivandrum@2026',
    'counter_delhi_west'                     => 'DelhiWest@2026',
    'counter_delhi_east'                     => 'DelhiEast@2026',
    'counter_ranchi'                         => 'Ranchi@2026',
];

echo "=== TESTING LOGIN FOR ALL 20 ACTIVE REGIONAL COUNTERS ===\n";
$allOk = true;
foreach ($accountsToTest as $u => $p) {
    $res = testLoginAccount($u, $p);
    if ($res['success']) {
        echo "  [PASS] {$u} with password '{$p}' logged in successfully (HTTP {$res['code']} -> redirect).\n";
    } else {
        echo "  [FAIL] {$u} with password '{$p}' FAILED!\n";
        $allOk = false;
    }
}

// Test Pune alias (e.g. counter_pune_1 with Pune1@2026)
echo "\n--- TESTING BOOTH ALIAS (Pune1@2026 for counter_pune_1) ---\n";
$resAlias = testLoginAccount('counter_pune_1', 'Pune1@2026');
if ($resAlias['success']) {
    echo "  [PASS] counter_pune_1 with alias 'Pune1@2026' logged in successfully.\n";
} else {
    echo "  [FAIL] counter_pune_1 with alias 'Pune1@2026' FAILED!\n";
    $allOk = false;
}

// Test combined counter alias (e.g. counter_raipur_chandigarh with Raipur@2026)
echo "\n--- TESTING COMBINED BOOTH ALIAS (Raipur@2026 for counter_raipur_chandigarh) ---\n";
$resComb = testLoginAccount('counter_raipur_chandigarh', 'Raipur@2026');
if ($resComb['success']) {
    echo "  [PASS] counter_raipur_chandigarh with alias 'Raipur@2026' logged in successfully.\n";
} else {
    echo "  [FAIL] counter_raipur_chandigarh with alias 'Raipur@2026' FAILED!\n";
    $allOk = false;
}

// Test rate limiting on invalid password
echo "\n--- TESTING RATE LIMIT & LOCKOUT ON WRONG PASSWORD ---\n";
$dummyUser = 'counter_ranchi';
// Clear attempts first
$pdo->prepare("UPDATE admins SET failed_attempts = 0, locked_until = NULL WHERE username = ?")->execute([$dummyUser]);

// Attempt wrong password
$resWrong = testLoginAccount($dummyUser, 'WrongPassword123');
$failedAttempts = (int)$pdo->query("SELECT failed_attempts FROM admins WHERE username = '{$dummyUser}'")->fetchColumn();
echo "  After 1 wrong attempt: failed_attempts = {$failedAttempts}\n";
if ($failedAttempts === 1) {
    echo "  [PASS] Rate limit counter incremented properly on failure.\n";
} else {
    echo "  [FAIL] Rate limit counter not incremented!\n";
    $allOk = false;
}

// Reset dummyUser back to 0 failed attempts
$pdo->prepare("UPDATE admins SET failed_attempts = 0, locked_until = NULL WHERE username = ?")->execute([$dummyUser]);

echo "\n=======================================================\n";
echo $allOk ? "ALL LOGIN TESTS PASSED SUCCESSFULLY!\n" : "SOME LOGIN TESTS FAILED!\n";
echo "=======================================================\n";
