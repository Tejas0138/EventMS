<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$stmt = $pdo->query("SELECT id, name, user_id, is_gift_collected, gift_collected_at, handed_over_by, counter_region FROM gift_distribution WHERE is_gift_collected = 1");
$collected = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Collected gifts count: " . count($collected) . "\n";
foreach ($collected as $c) {
    echo "ID: {$c['id']}, Name: {$c['name']}, at: {$c['gift_collected_at']}, by: {$c['handed_over_by']}, region: {$c['counter_region']}\n";
}
