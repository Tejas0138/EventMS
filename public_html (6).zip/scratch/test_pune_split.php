<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$stmt = $pdo->query("SELECT id, name, user_id FROM allowed_visitors WHERE LOWER(TRIM(region)) = 'pune'");
$puneVisitors = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Pune count in allowed_visitors: " . count($puneVisitors) . "\n";

$stmt2 = $pdo->query("SELECT id, name, user_id FROM gift_distribution WHERE LOWER(TRIM(region)) = 'pune'");
$puneGift = $stmt2->fetchAll(PDO::FETCH_ASSOC);
echo "Pune count in gift_distribution: " . count($puneGift) . "\n";

// Function to clean name for sorting (ignoring titles)
function cleanNameForSort(string $name): string {
    $clean = trim($name);
    // Remove titles: Dr., Mr., Mrs., Ms., Prof., Sh., Smt., Shri
    $clean = preg_replace('/^(dr\.?|mr\.?|mrs\.?|ms\.?|prof\.?|sh\.?|smt\.?|shri\.?)\s+/i', '', $clean);
    return trim($clean);
}

usort($puneVisitors, function($a, $b) {
    $nameA = cleanNameForSort($a['name']);
    $nameB = cleanNameForSort($b['name']);
    $cmp = strcasecmp($nameA, $nameB);
    if ($cmp !== 0) return $cmp;
    return strcasecmp($a['name'], $b['name']);
});

$g1 = array_slice($puneVisitors, 0, 73);
$g2 = array_slice($puneVisitors, 73, 73);
$g3 = array_slice($puneVisitors, 146, 72);
$g4 = array_slice($puneVisitors, 218, 72);

echo "Group 1 count: " . count($g1) . " | First: " . $g1[0]['name'] . " | Last: " . end($g1)['name'] . "\n";
echo "Group 2 count: " . count($g2) . " | First: " . $g2[0]['name'] . " | Last: " . end($g2)['name'] . "\n";
echo "Group 3 count: " . count($g3) . " | First: " . $g3[0]['name'] . " | Last: " . end($g3)['name'] . "\n";
echo "Group 4 count: " . count($g4) . " | First: " . $g4[0]['name'] . " | Last: " . end($g4)['name'] . "\n";

echo "\nCheck prompt mention: 'Pune Counter 1 (names A to Chetan Sonawane, ~73 visitors)'\n";
echo "Group 1 Last name: " . end($g1)['name'] . "\n";
echo "Check prompt mention: 'Pune Counter 2 (Chetana Naik to Namira Contractor, ~73 visitors)'\n";
echo "Group 2 First name: " . $g2[0]['name'] . " | Last name: " . end($g2)['name'] . "\n";
echo "Group 3 First name: " . $g3[0]['name'] . " | Last name: " . end($g3)['name'] . "\n";
echo "Group 4 First name: " . $g4[0]['name'] . " | Last name: " . end($g4)['name'] . "\n";
