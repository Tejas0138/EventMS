<?php
require_once __DIR__ . '/../config/db.php';

$testTs = '2026-11-18 05:36:14';
$formatted = formatIST($testTs, 'd M Y, h:i A');
echo "Formatted: '$formatted'\n";
echo "Empty test: '" . formatIST('', 'd M Y, h:i A') . "'\n";
echo "Null test: '" . formatIST(null, 'd M Y, h:i A') . "'\n";
