<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== 1. Table Collations ===\n";
$tables = $pdo->query("SELECT TABLE_NAME, TABLE_COLLATION FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'eventms_db'")->fetchAll(PDO::FETCH_ASSOC);
$nonUtf8Tables = [];
foreach ($tables as $t) {
    if (!str_starts_with($t['TABLE_COLLATION'] ?? '', 'utf8mb4')) {
        $nonUtf8Tables[] = "{$t['TABLE_NAME']} ({$t['TABLE_COLLATION']})";
    }
    echo "Table {$t['TABLE_NAME']}: {$t['TABLE_COLLATION']}\n";
}

echo "\n=== 2. Check for Duplicate Register Ids (user_id) ===\n";
$dupReg = $pdo->query("SELECT user_id, COUNT(*) as cnt FROM allowed_visitors GROUP BY user_id HAVING cnt > 1")->fetchAll(PDO::FETCH_ASSOC);
echo "Duplicate user_ids in allowed_visitors: " . count($dupReg) . "\n";
if (!empty($dupReg)) {
    print_r($dupReg);
}

$dupGiftReg = $pdo->query("SELECT user_id, COUNT(*) as cnt FROM gift_distribution GROUP BY user_id HAVING cnt > 1")->fetchAll(PDO::FETCH_ASSOC);
echo "Duplicate user_ids in gift_distribution: " . count($dupGiftReg) . "\n";
if (!empty($dupGiftReg)) {
    print_r($dupGiftReg);
}

echo "\n=== 3. Check for Duplicate FinCerts ===\n";
$dupFin = $pdo->query("SELECT fincert, COUNT(*) as cnt FROM allowed_visitors WHERE fincert IS NOT NULL AND TRIM(fincert) != '' GROUP BY fincert HAVING cnt > 1")->fetchAll(PDO::FETCH_ASSOC);
echo "Duplicate non-empty FinCerts in allowed_visitors: " . count($dupFin) . "\n";
if (!empty($dupFin)) {
    print_r($dupFin);
}

$dupGiftFin = $pdo->query("SELECT fincert, COUNT(*) as cnt FROM gift_distribution WHERE fincert IS NOT NULL AND TRIM(fincert) != '' GROUP BY fincert HAVING cnt > 1")->fetchAll(PDO::FETCH_ASSOC);
echo "Duplicate non-empty FinCerts in gift_distribution: " . count($dupGiftFin) . "\n";
if (!empty($dupGiftFin)) {
    print_r($dupGiftFin);
}

echo "\n=== 4. Verify Trivandrum visitor and Amrita Singh ===\n";
$stmtSpecial = $pdo->query("SELECT id, name, user_id, region, fincert FROM allowed_visitors WHERE user_id IN ('OS_3071828', 'OS_927864')");
$specialRows = $stmtSpecial->fetchAll(PDO::FETCH_ASSOC);
foreach ($specialRows as $sr) {
    $isEmpty = empty(trim((string)$sr['fincert']));
    echo "Visitor: {$sr['name']} (ID: {$sr['user_id']}, Region: {$sr['region']}) | FinCert: '" . ($sr['fincert'] ?? '') . "' | Is Empty? " . ($isEmpty ? "YES" : "NO") . "\n";
}
