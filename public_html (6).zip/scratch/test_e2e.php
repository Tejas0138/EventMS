<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "============================================================\n";
echo "EVENTMS - E2E TEST: KIT ONLY AFTER GATE ENTRY FLOW\n";
echo "============================================================\n\n";

class TestClient {
    private string $baseUrl;
    private array $cookies = [];

    public function __construct(string $baseUrl) {
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    public function login(string $username, string $password): bool {
        $this->cookies = [];
        $getRes = $this->get('login.php');
        if (!preg_match('/name="csrf_token"\s+value="([^"]+)"/', $getRes['body'], $m)) {
            return false;
        }
        $csrf = $m[1];
        $postRes = $this->post('login.php', [
            'username' => $username,
            'password' => $password,
            'csrf_token' => $csrf,
        ]);
        return ($postRes['status'] === 302);
    }

    public function get(string $path, array $headers = []): array {
        return $this->request('GET', $path, null, $headers);
    }

    public function post(string $path, array $data = [], bool $asJson = false, array $headers = []): array {
        return $this->request('POST', $path, $data, $headers, $asJson);
    }

    private function request(string $method, string $path, ?array $data = null, array $headers = [], bool $asJson = false): array {
        $url = $this->baseUrl . '/' . ltrim($path, '/');
        $opts = [
            'http' => [
                'method' => $method,
                'ignore_errors' => true,
                'timeout' => 8,
            ]
        ];

        $reqHeaders = [];
        if ($data !== null) {
            if ($asJson) {
                $opts['http']['content'] = json_encode($data);
                $reqHeaders[] = 'Content-Type: application/json';
            } else {
                $opts['http']['content'] = http_build_query($data);
                $reqHeaders[] = 'Content-Type: application/x-www-form-urlencoded';
            }
        }

        foreach ($headers as $k => $v) {
            $reqHeaders[] = "{$k}: {$v}";
        }

        if (!empty($this->cookies)) {
            $c = [];
            foreach ($this->cookies as $k => $v) $c[] = "{$k}={$v}";
            $reqHeaders[] = 'Cookie: ' . implode('; ', $c);
        }

        $opts['http']['header'] = implode("\r\n", $reqHeaders);
        $ctx = stream_context_create($opts);
        $body = @file_get_contents($url, false, $ctx);
        $resHeaders = $http_response_header ?? [];

        $this->parseCookies($resHeaders);
        $statusCode = $this->parseStatusCode($resHeaders);

        return [
            'status' => $statusCode,
            'body' => $body ?: '',
            'headers' => $resHeaders,
            'json' => json_decode($body ?: '', true),
        ];
    }

    private function parseCookies(array $headers): void {
        foreach ($headers as $h) {
            if (stripos($h, 'Set-Cookie:') === 0) {
                $parts = explode(';', substr($h, 11));
                $nv = explode('=', trim($parts[0]), 2);
                if (count($nv) === 2) {
                    $this->cookies[trim($nv[0])] = trim($nv[1]);
                }
            }
        }
    }

    private function parseStatusCode(array $headers): int {
        if (!empty($headers[0]) && preg_match('#HTTP/\S+\s+(\d+)#', $headers[0], $m)) {
            return (int)$m[1];
        }
        return 0;
    }
}

$client = new TestClient('http://localhost:8080/EventMS');

// Take snapshot of database state
$snapshotVisitors = $pdo->query("SELECT id, user_id, is_day1_checked_in, day1_checked_in_at, is_day2_checked_in, day2_checked_in_at, is_checked_in, checked_in_at FROM allowed_visitors")->fetchAll(PDO::FETCH_ASSOC);
$snapshotGifts = $pdo->query("SELECT id, user_id, is_gift_collected, gift_collected_at, handed_over_by, counter_region, counter_id FROM gift_distribution")->fetchAll(PDO::FETCH_ASSOC);

$pass = 0;
$fail = 0;

function check(bool $cond, string $msg) {
    global $pass, $fail;
    if ($cond) {
        $pass++;
        echo "  [PASS] {$msg}\n";
    } else {
        $fail++;
        echo "  [FAIL] {$msg}\n";
    }
}

try {
    // =========================================================
    // TEST 1: VISITOR WITH NO GATE ENTRY
    // =========================================================
    echo "--- TEST 1: Visitor with no gate entry ---\n";

    // Pick unentered visitor
    $unentered = $pdo->query("
        SELECT g.*, a.is_day1_checked_in, a.is_day2_checked_in
        FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.is_gift_collected = 0 AND a.is_day1_checked_in = 0 AND a.is_day2_checked_in = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);

    echo "Target unentered visitor: {$unentered['name']} (ID: {$unentered['id']}, User ID: {$unentered['user_id']}, Mobile: {$unentered['mobile']})\n";

    // 1A. COE Kit Terminal refuses handover
    $cRow = $pdo->query("SELECT username FROM counters WHERE id = {$unentered['counter_id']}")->fetch(PDO::FETCH_ASSOC);
    $cUser = $cRow['username'];
    // Lookup password from CSV
    $csvLines = file(__DIR__ . '/../counter_credentials.csv');
    $cPwd = '';
    foreach ($csvLines as $line) {
        $cols = str_getcsv($line);
        if ($cols[1] === $cUser) {
            $cPwd = $cols[2];
            break;
        }
    }

    $loginOk = $client->login($cUser, $cPwd);
    check($loginOk, "Logged in to terminal as assigned counter user ({$cUser})");

    // Submit visitor to gift terminal via AJAX
    $termRes = $client->post('gift.php', ['identifier' => $unentered['user_id']], true, [
        'X-Requested-With' => 'XMLHttpRequest',
        'Accept' => 'application/json'
    ]);
    check($termRes['status'] === 200, "Terminal returned HTTP 200 response");
    check(($termRes['json']['status'] ?? '') === 'not_entered', "Terminal status is 'not_entered'");
    $expectedWarning = "{$unentered['name']}, your gate entry is not done yet. Please complete entry at the gate first, then come back for your COE Kit.";
    check(($termRes['json']['message'] ?? '') === $expectedWarning, "Terminal returned exact required warning message");

    // Verify nothing recorded in DB
    $dbColl = $pdo->query("SELECT is_gift_collected FROM gift_distribution WHERE id = {$unentered['id']}")->fetchColumn();
    check((int)$dbColl === 0, "Database is_gift_collected remains 0 (nothing recorded)");

    // 1B. Table Row UI rendering: disabled pill "Not Entered" and Kit Status badge "Not Entered"
    $pageRes = $client->get('admin.php?tab=gift&dfilter=all');
    check(strpos($pageRes['body'], 'btn-not-entered') !== false, "Gift page renders disabled 'Not Entered' action button");
    check(strpos($pageRes['body'], 'pill-not-entered') !== false, "Gift page renders 'Not Entered' status badge");

    // 1C. Direct request to give-kit endpoint refused by server as Counter Staff
    $tamperCounter = $client->get("admin.php?tab=gift&action=mark_given&id={$unentered['id']}", [
        'X-Requested-With' => 'XMLHttpRequest'
    ]);
    check($tamperCounter['status'] === 400, "Counter user direct give-kit request returns HTTP 400");
    check(($tamperCounter['json']['error'] ?? '') === 'Gate entry required: Visitor has not checked in at the gate yet.', "Error message confirms gate entry required");
    $dbColl = $pdo->query("SELECT is_gift_collected FROM gift_distribution WHERE id = {$unentered['id']}")->fetchColumn();
    check((int)$dbColl === 0, "Database is_gift_collected remains 0 after counter give-kit attempt");

    // 1D. Direct request to give-kit endpoint refused by server as Super Admin
    $adminLogin = $client->login('admin', 'admin123');
    check($adminLogin, "Logged in as Super Admin (admin)");

    $tamperAdmin = $client->get("admin.php?tab=gift&action=mark_given&id={$unentered['id']}", [
        'X-Requested-With' => 'XMLHttpRequest'
    ]);
    check($tamperAdmin['status'] === 400, "Super Admin direct give-kit request returns HTTP 400");
    check(($tamperAdmin['json']['error'] ?? '') === 'Gate entry required: Visitor has not checked in at the gate yet.', "Super Admin blocked: Gate entry required");
    $dbColl = $pdo->query("SELECT is_gift_collected FROM gift_distribution WHERE id = {$unentered['id']}")->fetchColumn();
    check((int)$dbColl === 0, "Database is_gift_collected remains 0 after Super Admin attempt");


    // =========================================================
    // TEST 2: CHECK-IN AND REGION-WISE COUNTER APPEARANCE
    // =========================================================
    echo "\n--- TEST 2: Check-in and Region-wise counter appearance ---\n";

    // 2A. Lucknow Visitor (assigned to Dehradun / Lucknow Counter, id = 2)
    $lucknow = $pdo->query("
        SELECT g.*, a.id as a_id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Lucknow' AND g.counter_id = 2 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    echo "Lucknow Visitor: {$lucknow['name']} (ID: {$lucknow['id']})\n";

    // Check in at Day 1 gate
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$lucknow['a_id']}");

    // Log in as counter_dehradun_lucknow
    $client->login('counter_dehradun_lucknow', 'DehradunLucknow@2026');
    $pollLucknow = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check($pollLucknow['status'] === 200, "Live polling as counter_dehradun_lucknow succeeded");
    check(strpos($pollLucknow['json']['rowsHtml'] ?? '', $lucknow['name']) !== false, "Lucknow visitor appears in 'Entered' tab of Dehradun / Lucknow Counter");
    check(strpos($pollLucknow['json']['rowsHtml'] ?? '', 'btn-mark-given') !== false, "Give Kit button is now active for Lucknow visitor");

    // Log in as counter_noida
    $client->login('counter_noida', 'Noida@2026');
    $pollNoida = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check(strpos($pollNoida['json']['rowsHtml'] ?? '', $lucknow['name']) === false, "Lucknow visitor does NOT appear in Noida Counter");

    // 2B. Raipur Visitor (assigned to Raipur / Chandigarh Counter, id = 1)
    $raipur = $pdo->query("
        SELECT g.*, a.id as a_id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Raipur' AND g.counter_id = 1 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$raipur['a_id']}");

    $client->login('counter_raipur_chandigarh', 'RaipurChandigarh@2026');
    $pollRaipur = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check(strpos($pollRaipur['json']['rowsHtml'] ?? '', $raipur['name']) !== false, "Raipur visitor appears in Raipur / Chandigarh Counter");

    $client->login('counter_noida', 'Noida@2026');
    $pollNoida2 = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check(strpos($pollNoida2['json']['rowsHtml'] ?? '', $raipur['name']) === false, "Raipur visitor does NOT appear in Noida Counter");

    // 2C. Pune Visitor (Pune Counter 1, counter_id = 6)
    $pune = $pdo->query("
        SELECT g.*, a.id as a_id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Pune' AND g.counter_id = 6 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$pune['a_id']}");

    $client->login('counter_pune_1', 'Pune@2026');
    $pollPune1 = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check(strpos($pollPune1['json']['rowsHtml'] ?? '', $pune['name']) !== false, "Pune visitor appears in assigned Pune Counter 1");

    $client->login('counter_pune_2', 'Pune@2026');
    $pollPune2 = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check(strpos($pollPune2['json']['rowsHtml'] ?? '', $pune['name']) === false, "Pune visitor does NOT appear in Pune Counter 2");

    // 2D. Noida Visitor (Noida Counter, counter_id = 10)
    $noida = $pdo->query("
        SELECT g.*, a.id as a_id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.region = 'Noida' AND g.counter_id = 10 AND g.is_gift_collected = 0
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 1, day1_checked_in_at = UTC_TIMESTAMP() WHERE id = {$noida['a_id']}");

    $client->login('counter_noida', 'Noida@2026');
    $pollNoida3 = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check(strpos($pollNoida3['json']['rowsHtml'] ?? '', $noida['name']) !== false, "Noida visitor appears in Noida Counter");

    // 2E. Day 2 only check-in
    $d2 = $pdo->query("
        SELECT g.*, a.id as a_id FROM gift_distribution g
        JOIN allowed_visitors a ON a.user_id = g.user_id
        WHERE g.counter_id = 10 AND g.is_gift_collected = 0 AND g.id != {$noida['id']}
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 0, is_day2_checked_in = 1, day2_checked_in_at = UTC_TIMESTAMP() WHERE id = {$d2['a_id']}");
    $pollD2 = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    check(strpos($pollD2['json']['rowsHtml'] ?? '', $d2['name']) !== false, "Visitor with Day 2 check-in ONLY appears in Entered tab and Give Kit is active");


    // =========================================================
    // TEST 3: GIVE KIT & RESET KIT METRICS AND INVARIANTS
    // =========================================================
    echo "\n--- TEST 3: Give kit & reset kit metrics and mathematical invariants ---\n";

    // Counter user: counter_dehradun_lucknow
    $client->login('counter_dehradun_lucknow', 'DehradunLucknow@2026');

    $resB = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    $mBefore = $resB['json']['metrics'] ?? [];
    echo "Initial metrics for counter: Given={$mBefore['giftsGiven']}, Pending={$mBefore['giftsPending']}, Entered={$mBefore['giftsEntered']}, NotEntered={$mBefore['giftsNotEntered']}, Total={$mBefore['totalGiftElig']}\n";

    check((int)$mBefore['giftsPending'] === ((int)$mBefore['giftsEntered'] + (int)$mBefore['giftsNotEntered']), "Invariant: Pending = Entered + Not Entered ({$mBefore['giftsPending']} = {$mBefore['giftsEntered']} + {$mBefore['giftsNotEntered']})");
    check((int)$mBefore['totalGiftElig'] === ((int)$mBefore['giftsGiven'] + (int)$mBefore['giftsPending']), "Invariant: All = Kit Collected + Pending ({$mBefore['totalGiftElig']} = {$mBefore['giftsGiven']} + {$mBefore['giftsPending']})");

    // Give Kit to lucknow visitor
    $giveRes = $client->get("admin.php?tab=gift&action=mark_given&id={$lucknow['id']}", [
        'X-Requested-With' => 'XMLHttpRequest'
    ]);
    check($giveRes['status'] === 200 && ($giveRes['json']['success'] ?? false) === true, "Give kit action succeeded via AJAX");

    $resA = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    $mAfterGive = $resA['json']['metrics'] ?? [];
    echo "After give: Given={$mAfterGive['giftsGiven']}, Pending={$mAfterGive['giftsPending']}, Entered={$mAfterGive['giftsEntered']}, NotEntered={$mAfterGive['giftsNotEntered']}\n";

    check((int)$mAfterGive['giftsGiven'] === ((int)$mBefore['giftsGiven'] + 1), "Kit Collected increased by 1 immediately");
    check((int)$mAfterGive['giftsPending'] === ((int)$mBefore['giftsPending'] - 1), "Pending Kits decreased by 1 immediately");
    check((int)$mAfterGive['giftsEntered'] === ((int)$mBefore['giftsEntered'] - 1), "Entered tab count decreased by 1 immediately");
    check((int)$mAfterGive['giftsPending'] === ((int)$mAfterGive['giftsEntered'] + (int)$mAfterGive['giftsNotEntered']), "Invariant holds after Give: Pending = Entered + Not Entered");
    check((int)$mAfterGive['totalGiftElig'] === ((int)$mAfterGive['giftsGiven'] + (int)$mAfterGive['giftsPending']), "Invariant holds after Give: All = Kit Collected + Pending");

    // Reset Kit for lucknow visitor
    $resetRes = $client->get("admin.php?tab=gift&action=reset_gift&id={$lucknow['id']}", [
        'X-Requested-With' => 'XMLHttpRequest'
    ]);
    check($resetRes['status'] === 200, "Reset kit action succeeded via AJAX");

    $resR = $client->get('admin.php?tab=gift&dfilter=entered&ajax_live=1');
    $mAfterReset = $resR['json']['metrics'] ?? [];
    echo "After reset: Given={$mAfterReset['giftsGiven']}, Pending={$mAfterReset['giftsPending']}, Entered={$mAfterReset['giftsEntered']}, NotEntered={$mAfterReset['giftsNotEntered']}\n";

    check((int)$mAfterReset['giftsGiven'] === (int)$mBefore['giftsGiven'], "Kit Collected decreased by 1 on reset");
    check((int)$mAfterReset['giftsPending'] === (int)$mBefore['giftsPending'], "Pending Kits increased by 1 on reset");
    check((int)$mAfterReset['giftsPending'] === ((int)$mAfterReset['giftsEntered'] + (int)$mAfterReset['giftsNotEntered']), "Invariant holds after Reset: Pending = Entered + Not Entered");
    check((int)$mAfterReset['totalGiftElig'] === ((int)$mAfterReset['giftsGiven'] + (int)$mAfterReset['giftsPending']), "Invariant holds after Reset: All = Kit Collected + Pending");


    // =========================================================
    // TEST 4: TAMPERED KIT REQUEST FOR VISITOR OF ANOTHER COUNTER
    // =========================================================
    echo "\n--- TEST 4: Tampered kit request for visitor of another counter ---\n";

    // counter_noida tries to give kit to lucknow visitor (counter_id = 2)
    $client->login('counter_noida', 'Noida@2026');
    $tamperCross = $client->get("admin.php?tab=gift&action=mark_given&id={$lucknow['id']}", [
        'X-Requested-With' => 'XMLHttpRequest'
    ]);
    check($tamperCross['status'] === 403, "Tampered request for visitor of another counter returns HTTP 403");
    check(($tamperCross['json']['error'] ?? '') === 'Permission denied: This attendee belongs to another region counter.', "Error message confirms permission denied");


    // =========================================================
    // TEST 5: ALREADY COLLECTED KITS UNCHANGED
    // =========================================================
    echo "\n--- TEST 5: Already collected kits unchanged ---\n";

    // Mark lucknow visitor collected
    $pdo->exec("UPDATE gift_distribution SET is_gift_collected = 1, gift_collected_at = UTC_TIMESTAMP(), handed_over_by = 'admin', counter_region = 'Dehradun / Lucknow Counter' WHERE id = {$lucknow['id']}");

    // Reset gate check-in
    $pdo->exec("UPDATE allowed_visitors SET is_day1_checked_in = 0, day1_checked_in_at = NULL WHERE id = {$lucknow['a_id']}");

    // Verify kit remains collected
    $kitCheck = $pdo->query("SELECT is_gift_collected FROM gift_distribution WHERE id = {$lucknow['id']}")->fetchColumn();
    check((int)$kitCheck === 1, "Resetting gate check-in does not remove an already given kit (is_gift_collected remains 1)");

} finally {
    // =========================================================
    // TEST 6: RESTORE ALL TEST DATA
    // =========================================================
    echo "\n--- TEST 6: Restoring original snapshot data ---\n";

    $restoreVisitors = $pdo->prepare("
        UPDATE allowed_visitors 
        SET is_day1_checked_in = :d1, day1_checked_in_at = :d1_at,
            is_day2_checked_in = :d2, day2_checked_in_at = :d2_at,
            is_checked_in = :ci, checked_in_at = :ci_at
        WHERE id = :id
    ");
    foreach ($snapshotVisitors as $sv) {
        $restoreVisitors->execute([
            ':id'    => $sv['id'],
            ':d1'    => $sv['is_day1_checked_in'],
            ':d1_at' => $sv['day1_checked_in_at'],
            ':d2'    => $sv['is_day2_checked_in'],
            ':d2_at' => $sv['day2_checked_in_at'],
            ':ci'    => $sv['is_checked_in'],
            ':ci_at' => $sv['checked_in_at'],
        ]);
    }

    $restoreGifts = $pdo->prepare("
        UPDATE gift_distribution
        SET is_gift_collected = :coll, gift_collected_at = :coll_at,
            handed_over_by = :who, counter_region = :creg, counter_id = :cid
        WHERE id = :id
    ");
    foreach ($snapshotGifts as $sg) {
        $restoreGifts->execute([
            ':id'      => $sg['id'],
            ':coll'    => $sg['is_gift_collected'],
            ':coll_at' => $sg['gift_collected_at'],
            ':who'     => $sg['handed_over_by'],
            ':creg'    => $sg['counter_region'],
            ':cid'     => $sg['counter_id'],
        ]);
    }

    echo "All visitor and gift records successfully restored to initial snapshot.\n";
}

echo "\n============================================================\n";
echo "FINAL RESULTS: {$pass} PASSED, {$fail} FAILED\n";
echo "============================================================\n";
