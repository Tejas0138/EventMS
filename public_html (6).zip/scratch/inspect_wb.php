<?php
declare(strict_types=1);

$zip = new ZipArchive();
$zip->open(__DIR__ . '/../AG_Missing_Details_S.xlsx');
$wbXml = $zip->getFromName('xl/workbook.xml');
echo "Workbook XML: " . $wbXml . "\n\n";

$s1Xml = $zip->getFromName('xl/worksheets/sheet1.xml');
echo "Sheet1 sample (first 1000 chars):\n" . substr($s1Xml, 0, 1000) . "\n";
$zip->close();
