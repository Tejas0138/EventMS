<?php
require_once 'c:/xampp/htdocs/EventMS_loadtest/config/db.php';
$pdo = Database::getConnection();
$cols = $pdo->query("DESCRIBE rate_limits")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($cols, JSON_PRETTY_PRINT);
