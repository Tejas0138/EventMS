<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== counter_reassignment_log cols ===\n";
foreach ($pdo->query('DESCRIBE counter_reassignment_log')->fetchAll(PDO::FETCH_ASSOC) as $c) {
    echo "  {$c['Field']} ({$c['Type']})\n";
}
