<?php
require_once __DIR__ . '/../config/db.php';
$baseUrl = 'http://localhost:8080/EventMS';
$cookieFile = __DIR__ . '/test_admin_cookie.txt';

$ch = curl_init("$baseUrl/login.php");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR      => $cookieFile,
    CURLOPT_COOKIEFILE     => $cookieFile,
]);
$html = curl_exec($ch);
preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', (string)$html, $m);
$token = $m[1] ?? '';

curl_setopt_array($ch, [
    CURLOPT_POST       => true,
    CURLOPT_POSTFIELDS => http_build_query([
        'csrf_token' => $token,
        'username'   => 'admin',
        'password'   => 'admin123'
    ]),
    CURLOPT_FOLLOWLOCATION => true
]);
curl_exec($ch);

// GET gate page
curl_setopt_array($ch, [
    CURLOPT_URL => "$baseUrl/admin.php?tab=gate",
    CURLOPT_POST => false,
    CURLOPT_HTTPGET => true,
    CURLOPT_FOLLOWLOCATION => true
]);
$page = curl_exec($ch);
curl_close($ch);

// Find btnGateTabExport HTML
preg_match('/<div class="filter-btn-group">.*?<\/div>/s', $page, $match);
echo "=== FILTER BTN GROUP HTML ===\n";
echo $match[0] ?? 'NOT FOUND';
echo "\n";
