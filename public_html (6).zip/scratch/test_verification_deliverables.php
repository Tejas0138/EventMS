<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$_SESSION['admin_logged_in'] = true;
$_SESSION['user_role'] = 'super_admin';
$_SESSION['admin_username'] = 'master_admin';

require_once __DIR__ . '/../config/db.php';

// If renderGateTableRows is not yet loaded, we can require or declare it
if (!function_exists('renderGateTableRows')) {
    // Extract renderGateTableRows from admin.php
    $adminSource = file_get_contents(__DIR__ . '/../admin.php');
    preg_match('/function renderGateTableRows\(.*?\n\}\n/s', $adminSource, $m);
    if (!empty($m[0])) {
        eval($m[0]);
    }
}

$pdo = Database::getConnection();

echo "====================================================\n";
echo "CHECK 2: PICK 5 VISITORS AND VERIFY FINCERT IN HTML\n";
echo "====================================================\n";

// Target visitors:
// 1. One Pune visitor: e.g. OS_1278805 (Aparna Sunil Morris)
// 2. One like "akshitabahuguna": search for akshita in DB
// 3. Suchita Mishra (OS_939962)
// 4. Amrita Singh (OS_927864)
// 5. One other (e.g. OS_3071828 Shibili C K M or another)

$akshitaStmt = $pdo->query("SELECT * FROM allowed_visitors WHERE name LIKE '%akshita%' OR user_id LIKE '%akshita%' LIMIT 1");
$akshita = $akshitaStmt->fetch(PDO::FETCH_ASSOC);

$puneStmt = $pdo->query("SELECT * FROM allowed_visitors WHERE region = 'Pune' AND fincert != '' LIMIT 1");
$puneVisitor = $puneStmt->fetch(PDO::FETCH_ASSOC);

$suchitaStmt = $pdo->query("SELECT * FROM allowed_visitors WHERE user_id = 'OS_939962' LIMIT 1");
$suchita = $suchitaStmt->fetch(PDO::FETCH_ASSOC);

$amritaStmt = $pdo->query("SELECT * FROM allowed_visitors WHERE user_id = 'OS_927864' LIMIT 1");
$amrita = $amritaStmt->fetch(PDO::FETCH_ASSOC);

$otherStmt = $pdo->query("SELECT * FROM allowed_visitors WHERE user_id = 'OS_3071828' LIMIT 1");
$other = $otherStmt->fetch(PDO::FETCH_ASSOC);

$testVisitors = [
    'Pune Visitor' => $puneVisitor,
    'Akshita Bahuguna' => $akshita,
    'Suchita Mishra' => $suchita,
    'Amrita Singh' => $amrita,
    'Other (OS_3071828)' => $other
];

foreach ($testVisitors as $label => $v) {
    if (!$v) {
        echo "FAIL: $label not found in DB\n";
        continue;
    }
    // Render single row
    $html = renderGateTableRows([$v], '', '', '', 1, 0);

    // Extract rendered fincert from HTML
    // Looking for <td class="td-fincert col-fincert">...<span class="user-id-badge fincert-badge"...>(.*?)</span>
    preg_match('/<td[^>]*class="[^"]*col-fincert[^"]*"[^>]*>.*?<span[^>]*class="[^"]*fincert-badge[^"]*"[^>]*>(.*?)<\/span>/s', $html, $matches);
    $renderedFc = isset($matches[1]) ? trim($matches[1]) : 'NOT FOUND';

    $expectedFc = trim((string)($v['fincert'] ?? ''));
    if ($expectedFc === '') {
        $expectedFc = '-';
    }

    $pass = ($renderedFc === $expectedFc);
    echo "[$label]\n";
    echo "  Name: {$v['name']} | User ID: {$v['user_id']} | Region: {$v['region']}\n";
    echo "  DB Stored FinCert: '{$v['fincert']}'\n";
    echo "  Rendered in Gate Table: '$renderedFc'\n";
    echo "  Expected: '$expectedFc'\n";
    echo "  Status: " . ($pass ? "PASS" : "FAIL") . "\n\n";
}

echo "====================================================\n";
echo "CHECK 3: INTEGRITY ACROSS SEARCH, TABS, REGION, PAGINATION, SORT\n";
echo "====================================================\n";

// Load full gate visitors dataset like admin.php does
$stmt = $pdo->query("SELECT * FROM allowed_visitors");
$allGateVisitors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Test 3a: Search by name or user_id
echo "--- 3a. Search test: 'Mishra' ---\n";
$searchQuery = 'Mishra';
$filtered = array_filter($allGateVisitors, function($v) use ($searchQuery) {
    return (stripos($v['name'], $searchQuery) !== false || stripos($v['user_id'], $searchQuery) !== false);
});
$rendered = renderGateTableRows(array_values($filtered), 'all', $searchQuery, '', 1, 0);
// Check Suchita Mishra row in rendered HTML
if (strpos($rendered, 'SUCHITA MISHRA') !== false && strpos($rendered, 'NTC-2026/BSR/0051') !== false) {
    echo "PASS: Search preserves Suchita Mishra -> NTC-2026/BSR/0051\n";
} else {
    echo "FAIL: Suchita Mishra or fincert missing in search\n";
}

// Test 3b: Region filter 'Pune'
echo "--- 3b. Region filter: 'Pune' ---\n";
$puneFiltered = array_filter($allGateVisitors, function($v) {
    return (strcasecmp($v['region'], 'Pune') === 0);
});
$renderedPune = renderGateTableRows(array_slice(array_values($puneFiltered), 0, 10), 'all', '', 'Pune', 1, 0);
// Every row in renderedPune should match its corresponding visitor in puneFiltered
$puneSlice = array_slice(array_values($puneFiltered), 0, 10);
$allMatch = true;
foreach ($puneSlice as $pv) {
    $expectedFc = trim((string)($pv['fincert'] ?? '')) ?: '-';
    // Verify name and fincert appear in row
    $escapedName = htmlspecialchars($pv['name']);
    $escapedFc = htmlspecialchars($expectedFc);
    if (strpos($renderedPune, $escapedName) === false || strpos($renderedPune, $escapedFc) === false) {
        $allMatch = false;
        echo "FAIL: Mismatch for {$pv['name']}\n";
    }
}
if ($allMatch) {
    echo "PASS: Region filter maintains 100% correct 1-to-1 binding between visitor and FinCert\n";
}

// Test 3c: Tab switching (e.g. pending_both)
echo "--- 3c. Tab filter: 'pending_both' ---\n";
$pendingFiltered = array_filter($allGateVisitors, function($v) {
    return ((int)($v['is_day1_checked_in'] ?? 0) === 0 && (int)($v['is_day2_checked_in'] ?? 0) === 0);
});
$pendingSlice = array_slice(array_values($pendingFiltered), 0, 10);
$renderedPending = renderGateTableRows($pendingSlice, 'pending_both', '', '', 1, 0);
$allPendingMatch = true;
foreach ($pendingSlice as $pv) {
    $expectedFc = trim((string)($pv['fincert'] ?? '')) ?: '-';
    if (strpos($renderedPending, htmlspecialchars($pv['name'])) === false || strpos($renderedPending, htmlspecialchars($expectedFc)) === false) {
        $allPendingMatch = false;
        echo "FAIL: Mismatch for pending visitor {$pv['name']}\n";
    }
}
if ($allPendingMatch) {
    echo "PASS: Tab filter maintains 100% correct 1-to-1 binding between visitor and FinCert\n";
}

// Test 3d: Pagination (Page 2)
echo "--- 3d. Pagination: Page 2 (offset 25) ---\n";
$page2Visitors = array_slice($allGateVisitors, 25, 25);
$renderedPage2 = renderGateTableRows($page2Visitors, 'all', '', '', 2, 25);
$allP2Match = true;
foreach ($page2Visitors as $pv) {
    $expectedFc = trim((string)($pv['fincert'] ?? '')) ?: '-';
    if (strpos($renderedPage2, htmlspecialchars($pv['name'])) === false || strpos($renderedPage2, htmlspecialchars($expectedFc)) === false) {
        $allP2Match = false;
        echo "FAIL: Mismatch on page 2 for {$pv['name']}\n";
    }
}
if ($allP2Match) {
    echo "PASS: Page 2 pagination maintains 100% correct 1-to-1 binding between visitor and FinCert\n";
}

// Test 3e: Sorting and Check-In
echo "--- 3e. Sorting & Check-in simulation with sortGateVisitors() ---\n";
// Clone dataset, simulate check-in on Suchita Mishra, Amrita Singh, and a Pune visitor
$simVisitors = $allGateVisitors;
foreach ($simVisitors as &$sv) {
    if ($sv['user_id'] === 'OS_939962') {
        $sv['is_day1_checked_in'] = 1;
        $sv['day1_checked_in_at'] = '2026-11-18 10:15:00';
    }
    if ($sv['user_id'] === 'OS_927864') {
        $sv['is_day2_checked_in'] = 1;
        $sv['day2_checked_in_at'] = '2026-11-18 10:20:00';
    }
}
unset($sv);

// Call sortGateVisitors
sortGateVisitors($simVisitors);

// Render top 10 rows
$renderedSorted = renderGateTableRows(array_slice($simVisitors, 0, 10), 'all', '', '', 1, 0);

// Verify Suchita Mishra is in top 10 and has NTC-2026/BSR/0051
// Verify Amrita Singh is in top 10 and has -
$topSlice = array_slice($simVisitors, 0, 10);
$allSortedMatch = true;
foreach ($topSlice as $tsv) {
    $expectedFc = trim((string)($tsv['fincert'] ?? '')) ?: '-';
    if (strpos($renderedSorted, htmlspecialchars($tsv['name'])) === false || strpos($renderedSorted, htmlspecialchars($expectedFc)) === false) {
        $allSortedMatch = false;
        echo "FAIL: Mismatch after re-sorting for {$tsv['name']}\n";
    }
}
if ($allSortedMatch) {
    echo "PASS: Re-sorting keeps FinCert 100% bound to visitor row (no index shift or misattribution)\n";
}

echo "\n====================================================\n";
echo "CHECK 4: CSS AND LAYOUT VERIFICATION\n";
echo "====================================================\n";

$adminContent = file_get_contents(__DIR__ . '/../admin.php');

// Desktop table width:
if (preg_match('/\.crisp-table\.table-gate\s*\{\s*min-width:\s*1624px;/s', $adminContent)) {
    echo "PASS: Desktop table min-width 1624px configured\n";
} else {
    echo "FAIL: Desktop table min-width 1624px missing\n";
}

// Name width 220px:
if (preg_match('/\.table-gate\s+\.col-name\s*\{\s*width:\s*220px\s*!important;\s*min-width:\s*220px\s*!important;\s*max-width:\s*220px\s*!important;\s*text-align:\s*left\s*!important;/s', $adminContent)) {
    echo "PASS: Name column set to 220px (reduced by 40px from 260px)\n";
} else {
    echo "FAIL: Name column 220px missing\n";
}

// FinCert column width 190px and padding 12px:
if (preg_match('/\.col-fincert\s*\{\s*width:\s*190px\s*!important;\s*min-width:\s*190px\s*!important;\s*max-width:\s*190px\s*!important;\s*text-align:\s*left\s*!important;\s*padding-left:\s*12px\s*!important;\s*padding-right:\s*12px\s*!important;/s', $adminContent)) {
    echo "PASS: FinCert column width 190px, left-aligned, 12px padding configured\n";
} else {
    echo "FAIL: FinCert column 190px styling missing\n";
}

// Mobile grid styling:
if (strpos($adminContent, '"fc     fc"') !== false && strpos($adminContent, 'grid-area: fc;') !== false) {
    echo "PASS: Mobile card grid includes 'fc fc' area and .td-fincert has grid-area: fc\n";
} else {
    echo "FAIL: Mobile card grid missing fc area\n";
}

// Mobile break-all / overflow-wrap:
if (preg_match('/word-break:\s*break-all\s*!important;\s*overflow-wrap:\s*anywhere\s*!important;/s', $adminContent)) {
    echo "PASS: Mobile FinCert badge has word-break: break-all and overflow-wrap: anywhere\n";
} else {
    echo "FAIL: Mobile FinCert badge word-break missing\n";
}

echo "\nAll verification checks executed successfully!\n";
