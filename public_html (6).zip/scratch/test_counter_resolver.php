<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

function testResolve($region, $name) {
    global $pdo;
    $norm = trim($region);
    $lower = mb_strtolower($norm, 'UTF-8');

    if ($lower === 'pune') {
        $clean = trim($name);
        $clean = preg_replace('/^(dr\.?|mr\.?|mrs\.?|ms\.?|prof\.?|sh\.?|smt\.?|shri\.?)\s+/i', '', $clean);
        $sortName = trim($clean);

        if (strcasecmp($sortName, 'Chetan Sonawane') <= 0) {
            $code = 'pune_1';
        } elseif (strcasecmp($sortName, 'Namira Yunus Contractor') <= 0) {
            $code = 'pune_2';
        } elseif (strcasecmp($sortName, 'Sangeeta Rautji') <= 0) {
            $code = 'pune_3';
        } else {
            $code = 'pune_4';
        }

        $stmt = $pdo->prepare("SELECT id, name, code, name_range FROM counters WHERE code = ? AND is_active = 1");
        $stmt->execute([$code]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    $stmt = $pdo->prepare("
        SELECT c.id, c.name, c.code, c.name_range
        FROM counter_regions cr
        JOIN counters c ON c.id = cr.counter_id
        WHERE LOWER(TRIM(cr.region)) = :reg AND c.is_active = 1
        LIMIT 1
    ");
    $stmt->execute([':reg' => $lower]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

$tests = [
    ['Trivandrum', 'Suresh Kumar'],
    ['Pune', 'Aarti Bhujbal'],
    ['Pune', 'Dr. Chetan Sonawane'],
    ['Pune', 'Chetana Naik'],
    ['Pune', 'Pallavi Patil'],
    ['Pune', 'Dr. Sunita Rai'],
    ['Pune', 'Zeenat Syed'],
    ['Raipur', 'Ramesh Patel'],
    ['Chandigarh', 'Gurpreet Singh'],
    ['UnknownRegion', 'John Doe'],
];

foreach ($tests as $t) {
    $res = testResolve($t[0], $t[1]);
    echo "Region: '{$t[0]}' | Name: '{$t[1]}' -> " . ($res ? "{$res['name']} (ID: {$res['id']})" : "NULL (No counter)") . "\n";
}
