<?php
require 'config/db.php';
$pdo = Database::getConnection();
$admins = $pdo->query("SELECT id, username, role FROM admins WHERE role = 'super_admin'")->fetchAll(PDO::FETCH_ASSOC);
print_r($admins);
