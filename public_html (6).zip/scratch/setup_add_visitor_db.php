<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

// Check if added_by exists in allowed_visitors
$colsA = $pdo->query("SHOW COLUMNS FROM allowed_visitors LIKE 'added_by'")->fetchAll();
if (empty($colsA)) {
    $pdo->exec("ALTER TABLE `allowed_visitors` ADD COLUMN `added_by` VARCHAR(50) NULL DEFAULT NULL AFTER `counter_id`");
    echo "Added 'added_by' to allowed_visitors.\n";
} else {
    echo "'added_by' already exists in allowed_visitors.\n";
}

// Check if added_by exists in gift_distribution
$colsG = $pdo->query("SHOW COLUMNS FROM gift_distribution LIKE 'added_by'")->fetchAll();
if (empty($colsG)) {
    $pdo->exec("ALTER TABLE `gift_distribution` ADD COLUMN `added_by` VARCHAR(50) NULL DEFAULT NULL AFTER `counter_id`");
    echo "Added 'added_by' to gift_distribution.\n";
} else {
    echo "'added_by' already exists in gift_distribution.\n";
}

// Create audit_log table
$pdo->exec("
    CREATE TABLE IF NOT EXISTS `audit_log` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `action` VARCHAR(50) NOT NULL,
        `performed_by` VARCHAR(50) NOT NULL,
        `target_id` VARCHAR(50) NULL,
        `target_name` VARCHAR(100) NULL,
        `details` TEXT NULL,
        `created_at_ist` VARCHAR(50) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "Table audit_log verified/created.\n";
