<?php
require_once 'c:/xampp/htdocs/EventMS_loadtest/config/db.php';
$pdo = Database::getConnection();
echo "Connected to: " . $pdo->query("SELECT DATABASE()")->fetchColumn() . "\n";
