const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CHROME = '"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"';
const qaDir = path.join(__dirname, 'qa_views');

const widths = [360, 390, 430, 768, 1024, 1280, 1440, 1920];

const snippet = `
<script>
(function() {
    function runQA() {
        const docW = document.documentElement.clientWidth;
        const scrollW = document.documentElement.scrollWidth;
        const bodyScrollW = document.body.scrollWidth;
        const pageHasHScroll = (scrollW > docW + 2) || (bodyScrollW > docW + 2);

        // Find elements causing horizontal overflow outside .table-responsive
        const overflowingElements = [];
        if (pageHasHScroll) {
            const all = document.querySelectorAll('*');
            for (let el of all) {
                if (el.closest('.table-responsive')) continue;
                const rect = el.getBoundingClientRect();
                if (rect.right > docW + 2) {
                    overflowingElements.push({
                        tag: el.tagName,
                        class: el.className,
                        id: el.id,
                        right: Math.round(rect.right),
                        width: Math.round(rect.width)
                    });
                }
            }
        }

        // Check topbar title and buttons collision
        const titleEl = document.querySelector('.topbar-heading-wrap strong');
        const actionsEl = document.querySelector('.topbar-actions');
        let topbarCollision = false;
        if (titleEl && actionsEl) {
            const tRect = titleEl.getBoundingClientRect();
            const aRect = actionsEl.getBoundingClientRect();
            // Check if they intersect horizontally and vertically
            if (!(tRect.right <= aRect.left || tRect.left >= aRect.right || tRect.bottom <= aRect.top || tRect.top >= aRect.bottom)) {
                topbarCollision = true;
            }
        }

        // Check export buttons height and full width on mobile
        const exportBtns = Array.from(document.querySelectorAll('.btn-gate-tab-export, .btn-kit-tab-export')).map(b => ({
            class: b.className,
            width: Math.round(b.getBoundingClientRect().width),
            height: Math.round(b.getBoundingClientRect().height)
        }));

        // Check stat cards layout
        const statCards = Array.from(document.querySelectorAll('.metric-card')).map(c => ({
            width: Math.round(c.getBoundingClientRect().width),
            height: Math.round(c.getBoundingClientRect().height)
        }));

        // Check pagination if present
        const pagination = document.querySelector('.pagination, .pagination-wrap, .page-item');
        let paginationMetrics = null;
        if (pagination) {
            const pRect = pagination.getBoundingClientRect();
            paginationMetrics = {
                width: Math.round(pRect.width),
                right: Math.round(pRect.right),
                fits: pRect.right <= docW + 2
            };
        }

        const out = document.createElement('div');
        out.id = 'qa_report';
        out.textContent = JSON.stringify({
            docW,
            scrollW,
            bodyScrollW,
            pageHasHScroll,
            overflowCount: overflowingElements.length,
            overflowElements: overflowingElements.slice(0, 5),
            topbarCollision,
            exportBtns,
            statCardsCount: statCards.length,
            paginationMetrics
        });
        document.body.appendChild(out);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', runQA);
    } else {
        runQA();
    }
})();
</script>
`;

const files = fs.readdirSync(qaDir).filter(f => f.endsWith('.html') && !f.startsWith('temp_'));

const results = {};

for (const f of files) {
    const rawHtml = fs.readFileSync(path.join(qaDir, f), 'utf8');
    const injectedHtml = rawHtml.replace('</body>', `${snippet}</body>`);
    const tempFile = path.join(qaDir, `temp_${f}`);
    fs.writeFileSync(tempFile, injectedHtml, 'utf8');

    results[f] = {};

    for (const w of widths) {
        const fileUrl = `file:///${tempFile.replace(/\\/g, '/')}`;
        const cmd = `${CHROME} --headless=new --dump-dom --virtual-time-budget=2000 --window-size=${w},850 "${fileUrl}"`;
        try {
            const domOutput = execSync(cmd, { maxBuffer: 20 * 1024 * 1024, encoding: 'utf8' });
            const match = domOutput.match(/<div id="qa_report">([\s\S]*?)<\/div>/);
            if (match) {
                results[f][`${w}px`] = JSON.parse(match[1]);
            } else {
                results[f][`${w}px`] = { error: 'No report div found' };
            }
        } catch (e) {
            results[f][`${w}px`] = { error: e.message };
        }
    }

    fs.unlinkSync(tempFile);
}

fs.writeFileSync(path.join(__dirname, 'qa_results.json'), JSON.stringify(results, null, 2), 'utf8');
console.log('QA run completed successfully! Output saved to scratch/qa_results.json');
