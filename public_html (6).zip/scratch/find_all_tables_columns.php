<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$cols = $pdo->query("SELECT TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'eventms_db'")->fetchAll(PDO::FETCH_ASSOC);
foreach ($cols as $c) {
    if (preg_match('/(user_id|visitor|visitor_id|target_id|fincert)/i', $c['COLUMN_NAME'])) {
        echo "{$c['TABLE_NAME']}.{$c['COLUMN_NAME']}\n";
    }
}
