<?php
/**
 * Migration Script: Update EventMS Visitor Data from raw_data_AG_updated.xlsx
 */
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

require_once __DIR__ . '/parse_excel_test.php';

$excelFile = __DIR__ . '/../raw_data_AG_updated.xlsx';
if (!file_exists($excelFile)) {
    die("ERROR: Excel file not found at $excelFile\n");
}

$data = parseXlsx($excelFile);
$missingDetails = $data['Missing Details'] ?? [];
if (empty($missingDetails)) {
    die("ERROR: 'Missing Details' sheet is empty or not found\n");
}

echo "=== STARTING VISITOR DATA UPDATE ===\n";

// Function to normalize region to Title Case
function normalizeRegion(string $r): string {
    $r = trim($r);
    $lower = strtolower($r);
    if ($lower === 'delhi east') return 'Delhi East';
    if ($lower === 'delhi west') return 'Delhi West';
    return ucwords($lower);
}

// Function to clean name for Pune sorting
function cleanNameForSort(string $name): string {
    $clean = trim($name);
    $clean = preg_replace('/^(dr\.?|mr\.?|mrs\.?|ms\.?|prof\.?|sh\.?|smt\.?|shri\.?)\s+/i', '', $clean);
    return trim($clean);
}

// Map region to counter_id
function resolveCounterId(PDO $pdo, string $region, string $name = ''): ?int {
    $norm = normalizeRegion($region);
    $lower = strtolower($norm);

    if ($lower === 'pune') {
        $sortName = cleanNameForSort($name);
        if (strcasecmp($sortName, 'Chetan Sonawane') <= 0) {
            return 6; // Pune Counter 1
        } elseif (strcasecmp($sortName, 'Namira Yunus Contractor') <= 0) {
            return 7; // Pune Counter 2
        } elseif (strcasecmp($sortName, 'Sangeeta Rautji') <= 0) {
            return 8; // Pune Counter 3
        } else {
            return 9; // Pune Counter 4
        }
    }

    $stmt = $pdo->prepare("SELECT counter_id FROM counter_regions WHERE LOWER(TRIM(region)) = ? LIMIT 1");
    $stmt->execute([$lower]);
    $cid = $stmt->fetchColumn();
    if ($cid) {
        return (int)$cid;
    }
    return null;
}

$pdo->beginTransaction();

try {
    $updatedRegionList = [];
    $updatedContactList = [];
    $newVisitorList = [];
    $conflicts = [];
    $skipped = [];
    $totalSheetRows = 0;

    for ($r = 6; $r <= 21; $r++) {
        if (!isset($missingDetails[$r])) continue;
        $totalSheetRows++;
        $row = $missingDetails[$r];
        $sno = trim($row['A'] ?? '');
        $sheetRegion = trim($row['B'] ?? '');
        $userId = trim($row['C'] ?? '');
        $school = trim($row['D'] ?? '');
        $name = trim($row['E'] ?? '');
        $desig = trim($row['F'] ?? '');
        $contact = trim($row['G'] ?? '');
        $email = trim($row['H'] ?? '');
        $fincert = trim($row['I'] ?? '');
        $field = trim($row['J'] ?? '');

        if (empty($userId)) {
            $skipped[] = "Row $r: empty user_id";
            continue;
        }

        $cleanContact = preg_replace('/\D/', '', $contact);
        $normRegion = !empty($sheetRegion) ? normalizeRegion($sheetRegion) : '';

        // Check if user exists in allowed_visitors
        $stmtV = $pdo->prepare("SELECT * FROM allowed_visitors WHERE LOWER(TRIM(user_id)) = LOWER(TRIM(?))");
        $stmtV->execute([$userId]);
        $existing = $stmtV->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            // Existing visitor
            $visId = (int)$existing['id'];
            $needsUpdateAllowed = [];
            $needsUpdateGift = [];
            $paramsAllowed = [];
            $paramsGift = [];

            // Region update
            if (empty(trim((string)$existing['region'])) && !empty($normRegion)) {
                $counterId = resolveCounterId($pdo, $normRegion, $existing['name']);
                
                // Get counter name for gift_distribution.counter_region
                $cNameStmt = $pdo->prepare("SELECT name FROM counters WHERE id = ?");
                $cNameStmt->execute([$counterId]);
                $cName = $cNameStmt->fetchColumn() ?: $normRegion;

                $needsUpdateAllowed[] = "region = :reg, counter_id = :cid";
                $paramsAllowed[':reg'] = $normRegion;
                $paramsAllowed[':cid'] = $counterId;

                $needsUpdateGift[] = "region = :reg, counter_id = :cid, counter_region = :creg";
                $paramsGift[':reg'] = $normRegion;
                $paramsGift[':cid'] = $counterId;
                $paramsGift[':creg'] = $cName;

                $updatedRegionList[] = [
                    'sno' => $sno,
                    'user_id' => $userId,
                    'name' => $existing['name'],
                    'old_region' => '(Empty)',
                    'new_region' => $normRegion,
                    'counter_id' => $counterId,
                    'counter_name' => $cName
                ];
            } elseif (!empty(trim((string)$existing['region'])) && !empty($normRegion) && strcasecmp(trim($existing['region']), $normRegion) !== 0) {
                $conflicts[] = [
                    'user_id' => $userId,
                    'name' => $existing['name'],
                    'field' => 'region',
                    'db_val' => $existing['region'],
                    'sheet_val' => $normRegion
                ];
            }

            // Contact update
            if (empty(trim((string)$existing['mobile'])) && !empty($cleanContact)) {
                $needsUpdateAllowed[] = "mobile = :mob";
                $paramsAllowed[':mob'] = $cleanContact;

                $needsUpdateGift[] = "mobile = :mob";
                $paramsGift[':mob'] = $cleanContact;

                $updatedContactList[] = [
                    'sno' => $sno,
                    'user_id' => $userId,
                    'name' => $existing['name'],
                    'old_contact' => '(Empty)',
                    'new_contact' => $cleanContact
                ];
            } elseif (!empty(trim((string)$existing['mobile'])) && !empty($cleanContact) && trim($existing['mobile']) !== $cleanContact) {
                $conflicts[] = [
                    'user_id' => $userId,
                    'name' => $existing['name'],
                    'field' => 'mobile',
                    'db_val' => $existing['mobile'],
                    'sheet_val' => $cleanContact
                ];
            }

            // Email update if empty in DB
            if (empty(trim((string)$existing['email'])) && !empty($email)) {
                $needsUpdateAllowed[] = "email = :eml";
                $paramsAllowed[':eml'] = $email;

                $needsUpdateGift[] = "email = :eml";
                $paramsGift[':eml'] = $email;
            }

            // Execute update if any
            if (!empty($needsUpdateAllowed)) {
                $sqlA = "UPDATE allowed_visitors SET " . implode(', ', $needsUpdateAllowed) . " WHERE id = :id";
                $paramsAllowed[':id'] = $visId;
                $stmtUpdA = $pdo->prepare($sqlA);
                $stmtUpdA->execute($paramsAllowed);
            }

            if (!empty($needsUpdateGift)) {
                $sqlG = "UPDATE gift_distribution SET " . implode(', ', $needsUpdateGift) . " WHERE LOWER(TRIM(user_id)) = LOWER(TRIM(:uid))";
                $paramsGift[':uid'] = $userId;
                $stmtUpdG = $pdo->prepare($sqlG);
                $stmtUpdG->execute($paramsGift);
            }

        } else {
            // New visitor to insert
            $counterId = resolveCounterId($pdo, $normRegion, $name);
            $cNameStmt = $pdo->prepare("SELECT name FROM counters WHERE id = ?");
            $cNameStmt->execute([$counterId]);
            $cName = $cNameStmt->fetchColumn() ?: $normRegion;

            // Insert into allowed_visitors
            $insA = $pdo->prepare("
                INSERT INTO allowed_visitors (
                    name, user_id, region, school_name, designation, mobile, email, fincert,
                    counter_id, is_checked_in, is_day1_checked_in, is_day2_checked_in, created_at
                ) VALUES (
                    :name, :user_id, :region, :school_name, :designation, :mobile, :email, :fincert,
                    :counter_id, 0, 0, 0, NOW()
                )
            ");
            $insA->execute([
                ':name' => $name,
                ':user_id' => $userId,
                ':region' => $normRegion,
                ':school_name' => $school,
                ':designation' => $desig,
                ':mobile' => $cleanContact,
                ':email' => $email,
                ':fincert' => $fincert,
                ':counter_id' => $counterId
            ]);
            $newVisId = (int)$pdo->lastInsertId();

            // Insert into gift_distribution
            $insG = $pdo->prepare("
                INSERT INTO gift_distribution (
                    name, user_id, region, school_name, designation, mobile, email, fincert,
                    counter_id, counter_region, is_gift_collected, created_at
                ) VALUES (
                    :name, :user_id, :region, :school_name, :designation, :mobile, :email, :fincert,
                    :counter_id, :counter_region, 0, NOW()
                )
            ");
            $insG->execute([
                ':name' => $name,
                ':user_id' => $userId,
                ':region' => $normRegion,
                ':school_name' => $school,
                ':designation' => $desig,
                ':mobile' => $cleanContact,
                ':email' => $email,
                ':fincert' => $fincert,
                ':counter_id' => $counterId,
                ':counter_region' => $cName
            ]);

            $newVisitorList[] = [
                'sno' => $sno,
                'user_id' => $userId,
                'name' => $name,
                'region' => $normRegion,
                'school' => $school,
                'designation' => $desig,
                'contact' => $cleanContact,
                'email' => $email,
                'fincert' => $fincert,
                'counter_id' => $counterId,
                'counter_name' => $cName
            ];
        }
    }

    // Step 4: Check if any visitor still has empty region or Help Desk counter
    $remEmptyRegion = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE region IS NULL OR TRIM(region) = ''")->fetchColumn();
    $remHelpdesk = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id = 21")->fetchColumn();

    echo "Remaining empty region visitors: $remEmptyRegion\n";
    echo "Remaining Help Desk counter visitors: $remHelpdesk\n";

    if ($remEmptyRegion === 0 && $remHelpdesk === 0) {
        // Disable Help Desk counter in counters table
        $pdo->prepare("UPDATE counters SET is_active = 0 WHERE id = 21 OR code = 'helpdesk'")->execute();
        // Disable Help Desk login in admins table
        $pdo->prepare("UPDATE admins SET status = 'disabled', failed_attempts = 0 WHERE username = 'counter_helpdesk' OR counter_id = 21")->execute();
        echo "Help Desk counter deactivated and login disabled successfully.\n";
    } else {
        throw new Exception("Cannot deactivate Help Desk: $remEmptyRegion empty regions, $remHelpdesk at helpdesk.");
    }

    $pdo->commit();
    echo "\n=== TRANSACTION COMMITTED SUCCESSFULLY ===\n";

    echo "Total Sheet Rows Processed: $totalSheetRows\n";
    echo "Updated Region Count: " . count($updatedRegionList) . "\n";
    echo "Updated Contact Count: " . count($updatedContactList) . "\n";
    echo "New Visitors Added: " . count($newVisitorList) . "\n";
    echo "Conflicts: " . count($conflicts) . "\n";

    echo "\n--- UPDATED REGIONS ---\n";
    foreach ($updatedRegionList as $ur) {
        echo "SNo: {$ur['sno']} | UserID: {$ur['user_id']} | Name: {$ur['name']} | Old: {$ur['old_region']} | New: {$ur['new_region']} | Counter: {$ur['counter_name']} (ID: {$ur['counter_id']})\n";
    }

    echo "\n--- UPDATED CONTACTS ---\n";
    foreach ($updatedContactList as $uc) {
        echo "SNo: {$uc['sno']} | UserID: {$uc['user_id']} | Name: {$uc['name']} | Old: {$uc['old_contact']} | New: {$uc['new_contact']}\n";
    }

    echo "\n--- NEW VISITOR ---\n";
    foreach ($newVisitorList as $nv) {
        echo "UserID: {$nv['user_id']} | Name: {$nv['name']} | Region: {$nv['region']} | Mobile: {$nv['contact']} | FinCert: '{$nv['fincert']}' | Counter: {$nv['counter_name']} (ID: {$nv['counter_id']})\n";
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "ERROR during execution: " . $e->getMessage() . "\n";
    exit(1);
}
