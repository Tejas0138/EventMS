<?php
require_once 'c:/xampp/htdocs/EventMS_loadtest/config/db.php';
$pdo = Database::getConnection();
$stmt = $pdo->query("SELECT id, counter_no, name, code, username, is_active FROM counters ORDER BY counter_no ASC");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC), JSON_PRETTY_PRINT);
