<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$allowed = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
$gift = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution")->fetchColumn();
$d1 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day1_checked_in = 1")->fetchColumn();
$d2 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day2_checked_in = 1")->fetchColumn();
$kits = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE is_gift_collected = 1")->fetchColumn();

// Check if any mobile between 9000000001 and 9000000300 exists in real db
$stmt = $pdo->prepare("SELECT COUNT(*) FROM allowed_visitors WHERE mobile BETWEEN '9000000001' AND '9000000300'");
$stmt->execute();
$overlappingMobiles = (int)$stmt->fetchColumn();

// Check if any LOADTEST_% id exists in real db
$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM allowed_visitors WHERE user_id LIKE 'LOADTEST_%'");
$stmt2->execute();
$overlappingIds = (int)$stmt2->fetchColumn();

// Check mobile 9324564790 (from prompt: "mobile number 9324564790 (shared by two real visitors, copy that duplicate to the test data)")
$stmt3 = $pdo->prepare("SELECT id, name, user_id, mobile, region FROM allowed_visitors WHERE mobile = '9324564790'");
$stmt3->execute();
$sharedMobileVisitors = $stmt3->fetchAll(PDO::FETCH_ASSOC);

// Get event_settings
$settings = $pdo->query("SELECT * FROM event_settings")->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'database' => 'eventms_db',
    'allowed_visitors_total' => $allowed,
    'gift_distribution_total' => $gift,
    'day1_checkins' => $d1,
    'day2_checkins' => $d2,
    'kits_collected' => $kits,
    'overlapping_test_mobiles' => $overlappingMobiles,
    'overlapping_test_ids' => $overlappingIds,
    'shared_mobile_visitors' => $sharedMobileVisitors,
    'event_settings' => $settings
], JSON_PRETTY_PRINT);
