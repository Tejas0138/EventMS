<?php
$zip = new ZipArchive();
$file = __DIR__ . '/../raw_data_AG_updated.xlsx';
if ($zip->open($file) === TRUE) {
    echo "Files in $file:\n";
    for ($i = 0; $i < $zip->numFiles; $i++) {
        echo $zip->getNameIndex($i) . "\n";
    }
    $zip->close();
} else {
    echo "Failed to open $file\n";
}
