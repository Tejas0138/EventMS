<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$counters = $pdo->query("
    SELECT c.id, c.counter_no, c.name, c.username, c.name_range,
           COUNT(v.id) as visitor_count
    FROM counters c
    LEFT JOIN allowed_visitors v ON v.counter_id = c.id
    GROUP BY c.id
    ORDER BY c.counter_no ASC, c.id ASC
")->fetchAll(PDO::FETCH_ASSOC);

$total = 0;
foreach ($counters as $c) {
    echo "ID {$c['id']} | No: {$c['counter_no']} | {$c['name']} ({$c['username']}) | Visitors: {$c['visitor_count']}\n";
    $total += (int)$c['visitor_count'];
}
echo "Total across counters: {$total}\n";

$unassigned = $pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id IS NULL OR counter_id = 0")->fetchColumn();
echo "Unassigned visitors: {$unassigned}\n";
