<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$stmt = $pdo->query("SELECT id, name, code, username, name_range, is_active FROM counters ORDER BY id ASC");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
    echo sprintf("%2d | %-40s | %-35s | %-15s | %s\n", $r['id'], $r['name'], $r['username'], $r['code'], $r['name_range']);
}
