<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$rows = $pdo->query("SELECT id, username, failed_attempts, locked_until, status, counter_id FROM admins WHERE failed_attempts > 0 OR locked_until IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC);
echo "Locked or failed attempts accounts: " . count($rows) . "\n";
print_r($rows);
