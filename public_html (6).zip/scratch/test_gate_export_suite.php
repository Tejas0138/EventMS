<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$baseUrl = 'http://localhost:8080/EventMS';

// Function to log in and get cookie
function getSessionCookie(string $username, string $password): string {
    global $baseUrl;
    $cookieFile = __DIR__ . '/cookie_' . preg_replace('/[^a-zA-Z0-9]/', '_', $username) . '.txt';
    if (file_exists($cookieFile)) unlink($cookieFile);

    $ch = curl_init("$baseUrl/login.php");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEJAR      => $cookieFile,
        CURLOPT_COOKIEFILE     => $cookieFile,
        CURLOPT_TIMEOUT        => 10
    ]);
    $html = curl_exec($ch);
    preg_match('/name="csrf_token"\s+value="([a-f0-9]+)"/i', (string)$html, $m);
    $token = $m[1] ?? '';

    curl_setopt_array($ch, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'csrf_token' => $token,
            'username'   => $username,
            'password'   => $password
        ]),
        CURLOPT_FOLLOWLOCATION => true
    ]);
    curl_exec($ch);
    curl_close($ch);
    return $cookieFile;
}

// Function to make authenticated GET request
function authGet(string $url, string $cookieFile): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEFILE     => $cookieFile,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_TIMEOUT        => 15
    ]);
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $effectiveUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $redirectUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
    curl_close($ch);
    return [
        'code' => $code,
        'type' => $contentType,
        'body' => (string)$response,
        'effective_url' => $effectiveUrl,
        'redirect_url' => $redirectUrl
    ];
}

echo "====================================================\n";
echo "CHECK 1: SIDEBAR SHOWS ONLY 'GATE QR' UNDER PUBLIC TERMINALS\n";
echo "====================================================\n";

$adminCookie = getSessionCookie('admin', 'admin123');
// If default admin password differs, test with admin / correct pass
$adminTest = authGet("$baseUrl/admin.php?tab=gate", $adminCookie);
if (strpos($adminTest['body'], 'Sign In') !== false || $adminTest['code'] === 302) {
    // Try other passwords if admin123 is not set
    foreach (['admin', 'Admin@2026', 'admin@123', 'admin2026'] as $tryP) {
        $adminCookie = getSessionCookie('admin', $tryP);
        $adminTest = authGet("$baseUrl/admin.php?tab=gate", $adminCookie);
        if (strpos($adminTest['body'], 'Sign In') === false && $adminTest['code'] === 200) {
            break;
        }
    }
}

// Check sidebar for Public Terminals
$hasPublicTerminalsHeading = (strpos($adminTest['body'], 'Public Terminals') !== false);
$hasGateQrLink = (strpos($adminTest['body'], 'Gate QR') !== false);
$hasGateTerminal = (strpos($adminTest['body'], 'Gate Terminal') !== false);
$hasKitTerminal = (strpos($adminTest['body'], 'COE Kit Terminal') !== false);

echo "Public Terminals heading present: " . ($hasPublicTerminalsHeading ? "YES (PASS)" : "NO (FAIL)") . "\n";
echo "Gate QR link present: " . ($hasGateQrLink ? "YES (PASS)" : "NO (FAIL)") . "\n";
echo "Gate Terminal link hidden: " . (!$hasGateTerminal ? "YES (PASS)" : "NO (FAIL)") . "\n";
echo "COE Kit Terminal link hidden: " . (!$hasKitTerminal ? "YES (PASS)" : "NO (FAIL)") . "\n";

// Check Gate QR page works
$qrPage = authGet("$baseUrl/admin.php?tab=gate_qr", $adminCookie);
$qrWorks = ($qrPage['code'] === 200 && (strpos($qrPage['body'], 'Gate QR Poster') !== false || strpos($qrPage['body'], 'Gate Self Check-In QR') !== false));
echo "Gate QR page works: " . ($qrWorks ? "YES (PASS)" : "NO (FAIL)") . "\n\n";

// Also check Counter sidebar
$counterCookie = getSessionCookie('pune1', 'pune1@123');
$counterTest = authGet("$baseUrl/admin.php?tab=gift", $counterCookie);
$counterHasGateTerm = (strpos($counterTest['body'], 'Gate Terminal') !== false);
$counterHasKitTerm = (strpos($counterTest['body'], 'COE Kit Terminal') !== false);
echo "Counter sidebar Gate Terminal hidden: " . (!$counterHasGateTerm ? "YES (PASS)" : "NO (FAIL)") . "\n";
echo "Counter sidebar COE Kit Terminal hidden: " . (!$counterHasKitTerm ? "YES (PASS)" : "NO (FAIL)") . "\n\n";

echo "====================================================\n";
echo "CHECK 2: EXPORT CSV FOR EACH TAB (All, Day 1, Day 2, Pending Both)\n";
echo "====================================================\n";

$d1Count = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day1_checked_in = 1")->fetchColumn();
$d2Count = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day2_checked_in = 1")->fetchColumn();
$pendingBothCount = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day1_checked_in = 0 AND is_day2_checked_in = 0")->fetchColumn();
$totalCount = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();

$tabsToTest = [
    'all'          => ['name' => 'All', 'expected' => $totalCount],
    'day1'         => ['name' => 'Day 1 Inside', 'expected' => $d1Count],
    'day2'         => ['name' => 'Day 2 Inside', 'expected' => $d2Count],
    'pending_both' => ['name' => 'Pending Both', 'expected' => $pendingBothCount],
];

foreach ($tabsToTest as $tabKey => $tabInfo) {
    $url = "$baseUrl/admin.php?export=gate_tab_csv&gfilter=$tabKey";
    $csvRes = authGet($url, $adminCookie);

    $lines = array_filter(explode("\n", trim($csvRes['body'])));
    $headerLine = array_shift($lines);
    $dataRowCount = count($lines);

    $pass = ($csvRes['code'] === 200 && $dataRowCount === $tabInfo['expected']);
    echo "[Tab: {$tabInfo['name']}]\n";
    echo "  HTTP Code: {$csvRes['code']}\n";
    echo "  Rows in CSV: $dataRowCount | Expected DB Count: {$tabInfo['expected']}\n";
    echo "  Status: " . ($pass ? "PASS" : "FAIL") . "\n";
}

echo "\n====================================================\n";
echo "CHECK 3: FILTER BY REGION AND/OR SEARCH\n";
echo "====================================================\n";

// 3a. Region 'Pune'
$puneCount = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE region = 'Pune'")->fetchColumn();
$puneRes = authGet("$baseUrl/admin.php?export=gate_tab_csv&gfilter=all&gregion=Pune", $adminCookie);
$puneLines = array_filter(explode("\n", trim($puneRes['body'])));
array_shift($puneLines);
$puneRowCount = count($puneLines);
echo "Region 'Pune': CSV rows = $puneRowCount (DB expected: $puneCount) -> " . ($puneRowCount === $puneCount ? "PASS" : "FAIL") . "\n";

// 3b. Search 'Mishra'
$mishraCount = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE name LIKE '%Mishra%' OR mobile LIKE '%Mishra%' OR user_id LIKE '%Mishra%' OR fincert LIKE '%Mishra%' OR region LIKE '%Mishra%' OR school_name LIKE '%Mishra%'")->fetchColumn();
$mishraRes = authGet("$baseUrl/admin.php?export=gate_tab_csv&gfilter=all&gsearch=Mishra", $adminCookie);
$mishraLines = array_filter(explode("\n", trim($mishraRes['body'])));
array_shift($mishraLines);
$mishraRowCount = count($mishraLines);
echo "Search 'Mishra': CSV rows = $mishraRowCount (DB expected: $mishraCount) -> " . ($mishraRowCount === $mishraCount ? "PASS" : "FAIL") . "\n";

// 3c. Region 'Bhubaneswar' + Search 'Mishra'
$bothCount = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE region = 'Bhubaneswar' AND (name LIKE '%Mishra%' OR mobile LIKE '%Mishra%' OR user_id LIKE '%Mishra%' OR fincert LIKE '%Mishra%' OR region LIKE '%Mishra%' OR school_name LIKE '%Mishra%')")->fetchColumn();
$bothRes = authGet("$baseUrl/admin.php?export=gate_tab_csv&gfilter=all&gregion=Bhubaneswar&gsearch=Mishra", $adminCookie);
$bothLines = array_filter(explode("\n", trim($bothRes['body'])));
array_shift($bothLines);
$bothRowCount = count($bothLines);
echo "Region 'Bhubaneswar' + Search 'Mishra': CSV rows = $bothRowCount (DB expected: $bothCount) -> " . ($bothRowCount === $bothCount ? "PASS" : "FAIL") . "\n";

echo "\n====================================================\n";
echo "CHECK 4: CSV FORMAT, BOM, HEADERS, DATA COLUMNS & INTEGRITY\n";
echo "====================================================\n";

$allRes = authGet("$baseUrl/admin.php?export=gate_tab_csv&gfilter=all", $adminCookie);
$body = $allRes['body'];

// Check UTF-8 BOM
$hasBom = (substr($body, 0, 3) === "\xEF\xBB\xBF");
echo "Has UTF-8 BOM: " . ($hasBom ? "YES (PASS)" : "NO (FAIL)") . "\n";

// Parse CSV stream
$fp = fopen('php://memory', 'r+');
fwrite($fp, substr($body, 3)); // strip BOM
rewind($fp);

$headerRow = fgetcsv($fp);
$expectedHeaders = [
    '#',
    'Full Name',
    'Register Id',
    'FinCert',
    'Region',
    'Counter',
    'School',
    'Designation',
    'Mobile',
    'Email',
    'Day 1 Status',
    'Day 1 Check-in Time (IST)',
    'Day 2 Status',
    'Day 2 Check-in Time (IST)',
    'COE Kit Status'
];

$headersMatch = ($headerRow === $expectedHeaders);
echo "Headers match exactly: " . ($headersMatch ? "YES (PASS)" : "NO (FAIL)") . "\n";
if (!$headersMatch) {
    echo "  Actual: " . json_encode($headerRow) . "\n";
    echo "  Expected: " . json_encode($expectedHeaders) . "\n";
}

// Sample row check
$firstRow = fgetcsv($fp);
echo "First row column count: " . count($firstRow) . " (Expected: 15)\n";
echo "Sample row: \n";
foreach ($expectedHeaders as $i => $h) {
    echo "  $h: '{$firstRow[$i]}'\n";
}

echo "\n====================================================\n";
echo "CHECK 5: COUNTER USER ACCESS REJECTED WITH 403\n";
echo "====================================================\n";

$counterExportRes = authGet("$baseUrl/admin.php?export=gate_tab_csv&gfilter=all", $counterCookie);
echo "Counter export HTTP code: {$counterExportRes['code']} (Expected: 403)\n";
echo "Counter export refused: " . ($counterExportRes['code'] === 403 ? "PASS" : "FAIL") . "\n";

echo "\n====================================================\n";
echo "CHECK 6: HEADER 'EXPORT CSV' BUTTON STILL WORKS\n";
echo "====================================================\n";

$headerExportRes = authGet("$baseUrl/admin.php?export=gate_csv&tab=gate", $adminCookie);
echo "Header export HTTP code: {$headerExportRes['code']} (Expected: 200)\n";
$headerLines = array_filter(explode("\n", trim($headerExportRes['body'])));
echo "Header export row count: " . count($headerLines) . " -> " . ($headerExportRes['code'] === 200 ? "PASS" : "FAIL") . "\n";

// Cleanup cookies
if (file_exists($adminCookie)) unlink($adminCookie);
if (file_exists($counterCookie)) unlink($counterCookie);
