<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$stmt = $pdo->query("SELECT id, username, role, region, status FROM admins ORDER BY id ASC");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
    echo sprintf("%2d | %-25s | %-12s | %-20s | %s\n", $r['id'], $r['username'], $r['role'], $r['region'], $r['status']);
}
