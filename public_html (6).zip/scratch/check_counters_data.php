<?php
require 'config/db.php';
$pdo = Database::getConnection();

echo "--- Counters and Sample Visitors ---\n";
$counters = $pdo->query("SELECT id, name, username, name_range FROM counters ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
foreach ($counters as $c) {
    $vCount = $pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE counter_id = {$c['id']}")->fetchColumn();
    $sample = $pdo->query("SELECT name, region, user_id FROM gift_distribution WHERE counter_id = {$c['id']} LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $sampleInfo = $sample ? "{$sample['name']} ({$sample['region']}, {$sample['user_id']})" : "No visitors";
    echo "ID {$c['id']}: {$c['name']} (User: {$c['username']}) -> {$vCount} visitors. Sample: {$sampleInfo}\n";
}
