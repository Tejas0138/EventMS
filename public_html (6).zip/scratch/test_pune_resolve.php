<?php
require 'config/db.php';
$pdo = Database::getConnection();

$stmt = $pdo->query("
    SELECT v.id, v.name, v.user_id, v.region, v.counter_id,
           c.counter_no, c.name AS counter_name, c.name_range
    FROM allowed_visitors v
    LEFT JOIN counters c ON c.id = v.counter_id
    WHERE LOWER(TRIM(v.region)) = 'pune'
    ORDER BY v.id ASC
    LIMIT 10
");
while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "ID: {$r['id']} | Name: {$r['name']} | UserID: {$r['user_id']} | CounterID: {$r['counter_id']} | CounterNo: {$r['counter_no']} | CounterName: {$r['counter_name']} | Range: {$r['name_range']}\n";
}
