<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== GIFT_DISTRIBUTION COLUMNS ===\n";
foreach ($pdo->query("DESCRIBE gift_distribution")->fetchAll(PDO::FETCH_ASSOC) as $col) {
    echo "{$col['Field']} ({$col['Type']})\n";
}

echo "\n=== SAMPLE ROWS WITH GIFT COLLECTED ===\n";
$samples = $pdo->query("SELECT * FROM gift_distribution WHERE is_gift_collected = 1 LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
print_r($samples);
