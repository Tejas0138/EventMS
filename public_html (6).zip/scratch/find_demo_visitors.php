<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== Searching allowed_visitors ===\n";
$stmt1 = $pdo->query("SELECT * FROM allowed_visitors WHERE LOWER(TRIM(user_id)) IN ('1234', '23568') OR LOWER(TRIM(name)) IN ('test', 'test2')");
$rows1 = $stmt1->fetchAll(PDO::FETCH_ASSOC);
print_r($rows1);

echo "=== Searching gift_distribution ===\n";
$stmt2 = $pdo->query("SELECT * FROM gift_distribution WHERE LOWER(TRIM(user_id)) IN ('1234', '23568') OR LOWER(TRIM(name)) IN ('test', 'test2')");
$rows2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);
print_r($rows2);

echo "=== Searching audit_log ===\n";
$stmt3 = $pdo->query("SELECT * FROM audit_log WHERE LOWER(TRIM(target_id)) IN ('1234', '23568') OR LOWER(TRIM(target_name)) IN ('test', 'test2') OR details LIKE '%1234%' OR details LIKE '%23568%'");
$rows3 = $stmt3->fetchAll(PDO::FETCH_ASSOC);
print_r($rows3);

echo "=== Searching counter_reassignment_log ===\n";
$stmt4 = $pdo->query("SELECT * FROM counter_reassignment_log WHERE visitor_id IN (SELECT id FROM allowed_visitors WHERE LOWER(TRIM(user_id)) IN ('1234', '23568'))");
$rows4 = $stmt4->fetchAll(PDO::FETCH_ASSOC);
print_r($rows4);
