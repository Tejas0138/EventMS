<?php
require_once 'c:/xampp/htdocs/EventMS_loadtest/config/db.php';
$pdo = Database::getConnection();

$specs = [
    'php_version' => PHP_VERSION,
    'max_execution_time' => ini_get('max_execution_time'),
    'memory_limit' => ini_get('memory_limit'),
    'post_max_size' => ini_get('post_max_size'),
    'upload_max_filesize' => ini_get('upload_max_filesize'),
    'mysql_max_connections' => $pdo->query("SHOW VARIABLES LIKE 'max_connections'")->fetch(PDO::FETCH_ASSOC)['Value'] ?? null,
    'mysql_threads_connected' => $pdo->query("SHOW STATUS LIKE 'Threads_connected'")->fetch(PDO::FETCH_ASSOC)['Value'] ?? null,
    'mysql_wait_timeout' => $pdo->query("SHOW VARIABLES LIKE 'wait_timeout'")->fetch(PDO::FETCH_ASSOC)['Value'] ?? null,
    'mysql_slow_query_log' => $pdo->query("SHOW VARIABLES LIKE 'slow_query_log'")->fetch(PDO::FETCH_ASSOC)['Value'] ?? null,
    'mysql_long_query_time' => $pdo->query("SHOW VARIABLES LIKE 'long_query_time'")->fetch(PDO::FETCH_ASSOC)['Value'] ?? null
];

echo json_encode($specs, JSON_PRETTY_PRINT);
