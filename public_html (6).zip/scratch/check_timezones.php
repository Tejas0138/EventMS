<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "PHP default timezone: " . date_default_timezone_get() . "\n";
$phpNowIST = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
echo "PHP Current IST Time: " . $phpNowIST->format('Y-m-d H:i:s T') . "\n";

$sqlTimes = $pdo->query("SELECT NOW() as mysql_now, UTC_TIMESTAMP() as mysql_utc, @@session.time_zone as session_tz")->fetch(PDO::FETCH_ASSOC);
echo "MySQL session time_zone: " . $sqlTimes['session_tz'] . "\n";
echo "MySQL NOW(): " . $sqlTimes['mysql_now'] . "\n";
echo "MySQL UTC_TIMESTAMP(): " . $sqlTimes['mysql_utc'] . "\n";

// Day 1 / Day 2 decision test
$today = $phpNowIST->format('Y-m-d');
$settings = getEventSettings($pdo);
$d1 = $settings['day1_date'];
$d2 = $settings['day2_date'];
echo "\nToday IST: {$today} | Day 1: {$d1} | Day 2: {$d2}\n";
if ($today === $d1) {
    echo "Resolved Day: Day 1\n";
} elseif ($today === $d2) {
    echo "Resolved Day: Day 2\n";
} else {
    echo "Resolved Day: Not open today\n";
}
