<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$mismatch = $pdo->query('SELECT COUNT(*) FROM allowed_visitors a JOIN gift_distribution g ON a.user_id = g.user_id WHERE a.id != g.id')->fetchColumn();
echo "Mismatched IDs: $mismatch\n";

$totalA = $pdo->query('SELECT COUNT(*) FROM allowed_visitors')->fetchColumn();
$totalG = $pdo->query('SELECT COUNT(*) FROM gift_distribution')->fetchColumn();
echo "Total allowed_visitors: $totalA, Total gift_distribution: $totalG\n";

// Check sample visitor
$sample = $pdo->query('SELECT a.id as a_id, a.user_id, a.name, a.is_day1_checked_in, a.day1_checked_in_at, a.is_day2_checked_in, a.day2_checked_in_at, g.id as g_id, g.is_gift_collected FROM allowed_visitors a JOIN gift_distribution g ON a.user_id = g.user_id LIMIT 3')->fetchAll(PDO::FETCH_ASSOC);
print_r($sample);
