<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$pass = 0;
$fail = 0;

function report(string $name, bool $ok, string $details = '') {
    global $pass, $fail;
    if ($ok) {
        $pass++;
        echo "[PASS] $name" . ($details ? " ($details)" : "") . "\n";
    } else {
        $fail++;
        echo "[FAIL] $name" . ($details ? " ($details)" : "") . "\n";
    }
}

echo "=== EVENTMS TEST SUITE: 3 PROBLEMS VERIFICATION ===\n\n";

// -------------------------------------------------------------
// TEST 1: Counters page query & counts
// -------------------------------------------------------------
echo "--- TEST 1: Counters page visitor counts & totals ---\n";
$countersStmt = $pdo->query("
    SELECT c.id, c.name, c.code, c.username, c.name_range, c.is_active, c.last_login,
           a.id AS admin_id, a.status AS admin_status,
           COALESCE(g_agg.total_visitors, 0) AS total_visitors,
           COALESCE(g_agg.kits_distributed, 0) AS kits_distributed,
           COALESCE(g_agg.kits_pending, 0) AS kits_pending,
           (
               SELECT GROUP_CONCAT(NULLIF(TRIM(cr.region), '') ORDER BY cr.region SEPARATOR ', ')
               FROM `counter_regions` cr
               WHERE cr.counter_id = c.id AND TRIM(cr.region) != ''
           ) AS regions_covered
    FROM `counters` c
    LEFT JOIN `admins` a ON (a.username = c.username)
    LEFT JOIN (
        SELECT counter_id,
               COUNT(*) AS total_visitors,
               SUM(CASE WHEN is_gift_collected = 1 THEN 1 ELSE 0 END) AS kits_distributed,
               SUM(CASE WHEN is_gift_collected = 0 THEN 1 ELSE 0 END) AS kits_pending
        FROM `gift_distribution`
        WHERE counter_id IS NOT NULL AND counter_id > 0
        GROUP BY counter_id
    ) g_agg ON (g_agg.counter_id = c.id)
    ORDER BY c.id ASC
");
$countersList = $countersStmt->fetchAll(PDO::FETCH_ASSOC);

$expectedCounts = [
    'counter_raipur_chandigarh'             => 67,
    'counter_dehradun_lucknow'               => 67,
    'counter_gurugram_guwahati'              => 68,
    'counter_chennai_vijayawada'             => 67,
    'counter_panchkula_prayagraj_hyderabad' => 76,
    'counter_pune_1'                         => 73,
    'counter_pune_2'                         => 73,
    'counter_pune_3'                         => 72,
    'counter_pune_4'                         => 72,
    'counter_noida'                          => 76,
    'counter_bengaluru'                      => 70,
    'counter_bhopal'                         => 62,
    'counter_bhubaneswar'                    => 61,
    'counter_ajmer'                          => 58,
    'counter_ahmedabad'                      => 56,
    'counter_patna'                          => 53,
    'counter_trivandrum'                     => 52,
    'counter_delhi_west'                     => 51,
    'counter_delhi_east'                     => 44,
    'counter_ranchi'                         => 39,
    'counter_helpdesk'                       => 12,
];

$totalVisitorsSum = 0;
$totalGivenSum = 0;
$totalPendingSum = 0;
$allMathOk = true;
$allCountsOk = true;

foreach ($countersList as $c) {
    $u = $c['username'];
    $tot = (int)$c['total_visitors'];
    $giv = (int)$c['kits_distributed'];
    $pen = (int)$c['kits_pending'];
    
    $totalVisitorsSum += $tot;
    $totalGivenSum += $giv;
    $totalPendingSum += $pen;
    
    if (($giv + $pen) !== $tot) {
        $allMathOk = false;
        echo "[ERR] Math mismatch for {$c['name']}: given($giv) + pend($pen) != total($tot)\n";
    }
    
    $expected = $expectedCounts[$u] ?? null;
    if ($expected === null || $tot !== $expected) {
        $allCountsOk = false;
        echo "[ERR] Count mismatch for {$c['name']} ($u): got $tot, expected $expected\n";
    }
}

report("All 21 individual counter counts match specifications", $allCountsOk);
report("Distributed + Pending == Visitors for every counter", $allMathOk);
report("Total sum of counter visitor counts is 1269", $totalVisitorsSum === 1269, "Total: $totalVisitorsSum");

// -------------------------------------------------------------
// TEST 2: counter_raipur_chandigarh scope
// -------------------------------------------------------------
echo "\n--- TEST 2: Combined Counter Staff Scoping (Raipur / Chandigarh) ---\n";
$rcCounterId = (int)$pdo->query("SELECT id FROM counters WHERE code = 'raipur_chandigarh'")->fetchColumn();
$rcStmt = $pdo->prepare("SELECT COUNT(*) FROM gift_distribution WHERE counter_id = :cid");
$rcStmt->execute([':cid' => $rcCounterId]);
$rcCount = (int)$rcStmt->fetchColumn();
report("counter_raipur_chandigarh list has exactly 67 visitors", $rcCount === 67, "Count: $rcCount");

// Check for duplicate user_ids in raipur_chandigarh
$rcDupStmt = $pdo->prepare("SELECT user_id, COUNT(*) as cnt FROM gift_distribution WHERE counter_id = :cid GROUP BY user_id HAVING cnt > 1");
$rcDupStmt->execute([':cid' => $rcCounterId]);
$rcDups = $rcDupStmt->fetchAll();
report("Zero duplicate visitors in counter_raipur_chandigarh", count($rcDups) === 0);

// -------------------------------------------------------------
// TEST 3: Null counter_id check
// -------------------------------------------------------------
echo "\n--- TEST 3: Visitor counter_id completeness ---\n";
$nullCount = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id IS NULL OR counter_id = 0")->fetchColumn();
report("Zero allowed_visitors with NULL or 0 counter_id", $nullCount === 0, "Null count: $nullCount");

$giftNullCount = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE counter_id IS NULL OR counter_id = 0")->fetchColumn();
report("Zero gift_distribution with NULL or 0 counter_id", $giftNullCount === 0, "Null count: $giftNullCount");

// -------------------------------------------------------------
// TEST 4: Gate Terminal check-in simulation & badge generation
// -------------------------------------------------------------
echo "\n--- TEST 4: Gate Terminal Badge & Counter Routing ---\n";

function simulateCheckin(PDO $pdo, string $identifier): array {
    $stmt = $pdo->prepare("
        SELECT v.id, v.name, v.mobile, v.user_id, v.fincert, v.region, v.school_name, v.designation, v.email,
               v.counter_id, c.name AS counter_name, c.code AS counter_code, c.name_range AS counter_range,
               (
                   SELECT GROUP_CONCAT(NULLIF(TRIM(cr.region), '') ORDER BY cr.region SEPARATOR ', ')
                   FROM `counter_regions` cr
                   WHERE cr.counter_id = c.id AND TRIM(cr.region) != ''
               ) AS counter_regions
        FROM `allowed_visitors` v
        LEFT JOIN `counters` c ON c.id = v.counter_id
        WHERE v.mobile = :id OR LOWER(TRIM(v.user_id)) = LOWER(:id2) OR v.name LIKE :name
        LIMIT 1
    ");
    $stmt->execute([':id' => $identifier, ':id2' => $identifier, ':name' => "%$identifier%"]);
    $v = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$v) return ['found' => false];
    
    $userRegion             = trim((string)($v['region'] ?? ''));
    $assignedCounterName    = trim((string)($v['counter_name'] ?? ''));
    $assignedCounterCode    = trim((string)($v['counter_code'] ?? ''));
    $assignedCounterRange   = trim((string)($v['counter_range'] ?? ''));
    $assignedCounterRegions = trim((string)($v['counter_regions'] ?? ''));

    if ($assignedCounterName === '') {
        $assignedCounterName = ($userRegion !== '') ? "{$userRegion} Counter" : 'Help Desk';
    }

    $counterSubtext = '';
    if (!empty($assignedCounterRange)) {
        $cleanRange = trim($assignedCounterRange);
        $counterSubtext = str_starts_with(strtolower($cleanRange), 'name') ? $cleanRange : ("Names " . $cleanRange);
    } elseif (!empty($assignedCounterRegions)) {
        $regList = array_values(array_filter(array_map('trim', explode(',', $assignedCounterRegions))));
        if (count($regList) === 1) {
            $r = reset($regList);
            $counterSubtext = (strtolower($r) === 'help desk') ? 'Unassigned attendees & assistance' : ($r . ' visitors');
        } elseif (count($regList) === 2) {
            $counterSubtext = $regList[0] . ' and ' . $regList[1] . ' visitors';
        } elseif (count($regList) > 2) {
            $last = array_pop($regList);
            $counterSubtext = implode(', ', $regList) . ' and ' . $last . ' visitors';
        }
    } elseif ($assignedCounterCode === 'helpdesk' || $assignedCounterName === 'Help Desk' || $userRegion === '') {
        $counterSubtext = 'Unassigned attendees & assistance';
    } elseif ($userRegion !== '') {
        $counterSubtext = $userRegion . ' visitors';
    }

    require_once __DIR__ . '/../index.php';
    $html = renderCoeKitLine($assignedCounterName, $counterSubtext);

    return [
        'found'           => true,
        'name'            => $v['name'],
        'counter_name'    => $assignedCounterName,
        'counter_range'   => $assignedCounterRange,
        'counter_subtext' => $counterSubtext,
        'html'            => $html
    ];
}

// 4a. Aarti Bhujbal -> Pune Counter 1
$r1 = simulateCheckin($pdo, 'Aarti Bhujbal');
$p1Ok = ($r1['counter_name'] === 'Pune Counter 1') && 
        (strpos($r1['counter_subtext'], 'A to Chetan Sonawane') !== false) &&
        (strpos($r1['html'], 'Pune Counter 1') !== false) &&
        (strpos($r1['html'], 'coe-kit-counter-pill') !== false);
report("Aarti Bhujbal routes to Pune Counter 1 with range subtext", $p1Ok, "Counter: {$r1['counter_name']}, Subtext: {$r1['counter_subtext']}");

// 4b. Pune Counter 2 visitor
$p2Vis = $pdo->query("SELECT name FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_2') LIMIT 1")->fetchColumn();
$r2 = simulateCheckin($pdo, $p2Vis);
$p2Ok = ($r2['counter_name'] === 'Pune Counter 2') && 
        (strpos($r2['counter_subtext'], 'Chetana Naik to Namira Contractor') !== false);
report("Pune-2 attendee ($p2Vis) routes to Pune Counter 2", $p2Ok, "Counter: {$r2['counter_name']}");

// 4c. Pune Counter 3 visitor
$p3Vis = $pdo->query("SELECT name FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_3') LIMIT 1")->fetchColumn();
$r3 = simulateCheckin($pdo, $p3Vis);
$p3Ok = ($r3['counter_name'] === 'Pune Counter 3') && 
        (strpos($r3['counter_subtext'], 'Namrata Bele to Sangeeta Rautji') !== false);
report("Pune-3 attendee ($p3Vis) routes to Pune Counter 3", $p3Ok, "Counter: {$r3['counter_name']}");

// 4d. Pune Counter 4 visitor
$p4Vis = $pdo->query("SELECT name FROM allowed_visitors WHERE counter_id = (SELECT id FROM counters WHERE code = 'pune_4') LIMIT 1")->fetchColumn();
$r4 = simulateCheckin($pdo, $p4Vis);
$p4Ok = ($r4['counter_name'] === 'Pune Counter 4') && 
        (strpos($r4['counter_subtext'], 'Santosh Patil to Zeenat Syed') !== false);
report("Pune-4 attendee ($p4Vis) routes to Pune Counter 4", $p4Ok, "Counter: {$r4['counter_name']}");

// 4e. Raipur visitor -> Raipur / Chandigarh Counter
$raipurVis = $pdo->query("SELECT name FROM allowed_visitors WHERE LOWER(TRIM(region)) = 'raipur' LIMIT 1")->fetchColumn();
$rRc = simulateCheckin($pdo, $raipurVis);
$rcOk = ($rRc['counter_name'] === 'Raipur / Chandigarh Counter') && 
        (strpos($rRc['counter_subtext'], 'Raipur') !== false) &&
        (strpos($rRc['counter_subtext'], 'Chandigarh') !== false);
report("Raipur attendee ($raipurVis) routes to Raipur / Chandigarh Counter", $rcOk, "Subtext: {$rRc['counter_subtext']}");

// 4f. Empty region visitor -> Help Desk
$emptyVis = $pdo->query("SELECT name FROM allowed_visitors WHERE region IS NULL OR TRIM(region) = '' LIMIT 1")->fetchColumn();
$rHelp = simulateCheckin($pdo, $emptyVis);
$helpOk = ($rHelp['counter_name'] === 'Help Desk') && 
          (strpos($rHelp['html'], 'Help Desk') !== false);
report("Empty region attendee ($emptyVis) routes to Help Desk", $helpOk, "Counter: {$rHelp['counter_name']}");

// -------------------------------------------------------------
// TEST 5: Counter terminal wrong counter check
// -------------------------------------------------------------
echo "\n--- TEST 5: Counter terminal wrong counter validation ---\n";
// Simulating Pune Counter 2 staff checking Aarti Bhujbal (belongs to Pune Counter 1)
$p2CounterId = (int)$pdo->query("SELECT id FROM counters WHERE code = 'pune_2'")->fetchColumn();
$aartiStmt = $pdo->prepare("
    SELECT g.*, c.name AS assigned_counter_name, c.name_range AS assigned_counter_range
    FROM gift_distribution g
    LEFT JOIN counters c ON c.id = g.counter_id
    WHERE g.name LIKE '%Aarti Bhujbal%'
    LIMIT 1
");
$aartiStmt->execute();
$aarti = $aartiStmt->fetch(PDO::FETCH_ASSOC);

$vCounterId = (int)$aarti['counter_id'];
$vCounterName = trim((string)$aarti['assigned_counter_name']);
$isMismatch = ($vCounterId !== $p2CounterId);

$vNameEsc = htmlspecialchars($aarti['name']);
$rangeSuffix = (!empty($aarti['assigned_counter_range'])) ? " ({$aarti['assigned_counter_range']})" : '';
$targetWithRange = htmlspecialchars($vCounterName . $rangeSuffix);
$targetShort = htmlspecialchars($vCounterName);
$mismatchMsg = "{$vNameEsc}, your COE Kit counter is <strong>{$targetWithRange}</strong>. Please go to <strong>{$targetShort}</strong>.";

$wrongCounterOk = $isMismatch && (strpos($mismatchMsg, 'Please go to <strong>Pune Counter 1</strong>') !== false);
report("Pune Counter 2 rejects Aarti Bhujbal with 'Please go to Pune Counter 1'", $wrongCounterOk, "Message: $mismatchMsg");

echo "\n==================================\n";
echo "SUMMARY: $pass PASSED, $fail FAILED\n";
if ($fail === 0) {
    echo "ALL 3 PROBLEMS ARE 100% RESOLVED AND VERIFIED!\n";
}
