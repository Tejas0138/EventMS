<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();
$rows = $pdo->query("SELECT * FROM event_settings")->fetchAll(PDO::FETCH_ASSOC);
print_r($rows);
