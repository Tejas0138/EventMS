<?php
function parseXlsx($filePath) {
    $zip = new ZipArchive();
    if ($zip->open($filePath) !== TRUE) {
        die("Cannot open $filePath\n");
    }

    // Shared strings
    $sharedStrings = [];
    $ssXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssXml) {
        $xml = simplexml_load_string($ssXml);
        foreach ($xml->si as $si) {
            if (isset($si->t)) {
                $sharedStrings[] = (string)$si->t;
            } elseif (isset($si->r)) {
                $text = '';
                foreach ($si->r as $r) {
                    $text .= (string)$r->t;
                }
                $sharedStrings[] = $text;
            } else {
                $sharedStrings[] = '';
            }
        }
    }

    // Workbook
    $wbXml = simplexml_load_string($zip->getFromName('xl/workbook.xml'));
    $sheets = [];
    foreach ($wbXml->sheets->sheet as $sheet) {
        $name = (string)$sheet['name'];
        $rId = (string)$sheet->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
        $sheets[$rId] = $name;
    }

    // Sheet rels to find target xml file
    $relsXml = simplexml_load_string($zip->getFromName('xl/_rels/workbook.xml.rels'));
    $sheetFiles = [];
    foreach ($relsXml->Relationship as $rel) {
        $id = (string)$rel['Id'];
        $target = (string)$rel['Target'];
        if (isset($sheets[$id])) {
            $sheetFiles[$sheets[$id]] = 'xl/' . $target;
        }
    }

    $result = [];
    foreach ($sheetFiles as $sheetName => $targetXml) {
        $sheetData = [];
        $xml = simplexml_load_string($zip->getFromName($targetXml));
        foreach ($xml->sheetData->row as $row) {
            $rowNum = (int)$row['r'];
            $rowData = [];
            foreach ($row->c as $c) {
                $cellRef = (string)$c['r'];
                // extract column letters
                preg_match('/^([A-Z]+)/', $cellRef, $matches);
                $colLetters = $matches[1];
                
                $t = (string)$c['t'];
                $val = (string)$c->v;
                if ($t === 's') {
                    $val = $sharedStrings[(int)$val] ?? '';
                } elseif ($t === 'inlineStr' && isset($c->is->t)) {
                    $val = (string)$c->is->t;
                }
                $rowData[$colLetters] = $val;
            }
            $sheetData[$rowNum] = $rowData;
        }
        $result[$sheetName] = $sheetData;
    }

    $zip->close();
    return $result;
}

$data = parseXlsx(__DIR__ . '/../raw_data_AG_updated.xlsx');
foreach ($data as $sheetName => $rows) {
    echo "========================================\n";
    echo "SHEET: $sheetName (Total Rows: " . count($rows) . ")\n";
    echo "========================================\n";
    foreach ($rows as $rNum => $rData) {
        echo "Row $rNum: ";
        foreach ($rData as $col => $val) {
            echo "[$col] => $val | ";
        }
        echo "\n";
    }
}
