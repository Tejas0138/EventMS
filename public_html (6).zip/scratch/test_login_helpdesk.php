<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$username = 'counter_helpdesk';
$stmt = $pdo->prepare("SELECT id, username, password, role, region, status, counter_id FROM admins WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

echo "Admin row for counter_helpdesk:\n";
print_r($user);

if ($user) {
    if (($user['status'] ?? 'active') === 'disabled') {
        echo "RESULT: Account is DISABLED. Login would be rejected with: 'Your account has been disabled. Please contact the Super Admin.'\n";
    } else {
        echo "WARNING: Account is not disabled!\n";
    }
} else {
    echo "Account not found in admins table.\n";
}
