<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$countersStmt = $pdo->query("
    SELECT c.id, c.name, c.code, c.username, c.name_range, c.is_active, c.last_login,
           a.id AS admin_id, a.status AS admin_status,
           COALESCE(g_agg.total_visitors, 0) AS total_visitors,
           COALESCE(g_agg.kits_distributed, 0) AS kits_distributed,
           COALESCE(g_agg.kits_pending, 0) AS kits_pending,
           (
               SELECT GROUP_CONCAT(NULLIF(TRIM(cr.region), '') ORDER BY cr.region SEPARATOR ', ')
               FROM `counter_regions` cr
               WHERE cr.counter_id = c.id AND TRIM(cr.region) != ''
           ) AS regions_covered
    FROM `counters` c
    LEFT JOIN `admins` a ON (a.username = c.username)
    LEFT JOIN (
        SELECT counter_id,
               COUNT(*) AS total_visitors,
               SUM(CASE WHEN is_gift_collected = 1 THEN 1 ELSE 0 END) AS kits_distributed,
               SUM(CASE WHEN is_gift_collected = 0 THEN 1 ELSE 0 END) AS kits_pending
        FROM `gift_distribution`
        WHERE counter_id IS NOT NULL AND counter_id > 0
        GROUP BY counter_id
    ) g_agg ON (g_agg.counter_id = c.id)
    WHERE c.is_active = 1 AND c.code != 'helpdesk'
    ORDER BY c.id ASC
");
$countersList = $countersStmt->fetchAll(PDO::FETCH_ASSOC);

echo "Total counters in countersList: " . count($countersList) . "\n";
$sumVisitors = 0;
foreach ($countersList as $i => $c) {
    echo "#" . ($i + 1) . " ID: {$c['id']} | Name: {$c['name']} | User: {$c['username']} | AdminUser: {$c['username']} | Visitors: {$c['total_visitors']}\n";
    $sumVisitors += (int)$c['total_visitors'];
}
echo "Sum visitors: $sumVisitors\n";
