<?php
/**
 * Verification test suite for COE Kit Distribution Log layout and alignment fixes.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();

echo "========================================================\n";
echo "   COE KIT DISTRIBUTION LOG & GATE LOG LAYOUT TESTS    \n";
echo "========================================================\n\n";

$testsPassed = 0;
$totalTests = 0;

function assertTest(bool $condition, string $message): void {
    global $testsPassed, $totalTests;
    $totalTests++;
    if ($condition) {
        $testsPassed++;
        echo " [PASS] $message\n";
    } else {
        echo " [FAIL] $message\n";
    }
}

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$_SESSION['user_id'] = 1;
$_SESSION['username'] = 'superadmin';
$_SESSION['user_role'] = 'super_admin';

// Require helper functions from admin.php if not already declared
// We can define a test harness by reading admin.php or running via CLI
require_once __DIR__ . '/../admin.php';

// Test 1: renderGiftTableRows with a combined counter (Panchkula / Prayagraj / Hyderabad Counter)
$mockGiftVisitors = [
    [
        'id' => 99991,
        'name' => 'Dr. Rajesh Sharma',
        'school_name' => 'Delhi Public School, Sector 45',
        'designation' => 'Principal',
        'user_id' => 'REG-PUN-001',
        'region' => 'Hyderabad',
        'assigned_counter_name' => 'Panchkula / Prayagraj / Hyderabad Counter',
        'mobile' => '9876543210',
        'is_gift_collected' => 0,
        'gift_collected_at' => null,
        'handed_over_by' => null,
        'counter_region' => null,
        'counter_id' => 5
    ],
    [
        'id' => 99992,
        'name' => 'Sunita Patil',
        'school_name' => 'Kendriya Vidyalaya No. 1',
        'designation' => 'Vice Principal',
        'user_id' => 'REG-PUN-002',
        'region' => 'Raipur',
        'assigned_counter_name' => 'Raipur / Chandigarh Counter',
        'mobile' => '9123456789',
        'is_gift_collected' => 1,
        'gift_collected_at' => '2026-11-17 14:30:00',
        'handed_over_by' => 'counter_raipur_chandigarh',
        'counter_region' => 'Raipur, Chandigarh',
        'counter_id' => 1
    ]
];

$giftHtml = renderGiftTableRows($mockGiftVisitors, 'all', '', '', 1, 0, 0);

// Test 1: Check <wbr> inserted after / in combined counter
assertTest(strpos($giftHtml, 'Panchkula / <wbr>Prayagraj / <wbr>Hyderabad Counter') !== false,
    'Combined counter name has <wbr> inserted after slashes');

// Test 2: Check region-counter-stack and counter-name-wrap
assertTest(strpos($giftHtml, 'class="region-counter-stack"') !== false,
    'Region & Counter cell uses region-counter-stack container');
assertTest(strpos($giftHtml, 'class="counter-name-wrap"') !== false,
    'Counter name is wrapped in counter-name-wrap with bi-shop icon');
assertTest(strpos($giftHtml, 'class="counter-name-text"') !== false,
    'Counter name text uses counter-name-text class');

// Test 3: Check title attribute on counter name wrap and region badge
assertTest(strpos($giftHtml, 'title="Panchkula / Prayagraj / Hyderabad Counter"') !== false,
    'counter-name-wrap has full counter name in native title attribute');
assertTest(strpos($giftHtml, 'title="Hyderabad"') !== false,
    'region-badge has native title attribute');

// Test 4: Check Move button has class btn-move-counter action-btn and no inline styles
assertTest(strpos($giftHtml, 'class="btn-move-counter action-btn"') !== false,
    'Move button uses unified btn-move-counter action-btn class');
assertTest(strpos($giftHtml, 'border-radius:6px') === false,
    'Move button has NO legacy inline border-radius:6px');
assertTest(strpos($giftHtml, 'padding:6px 10px') === false,
    'Move button has NO legacy inline padding:6px 10px');

// Test 5: Check Give Kit button
assertTest(strpos($giftHtml, 'class="btn-mark-given action-btn"') !== false,
    'Give Kit button uses btn-mark-given action-btn class');

// Test 6: Check Handover Timestamp formatting
assertTest(strpos($giftHtml, '— Not Yet Handed Over —') !== false,
    'Pending visitor shows "— Not Yet Handed Over —"');
assertTest(strpos($giftHtml, 'gift-handed-by') !== false,
    'Collected visitor shows gift-handed-by container');
assertTest(strpos($giftHtml, 'counter_raipur_chandigarh') !== false,
    'Collected visitor displays username of person who handed over');

// Test 7: Verify max 2 buttons per row for Super Admin
// Visitor 1 (Pending): Give Kit + Move = 2 buttons
// Visitor 2 (Collected): Reset Kit + Move = 2 buttons
$dom = new DOMDocument();
@$dom->loadHTML('<table><tbody>' . $giftHtml . '</tbody></table>');
$rows = $dom->getElementsByTagName('tr');
assertTest($rows->length === 2, 'Rendered exactly 2 rows');

foreach ($rows as $i => $row) {
    $actionGroups = $row->getElementsByTagName('div');
    $btnCount = 0;
    foreach ($actionGroups as $div) {
        if ($div->getAttribute('class') === 'action-btn-group') {
            $links = $div->getElementsByTagName('a');
            $buttons = $div->getElementsByTagName('button');
            $spans = $div->getElementsByTagName('span');
            $btnCount = $links->length + $buttons->length + $spans->length;
        }
    }
    assertTest($btnCount <= 2, "Row " . ($i + 1) . " has at most 2 action items ($btnCount items found)");
}

// Test 8: renderGateTableRows
$mockGateVisitors = [
    [
        'id' => 99993,
        'name' => 'Anita Desai',
        'school_name' => 'St. Xavier High School',
        'designation' => 'Teacher',
        'user_id' => 'REG-AHM-045',
        'region' => 'Ahmedabad',
        'mobile' => '9822011223',
        'is_day1_checked_in' => 0,
        'day1_checked_in_at' => null,
        'is_day2_checked_in' => 0,
        'day2_checked_in_at' => null
    ]
];
$gateHtml = renderGateTableRows($mockGateVisitors, 'all', '', '', 1, 0);
assertTest(strpos($gateHtml, 'title="Ahmedabad"') !== false,
    'Gate Entry region-badge has title attribute');
assertTest(strpos($gateHtml, 'title="Check in Day 1"') !== false,
    'Gate Entry Day 1 button has native title attribute');
assertTest(strpos($gateHtml, 'title="Check in Day 2"') !== false,
    'Gate Entry Day 2 button has native title attribute');

// Test 9: CSS Rules in admin.php
$adminCss = file_get_contents(__DIR__ . '/../admin.php');

assertTest(strpos($adminCss, '.crisp-table.table-gift') !== false && strpos($adminCss, 'min-width: 1514px') !== false,
    'CSS has table-gift min-width: 1514px');
assertTest(strpos($adminCss, '.crisp-table.table-gate') !== false && strpos($adminCss, 'min-width: 1464px') !== false,
    'CSS has table-gate min-width: 1464px');
assertTest(strpos($adminCss, 'padding: 14px 14px !important;') !== false,
    'CSS enforces 14px 14px cell padding for zero column touching');
assertTest(strpos($adminCss, 'height: 76px !important;') !== false,
    'CSS enforces uniform row height 76px');
assertTest(strpos($adminCss, 'width: 270px !important;') !== false,
    'CSS sets col-region width: 270px on desktop');
assertTest(strpos($adminCss, 'width: 240px !important;') !== false,
    'CSS sets col-actions width: 240px on desktop');
assertTest(strpos($adminCss, 'width: 108px !important;') !== false,
    'CSS sets action button width: 108px on desktop');
assertTest(strpos($adminCss, 'width: 110px !important;') !== false,
    'CSS sets col-gift-status .status-pill width: 110px on desktop');
assertTest(strpos($adminCss, '.action-btn-group .btn-move-counter') !== false,
    'CSS includes btn-move-counter in mobile action button grid');

echo "\n--------------------------------------------------------\n";
echo "SUMMARY: $testsPassed / $totalTests tests passed.\n";
echo "========================================================\n";
exit($testsPassed === $totalTests ? 0 : 1);
