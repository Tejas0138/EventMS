<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();
$tables = $pdo->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_NUM);
echo "BASE TABLES:\n";
foreach ($tables as $t) {
    $tName = $t[0];
    $count = $pdo->query("SELECT COUNT(*) FROM `{$tName}`")->fetchColumn();
    echo " - {$tName}: {$count} rows\n";
}

$views = $pdo->query("SHOW FULL TABLES WHERE Table_type = 'VIEW'")->fetchAll(PDO::FETCH_NUM);
echo "VIEWS:\n";
foreach ($views as $v) {
    echo " - {$v[0]}\n";
}
