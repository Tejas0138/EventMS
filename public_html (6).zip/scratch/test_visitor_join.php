<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$missing = $pdo->query('SELECT COUNT(*) FROM allowed_visitors a LEFT JOIN gift_distribution g ON a.user_id = g.user_id WHERE g.id IS NULL')->fetchColumn();
echo "Missing in gift_dist: $missing\n";

$sample = $pdo->query("
    SELECT a.id, a.name, a.user_id, a.fincert, a.region,
           c.name as counter_name,
           a.school_name, a.designation, a.mobile, a.email,
           a.is_day1_checked_in, a.day1_checked_in_at,
           a.is_day2_checked_in, a.day2_checked_in_at,
           g.is_gift_collected
    FROM allowed_visitors a
    LEFT JOIN gift_distribution g ON a.user_id = g.user_id
    LEFT JOIN counters c ON g.counter_id = c.id
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

print_r($sample);
