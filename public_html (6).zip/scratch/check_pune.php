<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

$puneCounters = $pdo->query("SELECT * FROM counters WHERE code LIKE 'pune%' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
echo "=== PUNE COUNTERS IN DATABASE ===\n";
foreach ($puneCounters as $pc) {
    echo "ID: {$pc['id']} | Code: {$pc['code']} | Name: {$pc['name']} | Range: {$pc['name_range']}\n";
    $minMax = $pdo->query("SELECT MIN(name) as min_name, MAX(name) as max_name, COUNT(*) as cnt FROM allowed_visitors WHERE counter_id = {$pc['id']}")->fetch(PDO::FETCH_ASSOC);
    echo "   Actual visitors: {$minMax['cnt']} (Min: '{$minMax['min_name']}' to Max: '{$minMax['max_name']}')\n";
}
