<?php
require_once __DIR__ . '/../config/db.php';
$baseUrl = 'http://localhost:8080/EventMS';
$cookieFile = __DIR__ . '/test_admin_cookie.txt';

$ch = curl_init("$baseUrl/admin.php?export=gate_tab_csv&gfilter=all");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEFILE     => $cookieFile,
    CURLOPT_TIMEOUT        => 15
]);
$csvContent = curl_exec($ch);
curl_close($ch);

// Check first 3 bytes for BOM
$bom = bin2hex(substr($csvContent, 0, 3));
echo "BOM hex: $bom (Expected: efbbbf)\n";

// Parse rows
$lines = explode("\n", substr($csvContent, 3));
$headers = str_getcsv(array_shift($lines));
echo "Total columns: " . count($headers) . "\n";
echo "Columns: " . implode(" | ", $headers) . "\n\n";

$rowCount = 0;
$hasSpecialOrHindi = false;
$sampleChecked = null;
foreach ($lines as $line) {
    if (trim($line) === '') continue;
    $row = str_getcsv($line);
    $rowCount++;
    if (count($row) !== 15) {
        echo "ERROR: Row $rowCount has " . count($row) . " columns instead of 15!\n";
    }
    // Check for check-in times
    if ($row[10] === 'Inside Gate' && empty($row[11])) {
        echo "ERROR: Row $rowCount is Inside Gate on Day 1 but has empty time!\n";
    }
    if ($sampleChecked === null && $row[10] === 'Inside Gate') {
        $sampleChecked = $row;
    }
}
echo "Total parsed rows: $rowCount\n";
if ($sampleChecked) {
    echo "Checked-in sample row:\n";
    foreach ($headers as $idx => $h) {
        echo "  $h: '{$sampleChecked[$idx]}'\n";
    }
}
