<?php
/**
 * Test to verify removal of Counter Username column from Regional Counter Accounts table
 */
require_once __DIR__ . '/../config/db.php';
$baseUrl = 'http://localhost:8080/EventMS';
$cookie = tempnam(sys_get_temp_dir(), 'test_c_');
$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);

// 1. Login as Super Admin
curl_setopt($ch, CURLOPT_URL, "$baseUrl/login.php");
$html = curl_exec($ch);
preg_match('/name="csrf_token"\s+value="([^"]+)"/', $html, $m);
$csrf = $m[1] ?? '';

curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'csrf_token' => $csrf,
    'username'   => 'admin',
    'password'   => 'admin123'
]));
curl_exec($ch);

// 2. Fetch admin.php?tab=counters
curl_setopt($ch, CURLOPT_POST, false);
curl_setopt($ch, CURLOPT_URL, "$baseUrl/admin.php?tab=counters");
$res = curl_exec($ch);

$allPass = true;
function assertCondition($name, $cond, $details = '') {
    global $allPass;
    if ($cond) {
        echo "  [PASS] $name\n";
    } else {
        echo "  [FAIL] $name - $details\n";
        $allPass = false;
    }
}

echo "========================================================\n";
echo "TESTING REMOVAL OF COUNTER USERNAME COLUMN\n";
echo "========================================================\n";

// Locate table
preg_match('/<table class="crisp-table table-counters">(.*?)<\/table>/s', $res, $tm);
$tableHtml = $tm[1] ?? '';

assertCondition("Found table-counters in HTML", !empty($tableHtml));

// 1. Header check
assertCondition(
    "Header DOES NOT contain 'Counter Username'",
    stripos($tableHtml, '<th class="col-c-user"') === false && stripos($tableHtml, 'Counter Username') === false,
    "Counter Username header still found in table"
);

// Count <th>
preg_match_all('/<th\b[^>]*>/i', $tableHtml, $thm);
$thCount = count($thm[0]);
assertCondition("Table has exactly 9 <th> columns", $thCount === 9, "Found: $thCount");

// 2. Body cell check
assertCondition(
    "Table body DOES NOT contain <td class=\"col-c-user\">",
    strpos($tableHtml, '<td class="col-c-user">') === false,
    "col-c-user cell still found in tbody"
);

// Verify each row in tbody has exactly 9 <td>
preg_match('/<tbody>(.*?)<\/tbody>/s', $tableHtml, $tbm);
$tbody = $tbm[1] ?? '';
preg_match_all('/<tr>(.*?)<\/tr>/s', $tbody, $rowMatches);

$rowCount = count($rowMatches[0]);
assertCondition("Found counter rows in tbody", $rowCount > 0, "Row count: $rowCount");

$allRowsHave9 = true;
foreach ($rowMatches[1] as $idx => $rowContent) {
    preg_match_all('/<td\b[^>]*>/i', $rowContent, $tdm);
    $tdCount = count($tdm[0]);
    if ($tdCount !== 9) {
        $allRowsHave9 = false;
        echo "    Row #$idx has $tdCount <td> (expected 9)\n";
    }
}
assertCondition("All rows in tbody have exactly 9 <td> cells", $allRowsHave9);

// 3. Footer check
preg_match('/<tfoot>(.*?)<\/tfoot>/s', $tableHtml, $tfm);
$tfoot = $tfm[1] ?? '';
assertCondition(
    "Table footer DOES NOT contain <td class=\"col-c-user\">",
    strpos($tfoot, 'col-c-user') === false,
    "col-c-user found in tfoot"
);

// Footer has 7 td tags where one has colspan=3 (total 9 columns)
preg_match_all('/<td\b[^>]*>/i', $tfoot, $tfootTdMatches);
$tfootTdCount = count($tfootTdMatches[0]);
assertCondition("Footer has 7 <td> cells (including colspan=3 for a total of 9)", $tfootTdCount === 7, "Found: $tfootTdCount");

// 4. Empty state colspan check in admin.php code
$adminCode = file_get_contents(__DIR__ . '/../admin.php');
assertCondition(
    "Empty state row has colspan=\"9\"",
    strpos($adminCode, '<td colspan="9" style="text-align:center;padding:3rem;color:var(--text-muted);"') !== false,
    "Colspan 9 not found in empty state"
);

// 5. CSS column widths check
assertCondition(
    "col-c-name has expanded width (320px)",
    strpos($adminCode, '.table-counters .col-c-name {') !== false && strpos($adminCode, 'width: 320px !important;') !== false,
    "Expanded width for col-c-name missing"
);
assertCondition(
    "col-c-regions has expanded width (440px)",
    strpos($adminCode, '.table-counters .col-c-regions {') !== false && strpos($adminCode, 'width: 440px !important;') !== false,
    "Expanded width for col-c-regions missing"
);

echo "========================================================\n";
if ($allPass) {
    echo ">>> ALL COUNTER TABLE COLUMN REMOVAL TESTS PASSED! <<<\n";
    exit(0);
} else {
    echo ">>> SOME TESTS FAILED! <<<\n";
    exit(1);
}
