<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();
$pdo->exec("ALTER TABLE rate_limits CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
echo "rate_limits collation is now utf8mb4_unicode_ci\n";
