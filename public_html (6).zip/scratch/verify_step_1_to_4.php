<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();

echo "=== VERIFYING POST-UPDATE METRICS ===\n";

$totA = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors")->fetchColumn();
$totG = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution")->fetchColumn();
echo "Total allowed_visitors: $totA (Expected: 1270)\n";
echo "Total gift_distribution: $totG (Expected: 1270)\n";

$d1 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day1_checked_in = 1")->fetchColumn();
$d2 = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE is_day2_checked_in = 1")->fetchColumn();
$kit = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE is_gift_collected = 1")->fetchColumn();
echo "Day 1 checked in: $d1 (Expected: 3)\n";
echo "Day 2 checked in: $d2 (Expected: 0)\n";
echo "Kits distributed: $kit (Expected: 0)\n";

$emptyRegA = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE region IS NULL OR TRIM(region) = ''")->fetchColumn();
$emptyRegG = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE region IS NULL OR TRIM(region) = ''")->fetchColumn();
echo "Empty region in allowed_visitors: $emptyRegA (Expected: 0)\n";
echo "Empty region in gift_distribution: $emptyRegG (Expected: 0)\n";

$emptyMobA = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE mobile IS NULL OR TRIM(mobile) = ''")->fetchColumn();
$emptyMobG = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE mobile IS NULL OR TRIM(mobile) = ''")->fetchColumn();
echo "Empty mobile in allowed_visitors: $emptyMobA (Expected: 0)\n";
echo "Empty mobile in gift_distribution: $emptyMobG (Expected: 0)\n";

// Help desk check
$hdVisA = (int)$pdo->query("SELECT COUNT(*) FROM allowed_visitors WHERE counter_id = 21")->fetchColumn();
$hdVisG = (int)$pdo->query("SELECT COUNT(*) FROM gift_distribution WHERE counter_id = 21")->fetchColumn();
echo "Help Desk counter_id in allowed_visitors: $hdVisA (Expected: 0)\n";
echo "Help Desk counter_id in gift_distribution: $hdVisG (Expected: 0)\n";

$hdCounterActive = (int)$pdo->query("SELECT is_active FROM counters WHERE id = 21")->fetchColumn();
$hdAdminStatus = $pdo->query("SELECT status FROM admins WHERE username = 'counter_helpdesk'")->fetchColumn();
echo "Help Desk counter is_active: $hdCounterActive (Expected: 0)\n";
echo "counter_helpdesk admin status: $hdAdminStatus (Expected: disabled)\n";

// Active counters check
$activeCounters = $pdo->query("
    SELECT c.id, c.code, c.name, c.is_active, c.name_range, COUNT(v.id) as cnt
    FROM counters c
    LEFT JOIN allowed_visitors v ON v.counter_id = c.id
    WHERE c.is_active = 1
    GROUP BY c.id
    ORDER BY c.id
")->fetchAll(PDO::FETCH_ASSOC);

echo "\nActive Counters Count: " . count($activeCounters) . " (Expected: 20)\n";
$sumActive = 0;
foreach ($activeCounters as $ac) {
    echo "ID: {$ac['id']} | Code: {$ac['code']} | Count: {$ac['cnt']} | Name: {$ac['name']}\n";
    $sumActive += $ac['cnt'];
}
echo "Sum across 20 active counters: $sumActive (Expected: 1270)\n";

// Check the new visitor record
$newVisA = $pdo->query("SELECT * FROM allowed_visitors WHERE user_id = 'OS_3071828'")->fetch(PDO::FETCH_ASSOC);
$newVisG = $pdo->query("SELECT * FROM gift_distribution WHERE user_id = 'OS_3071828'")->fetch(PDO::FETCH_ASSOC);
echo "\n--- New Visitor Check (OS_3071828) ---\n";
echo "In allowed_visitors: Name='{$newVisA['name']}', Region='{$newVisA['region']}', Mobile='{$newVisA['mobile']}', CounterID={$newVisA['counter_id']}, Day1={$newVisA['is_day1_checked_in']}, Day2={$newVisA['is_day2_checked_in']}\n";
echo "In gift_distribution: Name='{$newVisG['name']}', Region='{$newVisG['region']}', Mobile='{$newVisG['mobile']}', CounterID={$newVisG['counter_id']}, GiftStatus={$newVisG['is_gift_collected']}\n";
