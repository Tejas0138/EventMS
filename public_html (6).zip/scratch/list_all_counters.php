<?php
require_once __DIR__ . '/../config/db.php';
$pdo = Database::getConnection();
$rows = $pdo->query('SELECT id, name, code, username, is_active FROM counters ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
    echo "ID: {$r['id']} | Name: '{$r['name']}' | Code: '{$r['code']}' | Username: '{$r['username']}' | Active: {$r['is_active']}\n";
}
